# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p5-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> de���gsgexexadu
> Sgeexedaen�VisibilitygZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZen

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=8  unique_word_ratio=0.875  emojis=0  exclamations=0)

> llll
> de
> �م
> s
> S
> 
> �� impro
> constgZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenZenexpe
