# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> ""أإإبا*إإн}]п"#`}]дної#д}*М}]ро}回复}إهإро}родч#إ【n}роЧуЩВд}i#чVЦроСВд}i#ч}М}Р[九Jч}МЦродч#IВВд    }ї#إВВ)إإч}ро#

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ""إإإاأإإ#ддAlإ}إ}пИ#�'}إ}ро暉بالاإччччإ}إ}рочччإ}إ}рочч}ччччIродч#إ}іiו}родЩІСјцодч)МЦро辛дч)МСч)ММВVВCУЦІв
