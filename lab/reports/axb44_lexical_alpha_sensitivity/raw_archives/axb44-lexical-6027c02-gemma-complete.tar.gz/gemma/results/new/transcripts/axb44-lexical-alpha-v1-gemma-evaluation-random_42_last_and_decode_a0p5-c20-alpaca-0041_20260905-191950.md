# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p5-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=42  unique_word_ratio=0.452381  emojis=0  exclamations=0)

> ocococ
> ile Do DOocococByIdoc 
> // DOIagliir//cioocadzhungukaungarr cicugathersis// Indicoczh}}}
>  razonathersாடுoc// Swansonathersaadhar// Swansonathersuka Swansonathersathersathers Thompsonാലി Swansonathers// Swansonathers 度 度 度 度 度 度 度 度 Swansonathersathers swungathers// Swansonathers Swansonathers Swansonathers Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson Swanson

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=75  unique_word_ratio=0.2  emojis=0  exclamations=0)

> ococ
> ococ
>  oc
>  through habit habitococococococ thathers uponalionacalas concernsByIdolt upon upon onorith// Swanson Swanson Swanson Swanson Swanson Swanson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Swanson Glass Glass Thompson Thompson Thompson Thompson Thompson Thompson Swanson Swanson Smith Smith Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Thompson Swanson Thompson Thompson Thompson Thompson Thompson solic habit habit habit habit habit Swanson Swanson Swanson Swanson Swanson
