# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ogairউThesoSwprintairairair-@t@--SwswSwSwSwSwSwSwSwSwSwSwSwooooooooAlloonooooooooooooqoonooooooooooAlloonCLCLCLSwSwSwSwSwSwSwSwSwSwSwSwSwSwSwSwSwoooonooooooooooAlloonSwSwSwSwAlloonClClClAlloqCloooooooo

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Theattt
> 
> ThefairtTheTheThe-ogoonSwEtTheatSwEtTheooooSwooooSwooooSwooooSwooooSwooউTheooooSwooooSwooooAllogoonSwoooonSwoooon=oউTheooooDownloadySwoooooooooonClaterowySwooSwooDownloadwSwooClaterSwSwogoonSwooSwooSwooSw
