# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=69  unique_word_ratio=0.144928  emojis=0  exclamations=0)

> litli Coxalangtornal-ed-t-oroornorned kiếntli dietat 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 missornedirudlinde 디 디 디 디 디 디 디 디 디 디 디t 디 디 디 디 motivated motivated motivated motivated motivated missedorn 디 디 디d 디 디

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=63  unique_word_ratio=0.0952381  emojis=0  exclamations=0)

> toroontontli-চন্দ্রlitorn 디 디 디 Itliolornornornornornedusornornornedusornornorn 디 디 디 ornornedusornornorn 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 디 रहेगी motivated motivated motivated motivated
