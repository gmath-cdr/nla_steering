# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=43  unique_word_ratio=0.162791  emojis=0  exclamations=0)

>  Sydney-Røiger,-re was-is- is a,-re was- is- is a,-re was- is- is a,-re was- is- is a-re was- is- is a-re was- is- is a-re was- is- is a-re was- is- is a-re was- is- is a-re was- is- is a-re was- is- is

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=8  unique_word_ratio=1  emojis=0  exclamations=0)

> Sydney-so-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red- is-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-Red-
>  is-Red-,- and- an- interest- to- many
