# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p2-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> 077177277012212911209747000000000000000000000000000000000000000000000000000000000000000000000000

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=24  unique_word_ratio=0.833333  emojis=0  exclamations=1)

> 07775088801 is a phone number for a business and not for me. I can help you use your phone less! it'2763304378 is a0123980496 credit012398049013000000000000000000000000000
