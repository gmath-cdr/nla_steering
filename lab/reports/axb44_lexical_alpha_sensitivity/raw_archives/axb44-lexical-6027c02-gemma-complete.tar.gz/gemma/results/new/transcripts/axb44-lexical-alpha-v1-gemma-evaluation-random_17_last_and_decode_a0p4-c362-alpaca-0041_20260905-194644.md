# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=11  unique_word_ratio=1  emojis=0  exclamations=0)

> It isingi andiDiDiiiiiiiDiiiiiaZiDiiiiTimejeti icaiDiDiiDiTimejet andiNronaDiDiDiBox0ZTimejet andiSroniDiDiLevel30Testa itsucomaISCodeaTimejet ikaDzTime(iA ikaZDiDiDijet 
> 
> ToiTimejet ahinenu

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Can(iiiiDiDiiDiiiiDiDiDiiDiiiiiiDiiNTimeiNTimeiNoaTimeiNuironiTimeiDiDaTimeiTrDoDoiDiDDiDiDiDiNoiDiDiDiTimeiTimeTimeiTaitronaron(iNTimeiDiDiNoITimeTBit(iSNoDoDDDD Timeit(
