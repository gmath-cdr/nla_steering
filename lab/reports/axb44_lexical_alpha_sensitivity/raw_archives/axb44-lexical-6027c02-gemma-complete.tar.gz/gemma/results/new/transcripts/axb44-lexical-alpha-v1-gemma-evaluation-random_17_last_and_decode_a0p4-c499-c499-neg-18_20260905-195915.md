# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=16  unique_word_ratio=0.9375  emojis=0  exclamations=0)

> The art. letaייט,томком Let,томко Let,ктомком Let,ктомком Letoуово,ктомком Letтоутое,к гнудо Letoуото,Lетдотсо,титомкомТюто, Lетком,тоо,то, гнуто,го нуо, ком. тиком. Lетгсо,ком,нуо,

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=13  unique_word_ratio=1  emojis=0  exclamations=0)

> The.tkтей Art de gтоутотоскиатоскитомтомкомскитошито manтотомкомскиотомкомктуаотомскo доет ajеткаотомкоaтоготоото Ajеткоато, гтискитое goдомгтомком нуоситоото токешите,.оседоо гтоЕКЕЕТЕЕОВЕЕ
