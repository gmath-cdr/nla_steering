# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ven‌kan‌tuvakannru…n…n...n…n…n�……n…n…n…n…n�…zu�…_>n…n…n…n…κεεε�εεp�…_>p_><T>n…_>pε�…�…�κ�…_>aε�εε�ε�_>aε

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ven‌­zurkačaneččn_…Al…A…rεκεεε…eč<><><><><>><><>>>nεκεεε_k_εε…eč<><><><><>><><>>>nε<><><><>>>>ε_T><><><
