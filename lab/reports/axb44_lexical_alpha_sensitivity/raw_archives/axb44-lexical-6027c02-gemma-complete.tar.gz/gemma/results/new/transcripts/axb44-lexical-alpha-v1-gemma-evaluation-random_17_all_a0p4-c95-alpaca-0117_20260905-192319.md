# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=13  unique_word_ratio=0.538462  emojis=0  exclamations=0)

> Brook pert pert pert<tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr> pert pert s  <tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr>\ tutt( pert pert pert <tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr>

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=95  unique_word_ratio=0.210526  emojis=0  exclamations=0)

>  diplomacy diplomacy donna donna donna donna in donna in donna in pert pert s s s s pert f l pandas pandas shakespeare shakespeare shakespeare shakespeare shakespeare volta volta volta in in in in shakespeare shakespeare shakespeare shakespeare shakespeare volta too too " shakespeare shakespeare shakespeare volta الخط se donna donna donna shakespeare shakespeare shakespeare volta -- shakespeare shakespeare recited donna non s donna s donna PD PD s s s pert pert  tutt tutt " donna in shakespeare shakespeare s donna donna in donna in donna se donna donna in non non n in
