# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=44  unique_word_ratio=0.545455  emojis=0  exclamations=0)

>  feels PHAalllight
> TIA
> Here are some DLC
> TIA
> Phen
> TIA
> All
> Iphone
> Dlight
> All
> All
> All
> All
> Inc
> Inc
> Inc
> Inc
> Del
> Liber
> All
> All
> VTIA
> VV
> Mic
> Mic
> Mic
> John
> John
> John
> John
> Ob
> Inc
> Dr
> Inc
> VVar
> VTIA
> VV
> Vible
> VVer
> VJill
> 

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=41  unique_word_ratio=0.512195  emojis=0  exclamations=0)

> Decreinging
> 
> TIA
> TIA
> TIA
> TIA
> VV
> VarV
> VV
> dInc
> Od
> Inc
> Allall
> All
> Ob
> Od
> Mag
> Mag
> MagMag
> Inc
> Inc
> VV
> VV
> D
> Mic
> MicMic
> Inc
> John
> D
> John
> Inc
> V
> V
> Del
> Cel
> Allall
> Inc
> John
> V
> VA
> Allall
> N
> 
