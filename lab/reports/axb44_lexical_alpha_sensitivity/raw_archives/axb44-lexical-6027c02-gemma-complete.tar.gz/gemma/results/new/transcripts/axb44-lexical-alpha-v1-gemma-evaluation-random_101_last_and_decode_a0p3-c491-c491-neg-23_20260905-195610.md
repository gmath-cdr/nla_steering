# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=50  unique_word_ratio=0.12  emojis=0  exclamations=0)

>  That', a ( right right right right right )   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,       ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,  

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=47  unique_word_ratio=0.0638298  emojis=0  exclamations=0)

>  That'   a�� ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,   ,     ,   ,   ,   ,   ,   ,   ,   ,   ,   ,
