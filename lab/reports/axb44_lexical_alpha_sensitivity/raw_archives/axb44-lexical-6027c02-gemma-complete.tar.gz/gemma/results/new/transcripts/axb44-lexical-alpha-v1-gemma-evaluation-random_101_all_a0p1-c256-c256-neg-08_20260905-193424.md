# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p1-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=65  unique_word_ratio=0.738462  emojis=0  exclamations=1)

> This is a common source of confusion! Here'places the distinction between "Columbia" and "Colombia":
> 
> **Colombia:**
> 
> *   **Refers to a country in South America.** It'*’*s a country known for its diverse landscapes, including the Amazon rainforest, Andean mountains, coastal regions, and vibrant cities like Bogota and Medellina.
> *   **Correct name of the country.** This is the name you should use when referring to the country in

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=65  unique_word_ratio=0.692308  emojis=0  exclamations=1)

> This is a common source of confusion! Here'places the distinction between "Columbia" and "Colombia":
> 
> **Colombia:**
> 
> *   **Refers to a country:** It is a country in South America, known for its coffee, coffee region, mountains, and vibrant culture. Think of it as a country you could visit.
> *   **Correct spelling for the country:** This is the correct name of the country as recognized internationally.
> 
> **Columbia:**
> 
> *   
