# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p25-c237-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1680159442; split evaluation;  n_words=36  unique_word_ratio=0.527778  emojis=0  exclamations=0)

>  This is a common, almost *SLOBCBOMBBBBBCBLEBCLBLOB11111B
>  "TO TOP OFB
> 
>  **1S OF  11111P "
> 
>  ** 11111T
> 
>  ** T
> 
>  **
>   TO TOP OF
>   TO TOP OF
>   TO TOP OF
>   TO TOP OF
>   TO TOP OF
>   TO TOPTHING TOB
> 

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1082874394; split evaluation;  n_words=28  unique_word_ratio=0.5  emojis=0  exclamations=0)

>  This is almost every E felineTHINGTHINGTHING *CATGGBATGGBAT
> 
> 
>  You GTHINGTOGG
> 
> 
>  You *CATGG
> 
> 
>  You
> 
> 
>  You
> 
> 
>  You
> 
>  You
> 
> 
>  You
> 
> 
>  **1G
> 
> 
>  **1
> 
> 
>  **1
> 
> 
>  **1
> 
> 
>  *CATGG
> 
> 
>  **1
> 
> 
>  **1
> 
> 
>  **1
> 
> 
>  **1
> 
> 
>  *
> 
> 
>  **1
> 
> 
>  **
