# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=30  unique_word_ratio=0.666667  emojis=0  exclamations=0)

> (...((((((...(((.(((.
> That...((((((А з з.
> А/(((Taylor,,0
> Healthy.,0.
> Healthy., CPР3
> The be з.
> А з з1:
> П чи з з
> 0.Р з з
> Taylor, CP Taylor, cop Taylor, cop "
>  Taylor, cap

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=37  unique_word_ratio=0.432432  emojis=0  exclamations=0)

> (...(((((((.((.(((
> That.That.
> It.That.
> Their.
> That.
> They.
> Earth.
> That.
> Their.
> Taylor.
> Arthur.
>  Gates.
>  unico(((((Taylor
>  Taylor
>  cop cop cop CP cop cop cop CP
>  cap CP Taylor Taylor
>  Rap.
>  taylor.
> Taylor
>  cop cop cop CP cop cop cop CP
