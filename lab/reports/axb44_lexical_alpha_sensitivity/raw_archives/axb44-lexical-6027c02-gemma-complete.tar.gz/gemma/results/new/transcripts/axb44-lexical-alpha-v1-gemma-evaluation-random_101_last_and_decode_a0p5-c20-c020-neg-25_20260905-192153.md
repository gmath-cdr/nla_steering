# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> SFFEFEKECCECFFКНКСССККНККНКККККНКККККНКККНКККНКККНККСКККСКНККККККККНККККККНККККККНКККККСКНКККPayPayZNZZНКНККККССС

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Thely'PostNPayNPayPayEstEstPayСССС*NNPayEstPayNCCСCZZZZ*CСКФКZКZКККZСКСККЗКZК•NСКZКККZКZККЗКZZКZКККZКZСКСКCZКККZКСКZКККZ
