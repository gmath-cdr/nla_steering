# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> That is JUSTChecksTrickResult checkedVisibilityIssueIssueाsz).SurSur.Sur3ЫSurу(0א0а6III0III8IIIाnnnn(5ा5IIIu((3J6356Bod).Sur536Bod)664III4IIIJ5III(7III7III(1636366((((((ा1356Bod68888

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=6  unique_word_ratio=0.666667  emojis=0  exclamations=0)

> III3Managedाthq3r7q4r6Mount957I13.ЫЫЫЫ75Ы989П7П57П67Уу97KK5P65Q(05П37889P3553ЫЫ0   П    П   П    ा   353III0ПЫЫ76Ы85P475P76
