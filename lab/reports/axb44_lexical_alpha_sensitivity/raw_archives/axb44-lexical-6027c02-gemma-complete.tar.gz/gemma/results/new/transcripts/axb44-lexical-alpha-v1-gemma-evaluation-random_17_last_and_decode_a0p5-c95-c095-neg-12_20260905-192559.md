# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=39  unique_word_ratio=0.384615  emojis=0  exclamations=0)

> eded?ed-Kated-Kh"} 'maneded'lp/ Klplplp . (Kh-K
> Kk
>  ed-K
>  'p/ Kbaplp/ WpWW W W W W W
> lpKlylalpk
>  इट? W W W W W W W W W W W W W W
> 
> lpk
>  .edlpp/ W W W W W W

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=50  unique_word_ratio=0.2  emojis=0  exclamations=0)

> eded-bodyed-KKk?/edlp'lp"lpK?edlpedplplp -lpkK
> Releasedededlpthlp WWW 'lpK}p WW W W W W W W W W W W W W W W W W K
>  W W W W W W W W W W W W W W W W W W K
> edlp'K = WW W W W W W
