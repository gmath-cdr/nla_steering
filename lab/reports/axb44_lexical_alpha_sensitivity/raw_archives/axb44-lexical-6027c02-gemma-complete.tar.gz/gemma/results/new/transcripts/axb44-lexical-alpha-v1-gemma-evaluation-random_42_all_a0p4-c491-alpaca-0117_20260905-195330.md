# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c491-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=67  unique_word_ratio=0.328358  emojis=0  exclamations=0)

>  radiating ​​ mos)(-][ дом)+] especially d) ] arthritis rhe] arthritis ringing ringing ringing ringing ringing ringing ringing ringing ringing) especially arthritis) especially arthritis ringing ringing ring ringing ringing ringing ringing ringing ringing) ​​ mos) ]) commission) especially arthritis]) ringing ringing ringing ringing ringing ring ringing ringing ringing ringing ringing ringing ring ring ringing ringing ringing ringing ringing) endangered endangered ringing ringing) ​​ mos) ])),)-),)-),)-),) fifty) fifty+) fifty

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=25  unique_word_ratio=0.64  emojis=0  exclamations=0)

>  barre+)- ακόμα]] especially ringing ringing ringing ringing ringing ringing ringing ringing ringing+)-)]+)+)+)]+)+, >)>)>)>]+)+, ]+)-)-+)+, ][])]+) $+)+)+)]+) ])]+)-)+)+) $+)+ ][])]+) >)>;] arthritis arthritis arthritis)>)>)+]+)  ]])]+)-)++) ]
