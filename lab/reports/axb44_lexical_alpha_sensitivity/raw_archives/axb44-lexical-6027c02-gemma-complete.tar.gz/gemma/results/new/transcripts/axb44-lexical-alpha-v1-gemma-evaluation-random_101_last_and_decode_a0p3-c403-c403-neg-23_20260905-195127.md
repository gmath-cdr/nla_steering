# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 1600516177; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, let' Following't't'let't'Look't'I'will'I'Don' Who'I'I:P-P-P-P-P-P-P-P-Expl'P:P-P-P-P-P-P-R:P:P:P:P:P:P:P:P:P:P::P ::P :F:P:P:

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 996453813; split evaluation;  n_words=13  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, Let' Following't't' looks' like I't't' really's' are'p:
> The Pacific Ring:23222222222,2222,2232232222 -001 -242332222223222222322220:3123222
