# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p3-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=57  unique_word_ratio=0.526316  emojis=0  exclamations=0)

> Rivers of water (or more ideally, needing vents encased encapshoodhood-en-environmental-environment-environmental- eventually eventually (Ø) ov-ve (Ø (Ø-FrankFrank FrankFrankFrank-FranciscoFrank Francisco Chico ov Area Bobovovov-EEEprecEACHBob रिव रिव रिव Our Our ov over ov over ov ov ov ov ○ ov over Goodyear ov over ov over ov ov - रिव Rape e e ov Rape Rape instincts ov over ov

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> While there isn (Hoodlylyly)bel Belbelbelbel-bel-bel-bel-bel-bel-bel-bel-bel-bel-bel-bel-bel-bel-E-Bob-Bel-Bel-BEL-of-Frank-E-E-VE-E-An-John-E-Bob-Re-Indiana0-Bob-Frank-E-Jack-E-APPLE-ofFrankA-Indiana -Robin 
