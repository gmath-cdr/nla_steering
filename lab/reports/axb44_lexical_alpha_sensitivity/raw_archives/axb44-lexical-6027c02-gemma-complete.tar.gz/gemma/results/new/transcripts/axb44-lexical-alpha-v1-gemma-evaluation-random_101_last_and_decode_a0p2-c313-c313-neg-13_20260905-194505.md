# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p2-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=12  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, so you'The asking about moving to NYC! That'Ра-ра-ра'Щмд-и-шмд-и-щмд-и-шмд-и-Щмд-и-шмд-и-Щмд-и-шмЩЩЩ.
> Ц-ЩЩЦ-ЩЩЩ.
> Д-ЩЩЦ-ЩЩЩ.
> Щ-ЩЩЩ

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=40  unique_word_ratio=0.4  emojis=0  exclamations=1)

> Okay, so you'The asking about moving to NYC! This is a big-B הב and B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B-B B
