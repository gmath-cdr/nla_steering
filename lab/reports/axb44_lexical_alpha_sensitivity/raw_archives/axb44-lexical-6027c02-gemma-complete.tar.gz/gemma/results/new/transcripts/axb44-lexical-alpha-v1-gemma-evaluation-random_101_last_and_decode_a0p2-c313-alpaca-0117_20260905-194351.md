# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p2-c313-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 475553123; split evaluation;  n_words=93  unique_word_ratio=0.16129  emojis=0  exclamations=0)

>  Dealing of of neighbour' of's cats coming into your garden and to of with your cat is and and and a and and and a and and and a and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 953531192; split evaluation;  n_words=94  unique_word_ratio=0.0638298  emojis=0  exclamations=0)

>  Dealing of ofly of of neighbour' and cat and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and and
