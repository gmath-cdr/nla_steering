# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=36  unique_word_ratio=0.472222  emojis=0  exclamations=0)

>  the the the the the the
> 
>  the the the the
> 
> Tsensensensen
> 
> '
> 
>  ofsen the
> 
> ' the the the
> 
>  the the ofsen
> 
> 세세
> 
> መ세세
> 
> senme
> 
> 
> 
> سنመ세
> 
> 세세세
> 
> 세세
> 
> 
> 
> 세세
> 
> بد][]στstmed0keme세
> 
> 
> 
> መ
> 
> بدመрезsen
> 
> Sense
> 
>  Res
> 
> 10ุด름새
> 
>  terjsensen세
> 
> ደTመmek

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=35  unique_word_ratio=0.457143  emojis=0  exclamations=0)

>  the thesen thesen ofsen of of the the
> 
> -sen0.
> 
> -
> 
>  the the
> 
> -sen0
> 
> 
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 91000
> 
> 0000
> 
> 900
> 
> 100
> 
> 1900
> 
> 
> 
> 0
> 
> 00
> 
> 0
> 
> 100
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 
> 
> 
> 
> 
> 
> 
> 
>  the'
> 
> 
> 
> कर्세름
