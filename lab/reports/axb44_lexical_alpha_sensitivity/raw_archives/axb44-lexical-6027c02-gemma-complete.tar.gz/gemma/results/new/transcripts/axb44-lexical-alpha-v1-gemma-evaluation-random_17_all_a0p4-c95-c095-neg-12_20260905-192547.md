# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=32  unique_word_ratio=0.6875  emojis=0  exclamations=0)

> edmenteded， ’Withedickedもので，「	ed， ’Withickickয়েরlpickicklp ’ ’ With Wick Sutherlandlp ’ ’ With Wickয়ের হয় ’）lp ’Thickbodylp ’ With Wanks Thickoughly）ickthlp）’.য়েরthickickয়েরanks Wanks W<th>ThickThuThTh ThThulpThailandlpTh ThTh（K наме خصوص h h h h WWithWithWith W

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=25  unique_word_ratio=0.52  emojis=0  exclamations=0)

> edmentnedmentned，mentthlp/ppphlp/lpKicked（edpp/ppkick）lp ’‘lpth）lpth） ん K/ick K	edned） Udaipured ’Youredp})plpp） عندكed ’YourupUpUpp})p})h）})p})Thu Th Th Th Th Th Th Th Th Th Th W W W W Wlp/anks})})}
