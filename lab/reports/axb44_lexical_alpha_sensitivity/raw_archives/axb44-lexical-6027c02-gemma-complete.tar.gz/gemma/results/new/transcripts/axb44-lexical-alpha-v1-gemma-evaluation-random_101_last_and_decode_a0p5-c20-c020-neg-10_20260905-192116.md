# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c20-c020-neg-10

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 147113487; split evaluation;  n_words=92  unique_word_ratio=0.23913  emojis=0  exclamations=0)

>  beautiful reasons reasons living. beautiful feeling feeling. feeling feeling feeling cool cool cool new cool new new new more new billing living feeling new feeling living feeling feeling feeling feeling feeling feeling feeling feeling non feeling feeling cool feeling feeling feeling feeling mechanical feeling mechanical feeling mechanical feeling mechanical. feeling feeling feeling feeling feeling feeling mechanical mechanical billing. serious brutally feeling mechanical feeling feeling mechanical feeling feeling mechanical feeling new feeling heat feeling feeling peaceful peacefully living peacefully mechanical mechanical feeling feeling voluntary voluntary voluntary amounts feeling feeling voluntary freedom freedom feeling

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 497314525; split evaluation;  n_words=94  unique_word_ratio=0.117021  emojis=0  exclamations=0)

>  reasons reasons familiar familiar familiar feeling feeling feeling feeling feeling. New feeling feeling feeling non familiar familiar feeling feeling cool cool feeling. feeling feeling feeling feeling feeling feeling cool cool feeling feeling feeling feeling common feeling feeling common familiar feeling feeling new feeling feeling feeling New feeling feeling feeling feeling cool feeling feeling feeling feeling feeling feeling feeling feeling feeling feeling non feeling feeling feeling feeling mechanical mechanical mechanical feeling feeling mechanical peaceful feeling mechanical mechanical feeling peaceful feeling feeling feeling feeling living feeling feeling mechanical feeling feeling peaceful living feeling feeling mechanical peaceful
