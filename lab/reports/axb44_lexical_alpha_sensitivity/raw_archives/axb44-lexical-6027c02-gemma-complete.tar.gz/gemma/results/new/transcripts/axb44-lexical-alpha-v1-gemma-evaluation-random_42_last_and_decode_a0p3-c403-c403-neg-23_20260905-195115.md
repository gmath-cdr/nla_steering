# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p3-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 1600516177; split evaluation;  n_words=73  unique_word_ratio=0.205479  emojis=0  exclamations=0)

> The Pacific Ring Belt is *al>.
> 
>  Here is />
> 
> * * *
> 
> ## What is >
> 
> * * *
> 
> 24 >
> 
> * * *
> 
>   * *
> 
>  *
> 
> * ~* ~
> 
> * ~ ~ * *
> 
> * ~ ~ * *
> 
> * ~ ~ ~ *
> 
> * ~ ~ * ~
> 
> * ~ ~ * ~
> 
> * ~ ~ ~ ~
> 
> * ~ ~ ~ ~
> 
> * ~ ~ ~ ~
> 
> * ~ ~

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 996453813; split evaluation;  n_words=82  unique_word_ratio=0.195122  emojis=0  exclamations=0)

> The Pacific Ring Belt is *anduso /> > C22 C22 C C C C C C C C C C C C C C C C C C C C C C C C C C C Cp C C C C C C C C C C C Cx C C x Cxx C C x C x Cxx C C x Cx C C x Cxx C C x Cx C C x Cxx C C ~ j ~ j
