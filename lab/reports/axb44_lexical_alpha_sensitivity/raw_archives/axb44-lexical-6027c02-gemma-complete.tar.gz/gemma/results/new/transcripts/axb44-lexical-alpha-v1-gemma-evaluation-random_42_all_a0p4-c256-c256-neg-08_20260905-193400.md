# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=12  unique_word_ratio=0.916667  emojis=0  exclamations=0)

> lI delivering instructions instructions instructionslpοpp lpοplpοοpp pο dοο55555lpοsplp lpο d55555lpοspdlp ==lp  ==d55llllll555llοspοοd555dlplpл55dlisl555

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=11  unique_word_ratio=1  emojis=0  exclamations=0)

> lI burstοοppοpοοpοpοpppppp llpοοp  lllpοsp llllpοspl lllllpοspllpζ lllllp555l crisοοpοοsp dοd d οpοοllllllplplPl
