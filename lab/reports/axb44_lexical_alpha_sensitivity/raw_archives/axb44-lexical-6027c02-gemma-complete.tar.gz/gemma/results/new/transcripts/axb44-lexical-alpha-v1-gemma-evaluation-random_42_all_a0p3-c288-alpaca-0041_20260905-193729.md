# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p3-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> ololololololspan class="olololossosσσისдmacfloattsxltststststststsxxxxmacxxmacxxSusslsssssssssssssssssssssssSSSsssssssssssssssssssssSsssssswsuGroupolololololololololololololololololSSingtstststststststsSSing

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> olololololaololsolsololsololSsSSSSSSSSSSSssSSssSSsSSSSs_sSsassSsSSs_sSos_S_S_S_SS_S_S_S__S_S_S_SS_S_S_S__S_S_S__S_
