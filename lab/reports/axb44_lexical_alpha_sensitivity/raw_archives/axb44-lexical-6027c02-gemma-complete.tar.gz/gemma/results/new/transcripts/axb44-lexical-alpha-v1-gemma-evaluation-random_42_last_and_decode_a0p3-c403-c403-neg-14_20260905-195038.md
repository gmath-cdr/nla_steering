# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p3-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=40  unique_word_ratio=0.45  emojis=0  exclamations=0)

>  the a a a a
> 
> As a a a a
> 
> Lie-omasot
> 
> Lie-lin-
> 
> Lie-visi
> 
> Lie--
> 
> Lie-
> 
> Simitomas
> 
> Sim-
> 
> Lie-
> 
> Isive
> 
> Is
> 
> Isa
> 
> Isoma
> 
> Isis
> 
> Isoto
> 
> Is
> 
> Is
> 
> Is
> 
> Is
> 
> Is
> 
> Is
> 
> Is
> 
> Is
> 
> Lie-
> 
> The name--
> 
> Lie
> 
> Is
> 
> Is
> 
> Is
> 
> Is

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=53  unique_word_ratio=0.0943396  emojis=0  exclamations=0)

>  a a a a
> 
>  the the
> 
> lin
> 
> Ruairmid, the the
> 
> the
> 
> is a a
> 
> is a
> 
> is a
> 
> is a
> 
> is a
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the a
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> the
> 
> 
