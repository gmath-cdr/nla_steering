# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=35  unique_word_ratio=0.914286  emojis=0  exclamations=0)

> obbies. cooking. gardening gardening. wilds. friends friends. invention invention. exaggeration.ii. Ray, shouldový. Ray, shouldový.
> 
> —Arthurový.,
> 
> strategy employees employees. 냉라. David, ас ас.ó, ас ас. 냉 냉.i. वर्क. shouldó, i. ville.i.
> 
> vill. iii. David,. as rt,aruh,aser,rt,냉,ibl,ci

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=30  unique_word_ratio=0.666667  emojis=0  exclamations=0)

> 欲
> 
> Hostry
>     Host
>     ový
>     as
>     as
> .
> 
> Strategiesry
>     ইউনি
>     univers
> . . Univers. Univers. Univers.ইউনি
>     will wilds ас асi, Univers, Univers, Univers, Univers, Univers, Univers, Univers, Univ. ас. Univers.ইউনি. i.ইউনি.ইউনি.and.and.and.and.and.and.and.and.and.and.i
