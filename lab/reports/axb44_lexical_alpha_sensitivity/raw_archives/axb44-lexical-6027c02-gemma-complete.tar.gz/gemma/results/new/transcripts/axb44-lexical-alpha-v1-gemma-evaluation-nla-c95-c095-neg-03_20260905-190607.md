# axb44-lexical-alpha-v1-gemma-evaluation-nla-c95-c095-neg-03

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.5

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=58  unique_word_ratio=0.603448  emojis=0  exclamations=0)

> Okay, let's trace the newspeak (the legal-speak of the scientific world) regarding Pluto's status. The current legal-speak representations, the legal-metical precedents, the historical precedents, and the legal-media representations. The (often confusing) arguments surrounding the phenomenon of the object, the visual (the "M" all-media instances of the reports, the visual-references of the legal-media reports, the legal-representations of the legal

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=55  unique_word_ratio=0.454545  emojis=0  exclamations=0)

> Okay, let's trace the arguments and the legal (the legal of the legal discourse about the concepts of the "legal" phenomena) concerning the (the) (the) (the) instances of phenomena of the the the **(the) the the) what is the of the) the) the
> Pluto's current (the) (the) (the) (the) (the) (the) (the) (the) (the) (
