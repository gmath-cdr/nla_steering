# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=54  unique_word_ratio=0.555556  emojis=0  exclamations=0)

>  this properly  been evaluated but are inherent inherent forest forest properly ivy ivy ivy ivy ivy. ASSESSMENT. 1.. 숲 5pine ivy ivy ivy. 5pine ivy. 5 5pine ivy ivy. છ 5 5pine ivy ivy. ็บ 5 5uran lepine ret f f fica 575 5ele ivy ivy. pine ivy 6• s الأصفر. 5pine. 7• pine

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=41  unique_word_ratio=0.609756  emojis=0  exclamations=0)

>  this�- rel็บ. 7 beenole live live ivy. 1 7 76 7. 667 7. 7. 67. 177 7 7. VII VI 7. ียว 7. 4 ( 7 7. 4 5elepine pine 7. pine. 4 NAS NAS lepine. 4 5uranr f f barnema
