# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=29  unique_word_ratio=0.482759  emojis=0  exclamations=0)

> Edited \\mathbfmathbf$mathbfmathbf$mathbf$mathbf' \\mathbf$mathbf$mathbf$mathbf$mathbf$mathbf$mathbf$mathbf' \\mathbf$mathbf$mathbf' \\mathbf' \mathbf \\mathbf$mathbf$mathbf' \mathbf ' \mathbf$ \mathbf ' \mathbf \\mathbf$mathbf$mathbf T E T \mathbf \\mathbf \\mathbf \mathbf \\mathbf$mathbf \\mathbf \mathbf \\mathbf$mathbf' \mathbf ' \mathbf \mathbf

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=41  unique_word_ratio=0.463415  emojis=0  exclamations=0)

> Breaking �Non ------------------ \\ \\mathbf$mathbf \\mathbf \\mathbf \\mathbf \\mathbf \mathbf\mathbf' Ｍ Ｍ Ｐ Ｐ \mathbf \mathbf' \mathbf \mathbf \mathbf ' \mathbf ' \mathbf \mathbf \mathbf ' \mathbf' \mathbf \mathbf\mathbf Ｍ Ｍ$ Ｔ Ｔ Ｔ$mathbf \mathbf$mathbf' \mathbf$ Ｔ Ｔ \mathbf$ \mathbf' \
