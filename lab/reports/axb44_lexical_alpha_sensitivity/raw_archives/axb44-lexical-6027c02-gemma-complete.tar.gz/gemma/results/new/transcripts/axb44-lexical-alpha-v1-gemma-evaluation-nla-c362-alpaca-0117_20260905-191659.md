# axb44-lexical-alpha-v1-gemma-evaluation-nla-c362-alpaca-0117

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.4

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=58  unique_word_ratio=0.724138  emojis=0  exclamations=2)

> Okay, I can understand how incredibly frustrating and upsetting that is! How can you be *both* a cat and a person *and* a person *of* the cats! (That's the emotion, I'm hearing). It's a situation that *really* does the feelings.  Hearing about what' and how to *with* *that* is... I'm *with* it.
> 
> It's not just the *incident* of

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=54  unique_word_ratio=0.833333  emojis=0  exclamations=1)

> Okay, that's a *very* frustrating and frankly, *emotionally* and *cat* (and **human**!) triggering situation.  I get how I would feel if that was happening.  It's not only the *audacity* of the behaviour, but the potential for **escalation**, **interruptions** to *everything* ( *particularly* if either cat is actually **injured**), and the **discomfort** of the **reactions
