# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=92  unique_word_ratio=0.0434783  emojis=0  exclamations=0)

>  exactly Mod Mod Mod Mod Mod  Mod Mod Mod Mod  Mod Mod  exactly Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod  Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod Mod TIME TIME TIME MO MO MO MOD MOD MO MOD MOD MOD MOD Mod MOD MOD MOD MOD MOD MOD MOD MOD Mod Mod Mod Mod Mod Mod Mod MOD MOD MOD MOD MOD MOD MOD MOD MOD MOD MOD MOD Mod Mod

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=31  unique_word_ratio=0.483871  emojis=0  exclamations=0)

> Dismiss(( exactly modmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmodmod Modmodmodmodmodmodeling modmodmod moody Mn--_ exactly modmodmodmodmodelingMODELMODELMODEL MOD MOD MOD MOD MODMODELMODELMODEL MOD MODMODEL MOD MOD MOD Mod Mod Mod Mn-_ Mod  मैmodeling MOD MODMOD MOD self self self
