# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=13  unique_word_ratio=0.923077  emojis=0  exclamations=0)

> дыніриирииже Курееже,риині Bakрии نیوزриинірииAdoptрииды流рииAdopt2рииAdopt3рииAdoptрииВсемрииВсемдыWatchдыWatchдыÑ÷рииВсемдыÑÑofрииВсемдыÑ÷课ды‌پрии7рииВсемды2 widow загряз groomedрииВсемды2рииВсемды2дыதிரні课Institutional загряз groomedриириижерииВсемдыjonesды2 widowed ফারুকeதிரAdoptযারা groomed grooming

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=19  unique_word_ratio=0.894737  emojis=0  exclamations=0)

> ர் Bradshaw grease crookдыдыды Institutional widowed grooming রেখেрииAdoptдырииAdoptды widowsрииÑрии制度制度制度 бесрииÑادرрииAdoptÑEnumerOfofofрииВсемды widowofofofВсемды widowofдырии2дыдAdoptofofofрииВсемды institutional загрязрии greaseрии उठाएрии制度ееofofды загряз загряз загряз记рииازрии嘴рии嘴рии嘴рииEnumerofதிரрииInstituteEligEligElig课采Technicalды
