# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c491-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ууssssysуукsукsукsукsумомомомомомомомомомомомоמומומווסaaaaмккмомомомомомомомомомомомомомомомомомомошмомомомомомомомомомомомомомомоიуумомомомомомомомомомомомомо

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> уsThisssssмуss最sуумоумоумоумоумоумок latterуумоveryумомомомомомоמויإم﻿умомомомоумомомоמו Opinionsучмомомомошшмомомомошмомомомочмомомомомокшшмомомомомомомомомомомомомомомо
