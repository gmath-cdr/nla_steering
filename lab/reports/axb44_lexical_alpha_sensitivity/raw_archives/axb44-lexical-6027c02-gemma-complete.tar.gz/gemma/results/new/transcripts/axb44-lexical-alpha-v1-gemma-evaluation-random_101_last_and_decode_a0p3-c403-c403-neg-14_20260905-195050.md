# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=37  unique_word_ratio=0.324324  emojis=0  exclamations=0)

> Paila 0 1FG 2FF 2SC 2SC SC SC SC SC 0 2FF 2FF 2SC 2SC 0 2FC 2NC 2NC 1SC 2NC 2NC 2NC 2SC 2SC 2SC 2SC P 2NC 2NC NC NC NC 2NC 2NC 2NC 2

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=48  unique_word_ratio=0.270833  emojis=0  exclamations=0)

> Pelis ick KFI Scenic 1 2 3 4 0 2 2 0 0 2 2 CC 0 2 2 0 0 2 I 2 0 0 2 2 0 2 2 0 0  P 2 2 0 2 2 0 2 2 0 0 2 2 NC 2
