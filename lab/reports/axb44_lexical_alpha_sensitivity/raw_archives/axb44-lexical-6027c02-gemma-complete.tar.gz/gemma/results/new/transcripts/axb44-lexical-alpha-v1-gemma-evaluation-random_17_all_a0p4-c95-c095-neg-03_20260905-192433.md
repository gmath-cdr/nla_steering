# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> BSBSVFontWilfontFontvFontVFfontMSvFfontµµµµµWilfontfontfontîîµµŵvµµµvMµBfontfontfontBBfontBVµµfontVMµµKKµкµµVMµKKKKKKKK­µµµvµMWWwwwVfontfontfontBKKMSµµKKKKKVMµµB

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> BForîBMSBBSFont fontfontfontfontfontfontfontfontfontFFont fontfontfontfont'BfontfontfontBvî'BSVMµµÀ­µµfontfontfontFfontfontBBfontBBGµµMSµAFBBSBBSB'BfontfontfontAnBirfontfontfont'µAMSµµMµKµµBSWvµµfontffontfontBVM
