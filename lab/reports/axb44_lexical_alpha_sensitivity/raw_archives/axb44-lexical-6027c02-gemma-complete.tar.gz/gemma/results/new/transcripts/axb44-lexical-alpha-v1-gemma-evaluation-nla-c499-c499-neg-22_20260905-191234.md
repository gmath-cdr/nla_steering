# axb44-lexical-alpha-v1-gemma-evaluation-nla-c499-c499-neg-22

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.4

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=29  unique_word_ratio=0.758621  emojis=0  exclamations=0)

> A **Basset Hound** is bigger than a Beagle.
> 
> Here's a comparison:
> 
> *   **Beagle:**
>     *   Dog-sit Memorial.com: 11.0–16.0 (1/2) - 15.0 × 16.0
>     *   Sitting: 11.0–16.0 (1/2)
>     *   Weight: 11.5

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=33  unique_word_ratio=0.69697  emojis=0  exclamations=0)

> A **bassett** is bigger than a beagle.
> 
> Here's a quick comparison:
> 
> *   **Beagle:**
>     *   Dog parties of 10-15 (20-30.4cm)
>     *   Warming of 10-13 (22.9-33).
>     *   Mood : 20-30
> 
> *   **Basset:**
>     *   Dog parties
