# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=83  unique_word_ratio=0.240964  emojis=0  exclamations=1)

>     careers t Enere in T ** Fox T Ex Ex Ex F F  Fox  E Fox T H va F  t t  tiro d in E SEM P P  E P ! E E E E E E E E Lyn Lyn Lyn E t t t  in j t In E In In In In In In t t E s In In In In In PDF PDF PDF In In In In P  t t In in In In in t

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=93  unique_word_ratio=0.150538  emojis=0  exclamations=0)

> U Universal U U Pl Pl Pl Pl E W L W L E  Lyn lyn lyn mine in mine mine Lyn lyn in lyn lyn In In In sulyy mine In In In Lyn In In In In In In Lyn In In In in lyn In In In In In mine Lyn In In In In In In In lyn In In In In t t sem sem sem mine lyn in mine In In In In URL URL URL URL URL URL va t in in In in t t 
