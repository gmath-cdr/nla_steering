# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=47  unique_word_ratio=0.0638298  emojis=0  exclamations=0)

> 
> 
> t
> 
> 
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -L
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=45  unique_word_ratio=0.0888889  emojis=0  exclamations=0)

> plpl
> 
> 
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -eli
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -ElEl-
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> 
