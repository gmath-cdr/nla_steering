# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=65  unique_word_ratio=0.138462  emojis=0  exclamations=0)

> Âœ. ** utility. **
> 
>  ** utility. ** ** low = low utility utility. **
>  ** utility. ** ** diverse = utility. **
> 
>  **. ** ** Utility ** **. **
>  **. ** ** utilities = ** **. ** **. ** **. **
>  **. ** **. **
> 
>  ** ** **. ** ** **. **
>  **. ** **. **
> 
>  **. ** **. ** **. ** **. ** **

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=67  unique_word_ratio=0.253731  emojis=0  exclamations=10)

>  ** utilities ). utility —. install utility utility ! odd utility ! utility !! arrin — arrin !! arrin !! arr. arr. arr **
> 
>  **.. arr. arr **
> 
>  **. arr ... arr **
> 
>  **. !! **
> 
>  **. **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
> 
>  ** . **
>  **. **
>  **. **
> 
>  **
