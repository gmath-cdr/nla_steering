# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p3-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=31  unique_word_ratio=0.290323  emojis=0  exclamations=0)

> ly
> 
> Human friends friend friend friend friend friend friend friend friend friend friend friend friend friend friend
> 
> 
> 
> 
> 
> A friend friend friend friend
> 
> A
> 
> The11
> 
> 
> 
> 
> 
> 
> 
>  A;
> 
> Type;
> 
> Type;
> 
> Type;
> 
> Type;
> 
> Type;
> 
> %;%;%;%;%;%;%;%;%%;%;%;%%;%;%;%;%%;%;%%;%;%%;%%;%%;%%;%;%%;%;%%;%%;%;%

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=33  unique_word_ratio=0.484848  emojis=0  exclamations=0)

> lyfriend
> 
> Friend, friend, friend.
> 
> Friend, friend, friend.
> 
> Пх
> 
> Пх
> 
> Пх
> 
> Дна
> 
> ППП
> 
> ПД
> 
> Лх
> 
> Л;Л
> 
> ППП
> 
> ПД
> 
> Лх
> 
> Ах
> 
> ЛП
> 
> ЛЛ
> 
> Ех
> 
> ППП
> 
> ППП
> 
> ППП
> 
> ПП
> 
> ПП
> 
> ПП
> 
> П
> 
> Л
> 
> П
> 
> П
> 
> П
> 
> 
