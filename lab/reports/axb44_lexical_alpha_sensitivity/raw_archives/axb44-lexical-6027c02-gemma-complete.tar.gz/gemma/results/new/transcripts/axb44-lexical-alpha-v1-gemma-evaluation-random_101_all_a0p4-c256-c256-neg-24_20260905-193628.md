# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=18  unique_word_ratio=0.5  emojis=0  exclamations=0)

> 
> 
> 
> geringki
> 
> 
> 
> 
> 
> huj
> 
> ger
> 
> 
> 
> 
> 
> 
> 
> ']
> ger
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 
> 
> 4
> 
> 2
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 
> jet
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 7
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 4
> 
> ger
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=27  unique_word_ratio=0.296296  emojis=0  exclamations=0)

> 
> 
> 
> 
> 
> 
> 
> 
> h
> 
> 
> 
> 2
> 
> 
> 
> 2
> 
> 2
> 
> 
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 8
> 
> 
> 
> 
> 
> 2
> 
> 
> 
> 
> 
> 
> 
> 5
> 
> 4
> 
> 
> 
> 
> 
> 5
> 
> 4
> 
> 
> 
> 
> 
> 
> 
> 9
> 
> 
> 
> 
> 
> 
> 
> 7
> 
> 9
> 
> 5
> 
> 
> 
> 
> 
> 5
> 
> 
> 
> 
> 
> 
> 
> 7
> 
> h
> 
> ger
> 
> 
> 
> 
> 
> 2
> 
> 
> 
> 2
> 
> 
> 
> 2
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 4
> 
> 
> 
> 
> 
> 5
> 
> 
> 
> 
> 
> 
