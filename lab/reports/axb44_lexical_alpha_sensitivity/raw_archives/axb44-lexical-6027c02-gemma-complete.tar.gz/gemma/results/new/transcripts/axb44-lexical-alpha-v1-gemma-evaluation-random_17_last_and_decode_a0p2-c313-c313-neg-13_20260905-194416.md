# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p2-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=52  unique_word_ratio=0.192308  emojis=0  exclamations=0)

> Okay, so you are about to aboutally sort of aboutally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sortally sort

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=95  unique_word_ratio=0.0631579  emojis=0  exclamations=0)

> Okay, so you are about to about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about about
