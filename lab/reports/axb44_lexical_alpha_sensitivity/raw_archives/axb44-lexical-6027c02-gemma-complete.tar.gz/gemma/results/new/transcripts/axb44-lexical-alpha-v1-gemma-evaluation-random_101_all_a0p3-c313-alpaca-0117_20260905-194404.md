# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c313-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 475553123; split evaluation;  n_words=11  unique_word_ratio=0.545455  emojis=0  exclamations=0)

>  to__________________________________________________
> _________�____
> ___
> __
> 
> to________
> _
> _
> _
> _
> _
> _
> 

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 953531192; split evaluation;  n_words=13  unique_word_ratio=0.384615  emojis=0  exclamations=0)

> \_____________________________\___________
> 
> _____________咪________
> 
> __________
> _
> _
> _
> _
> _
> _
> _
> 
> _____
> 
> _
> _
> 
