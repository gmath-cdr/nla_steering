# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p15-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=48  unique_word_ratio=0.1875  emojis=0  exclamations=0)

> A **bas ​​b ​​asse ​​e ​​e ​​er ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​e ​​️️️  ​​ ​​ ️  ​​ ️  ​​ ️  ​​ ️  ​​ ️  ​​ ️  ​​

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=3  unique_word_ratio=1  emojis=41  exclamations=0)

> A **bas ​​b️️🐕️🐕️🐕️🐕️🐕️️️️🐕️🐕️🐕️🐕️🐕️️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐶️🐕️🐕️🐕️🐕️️️️🐕️🐕️🐕️🐕️🐕️️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕️🐕
