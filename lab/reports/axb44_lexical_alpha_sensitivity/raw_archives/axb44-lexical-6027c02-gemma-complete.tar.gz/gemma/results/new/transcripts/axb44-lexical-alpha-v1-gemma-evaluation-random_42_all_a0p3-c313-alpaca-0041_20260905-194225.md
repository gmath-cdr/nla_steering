# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p3-c313-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0041: How can I  use my phone less?**  (sample 1896497915; split evaluation;  n_words=88  unique_word_ratio=0.465909  emojis=0  exclamations=0)

>  systemic systemic systemic ssürücam çık çık çık sm Classes classes Classes s réel réel ré réel x instrumental instrumental mbr Instrumental entend s rum musicals musicals‌ی instrumental instrumental instrumental s réel r Compound compound compound mounts sm spasms x cytot s recordings recordings Classes s recordings s instrumental h় files s PDFs PDFs PDFs s PDFs tóp té r instrumental r macro macro macro Macros s PDFs systemic systemic systems PDFs t t camb escribe learnings learnings’ôt effectivement實際 hữu té rf té சேர்ந்த கற்க vẫn கற்க vẫn bútり

**c313--alpaca-0041: How can I  use my phone less?**  (sample 91529697; split evaluation;  n_words=84  unique_word_ratio=0.464286  emojis=0  exclamations=0)

> 錄器 systemic systemic systemic financial systemic instrumental instrumental instrumental recordings recordings recordings recordings systemic systemic systemic systemic systemic systemic‌. bl bl bli meats meats meats meats meats anticoag meds meats meats meats tóp tipo PDFs PDFs tóp‌. té கற்க கற்க h ப h bl basal textos tê hú rose riscos systemic systemic s baz伍鳥についてもりについてもりのみについてもり té s baz té kaca té t rose rg cam vm pg hú hú té té s baz té মেয় の cytot cytot cytot cytot சேர்ந்த 粉 rose சேர்ந்த vm
