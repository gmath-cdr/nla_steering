# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p2-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=68  unique_word_ratio=0.75  emojis=0  exclamations=1)

>  Okay, let' heat get your ( and your house!) by tackling summer heat. Here are a few ways to keep your house cool throughout the summer. I categorize by how difficult/ expensive they are.
> 
>  ** Low Effort / Low Cost ( No more than your effort and a few coins )
> 
>  * **   Encap Apply Gel/ Ir all     Qual   al .   All   All.   All.   All.   All.   All.   All.

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=60  unique_word_ratio=0.733333  emojis=0  exclamations=0)

>  Okay, let' heat get your house by tackleing your cooling. Here are a few ways to keep your house cool during the summer, from simple and cheap to more investmented, categorized by how difficult they are to implement.
> 
>  ** **
> 
>  ** Low Effort / Low Cost ( No more than a few hours of your time ) **
> 
>  * **                                                  
