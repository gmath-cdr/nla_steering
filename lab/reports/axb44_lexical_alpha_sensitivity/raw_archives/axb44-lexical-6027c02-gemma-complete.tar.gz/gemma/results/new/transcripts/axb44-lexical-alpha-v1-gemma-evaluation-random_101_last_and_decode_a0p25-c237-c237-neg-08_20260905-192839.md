# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> Sydney'it extensivethings ititjetjetjetjetunremreasondjetunregrajetunrjasitunrusauesitunb.7busitunbur7busitunbur7busit.7.7.7.7.7.7.7.7.7.7.7.7.7.1267.7.7.7.7.7.7.7.67.7.

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Sydney'the abeautifulthisoneabovedutydutydutyDUTDUTDUTDUTDUTSUHTNH76787878787677877677877676787767767767778776776776777877677677677787767767767
