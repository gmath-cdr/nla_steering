# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=32  unique_word_ratio=0.21875  emojis=0  exclamations=0)

> OkayMarMar
> 
> TheSunSS
> 
> Okay
> 
> TheSunS
> 
> TheSun
> 
> The SunS
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=33  unique_word_ratio=0.212121  emojis=0  exclamations=0)

> OkayMarMar
> 
> OkayMar
> 
> Okay
> 
> Okay
> 
> TheSunSS
> 
> TheSun
> 
> The
> 
> Sun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> The
