# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p2-c288-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1940193698; split evaluation;  n_words=13  unique_word_ratio=0.769231  emojis=0  exclamations=0)

> Okay, the ol' resident-but-the-other-resident-is-a-*other_theile_epidragon-being-a-blBlBlBlBl-being-a-blBl-being-_ixxxixixiixxixixiixxxixiixxния I's the **bestxixixixixiixxixiixxния I** being a borubгенннии
> 
> Okay, the

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 382759914; split evaluation;  n_words=72  unique_word_ratio=0.125  emojis=0  exclamations=0)

> Okay, the resident-vs-the-visitor-being-better-off-being-separated is a *bl*хеbouдо theраз **the the the the the the ** the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the the
