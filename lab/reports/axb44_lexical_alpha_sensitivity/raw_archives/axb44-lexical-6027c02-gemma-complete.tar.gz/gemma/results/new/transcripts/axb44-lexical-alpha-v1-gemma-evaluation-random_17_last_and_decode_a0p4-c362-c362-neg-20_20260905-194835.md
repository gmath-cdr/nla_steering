# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=48  unique_word_ratio=0.395833  emojis=0  exclamations=0)

>  New nerve inhibitors nerve inhibitors nerve back nerve nerve nerve nerve       ` acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture acupuncture back acupuncture nerve nerve compare nerve regenerate regenerate regenerateمکملمکمل vitamins acupuncture acupuncture涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅مکمل ph acupuncture acupuncture睫睫睫睫辟法 背 背 popular popular nerveمکملمکملمکمل陪مکمل acupuncture ves nerveمکملمکملمکملمکملمکملمکمل哇 ves nerve涅مکمل陪مکملمکمل

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=52  unique_word_ratio=0.403846  emojis=0  exclamations=0)

> New nerve nerve nerve nerve
> New nerve nerve nerve. nerve
> Off nerve ves nerve nerve close nerve nerve spirit nerve roof nerve reef nerve reef nerve nerve nerve setting nerve nerve setting where nerve nerve nerve nerve ves nerve ph nerve ph education ph辟涅涅辟涅 ph border涅مکمل涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅涅ทร huntمکمل মাছ acupunctureمکمل涅‌‌‌‌‌ অসংখ্য huntsمکمل涅涅涅涅مکمل measureمکمل涅مکمل
