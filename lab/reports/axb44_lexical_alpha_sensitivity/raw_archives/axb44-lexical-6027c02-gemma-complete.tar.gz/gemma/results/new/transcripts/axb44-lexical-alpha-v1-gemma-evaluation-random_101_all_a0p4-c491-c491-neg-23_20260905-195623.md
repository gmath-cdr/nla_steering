# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=86  unique_word_ratio=0.127907  emojis=0  exclamations=0)

>  Hel পেন pen pen pen pen পেন পেন পেন pen pen পেন পেন পেন পেন পেন পেন পেন পেন পেন পেন পেন EP pen পেন পেন পেন পেন পেন EP পেন পেন EP pen পেন EP pen EP পেন পেন EP pen EP pen EP পেন EP পেন EP পেন EPcourse عد عد عد عد عد عد عد عد عد عد عد عد عد عد無GG পেন পেন EP exoner عد عد عدcourse পেন পেন EP pen EPcourse পেন EPcourse عد عدcourse পেন EPcourse錢 запи পেন EP

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=56  unique_word_ratio=0.178571  emojis=0  exclamations=0)

> Чтоν পেন পেন পেন পেন pen pen পেন পেন পেন pen pen পেন পেন পেন পেন pen পেন পেন পেন পেন পেন পেন পেন পেন পেন পেনcourse tingling tingling pen পেন pen পেন পেনcourse pen পেন পেন FAEXEXEXEXEXEXIEXEXEXEXEXEXEPEAEP পেন পেন পেন pen পেনcoursecoursecoursecoursecoursecourse পেন পেন পেনcoursecoursecoursecoursecourse পেন পেন পেন পেনcourse পেন পেন عد無 পেন পেন EPﻰ錢放coursecoursecoursecoursecourse
