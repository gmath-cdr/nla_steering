# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

>  Being 
> 
> 
> 
>  
> 
>  
> 
> 
> 
>  
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
>  
> 
> 
>  
>   
> 
>  
>  
> 
>  
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 
>  
>  
> 
> 
>  
> 
> 
>  
> 
> 
> 
>   
>    
>  
> 
>  
> 
>   
> 
>   
> 
> 
>  
> 
> 
>  
>  
>  
>  
> 
>  
> 
>  
>  
>  
>  
>  
> 
> 
> 
> 
> 
> 
> 
> 
> 
> 

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=8  unique_word_ratio=0.125  emojis=0  exclamations=0)

>  So
> 
>  So
> 
>  So
> 
> So
> 
>  So
> 
> So
> 
>  So
> 
> So
> 
>  
> 
> 
> 
> 
> 
>  
> 
> 
> 
>  
>  
>  
>  
> 
> 
> 
> 
> 
> 
> 
>  
> 
> 
> 
> 
>  
> 
> 
>  
> 
> 
> 
> 
>    
> 
> 
> 
> 
> 
> 
>   
>   
> 
> 
> 
>  
> 
> 
> 
> 
>  
> 
> 
>  
> 
>  
>   
>  
> 
> 
>   
> 
> 
> 
> 
>  
> 
>  
> 
> 
>   
> 
> 
>  
> 
> 
>  
