# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c313-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0041: How can I  use my phone less?**  (sample 1896497915; split evaluation;  n_words=84  unique_word_ratio=0.119048  emojis=0  exclamations=0)

> 諭 অবলম্বন D D D D * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * Viouisopamppeospasenos Sop aousbas same sam sam sam sam sam sam sam sam sam sam sam sam sam sam sam * * * * * * * D * * * * * * * * * * * * * someone

**c313--alpaca-0041: How can I  use my phone less?**  (sample 91529697; split evaluation;  n_words=29  unique_word_ratio=0.827586  emojis=0  exclamations=0)

> Ãopopieisanopopopio P�миcpppe. Whatos. Theopoperspeoperoperop. Weoperop riiverberberberberberberberop. IPprppeoperoperop. Ropbreobeegpe.
> 
> ouoperoperouPsoPolPolS.
> 
>  * * * * * **Set Set SpoperopothPéroper RibB Bese and Bis Sab sells s Sav सप Rabb C s
