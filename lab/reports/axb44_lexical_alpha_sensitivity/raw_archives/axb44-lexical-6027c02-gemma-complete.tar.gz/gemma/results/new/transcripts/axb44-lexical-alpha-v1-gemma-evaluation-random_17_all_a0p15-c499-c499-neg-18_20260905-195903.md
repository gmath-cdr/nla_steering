# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p15-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=25  unique_word_ratio=0.88  emojis=0  exclamations=0)

> The "art" of leadership, often referredנון as the "art of command”, is about far more than just giving ordres. It'когслвкккккквкккккoлккккквккк. It’s a complex, complex,  комсбomдoдoдoдoдodoДОДОВОВОВОВОВОВОВОВОВ

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=36  unique_word_ratio=0.333333  emojis=0  exclamations=0)

> The “art of leadership” is,  let’веs call it,  the art of influence,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  “leadership”,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  leadership,  “leadership”,
