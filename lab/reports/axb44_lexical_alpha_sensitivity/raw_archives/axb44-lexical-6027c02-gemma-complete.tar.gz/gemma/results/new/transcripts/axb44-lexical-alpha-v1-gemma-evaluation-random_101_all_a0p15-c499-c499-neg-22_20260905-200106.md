# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p15-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=45  unique_word_ratio=0.2  emojis=0  exclamations=0)

>  a **hare hare hare has thes thes thes thes thes thes thes thes thes thes thes thes thes the.
> 
> The Hare Hare Hare has thes the.
> 
> The Hare Hare Hare.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The. a.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The.
> 
> The.

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=44  unique_word_ratio=0.454545  emojis=0  exclamations=0)

>  a **bary barks'res are generally as-wein,. They are broader and lower than a Beagle.</b>
> 
> Here's a of the,)s P):) ( ( ( ( '"'' '"' '"' '"' '"' '"' '"' '"' '"' '"' '" '" '" '" '" '" '" '" '" '" '"
