# axb44-lexical-alpha-v1-gemma-evaluation-nla-c313-c313-neg-23

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.2

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=57  unique_word_ratio=0.842105  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and traditional snowboarding. Here's a comprehensive explanation, covering the equipment, the logistics, the experience, and the cost.
> 
> **1. The Core Concept: Accessing Backcountry Terrain**
> 
> *   **Snowboarding:** Primarily focuses on lift-accessible terrain within established ski resorts. You rely on the infrastructure (lifts, grooming, patrolled areas) for access.
> *   **Splitboarding:**  Is

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=55  unique_word_ratio=0.890909  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and traditional snowboarding. Here's a comprehensive explanation, focusing on the key aspects:
> 
> **1. The Core Concept: Accessibility**
> 
> *   **Snowboarding:** Designed for lift-served areas. You ride downhill, utilizing the infrastructure of a ski resort (lifts, groomed runs).
> *   **Splitboarding:**  The goal is to **access *un-lifted* backcountry terrain**.  It'
