# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=38  unique_word_ratio=0.710526  emojis=0  exclamations=0)

>  this one demonstrates what type super many people clearly-SSNM, which is the., he is., he(, the., he(, the, he., he, zz,, like he,(, the, he,(, be,, be, he(,  namNA, z,,, be(, renewed(,(,(, he., he, he., he, he, z,,,

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=39  unique_word_ratio=0.641026  emojis=0  exclamations=0)

>  this(, one, one( type(, be namnam_((( far, far far far far far far. name(, be ze((( far, far, far. PAN((( he((( far, zbe( he((( far, z ((, be. be. be. Z ((( be(  c( he.(: :, be.(:(, be.((, be.(,
