# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p25-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okaythewholebeingyoubeingbeing.Youthatentirebeing.Abeingthatbeingabeing.Beingabeing.Okaythewholebeingyoubeingbeing.Youaregoingtobebeingabe.Youaregoingtobebeingabe.Youaregoingthewholebeing.Youaregoingthewhole.Youaregoing.Youare.Isthatgo.Isthatgoing.Isthatgoing?Youaregoing.Isthat.Isthatgoing.Isthatgoing

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okaythetheyouyouyouyouyouyouyouyouwanttoyouwanttotoyouyouyouaaaaaa.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a.a
