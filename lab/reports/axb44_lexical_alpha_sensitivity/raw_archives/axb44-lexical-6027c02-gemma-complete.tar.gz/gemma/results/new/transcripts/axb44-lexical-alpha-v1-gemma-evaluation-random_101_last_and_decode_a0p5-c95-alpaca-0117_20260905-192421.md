# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=57  unique_word_ratio=0.175439  emojis=0  exclamations=0)

> ke 
> 
> ke
> 
> ke
> 
>  go go go go go go go go go go go go go n N N N N N N N N N N N N N N N N N N N N Non Non N N N N N N N N N Levels Levels Tera Tera Ow Ow Owermanberry tubo Teraburgermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanerman

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=11  unique_word_ratio=1  emojis=0  exclamations=0)

> kek
> 
> ke
> **ke �keke  гоereermanke ermanke Nereere roereke gogo gokeermanermanermanxieermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanermanerman гоermanermanermanermanermanermanermanerman
