# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c403-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 29478530; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Keeped-Delay-UpdateUpdateHelped UpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdate
> ItReplaceauxauxaux
> It'

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 160233634; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ited-forget-Myed-orderedUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateDualUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdateUpdate
