# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=64  unique_word_ratio=0.109375  emojis=0  exclamations=0)

> Ph Ph Ph   Ph Q Q Q Q Q  Q  Tall tall tall tall  mi  ไ Q Q Q Q  Q Q  Q  Q   Q Q Q Q Q Q Q   Q Q K K K  K K K K  Q Q Q Q  Q Q Q Q Q Q Ph Ph  Q Q Q Q Q Q  Q Q Q         M M M   

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=67  unique_word_ratio=0.104478  emojis=0  exclamations=0)

> PhotPh P  Q M M M  听听   图 Q Q Q Q Q Q Q Q Q Q Q Q Q Q Q Q    Q Q Q Q Q Q  Q Q  Q Q Q  Q Q Q Q  Q Q Q Q  Q Q         Q Q Q K  Q Q Q Q Q Q Q Q Q  Q Q Q  K  Q Q Q   Q Q
