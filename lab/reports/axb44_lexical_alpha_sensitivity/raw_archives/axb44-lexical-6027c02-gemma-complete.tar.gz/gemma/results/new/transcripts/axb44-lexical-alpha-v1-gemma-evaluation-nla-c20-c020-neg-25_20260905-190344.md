# axb44-lexical-alpha-v1-gemma-evaluation-nla-c20-c020-neg-25

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.5

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=93  unique_word_ratio=0.215054  emojis=0  exclamations=0)

> Okay, let's research the current understanding of the efforts to the assessment of the research to understanding the current methods of research for the evaluation of the efforts in understanding the studies of the studies of the investigations of the assessment of the reports of the studies of the evaluation of the areas of research to assess the studies of the efforts in investigating the areas of research to studies of the areas of investigations to the reports of the studies of the evaluation of the reports of the studies of the areas

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=93  unique_word_ratio=0.290323  emojis=0  exclamations=0)

> Okay, let's research the studies and efforts to determine the research into the concerns of studies around the matter of understanding the study of the investigation of determining the investigations of the research efforts to study the areas of potential areas of efforts to understand the studies related to the areas of approaches to areas of concern to the concerns of the studies related to the evaluation of the concerns of areas of investigations of the concerns of approaches to areas of studies related to the methods of concern of efforts to study
