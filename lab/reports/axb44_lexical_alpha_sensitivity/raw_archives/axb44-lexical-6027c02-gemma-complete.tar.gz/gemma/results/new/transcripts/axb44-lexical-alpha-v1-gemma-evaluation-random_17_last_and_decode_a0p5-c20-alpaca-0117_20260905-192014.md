# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c20-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1590581376; split evaluation;  n_words=13  unique_word_ratio=0.461538  emojis=0  exclamations=0)

> ieieieie
> ieieieieieieieieieieieieieieieieieieie-ieieieieie-ieie-ieie---ieie--ieie--ieieieie
> 
> ieieieie-ie----------

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1229758752; split evaluation;  n_words=10  unique_word_ratio=0.3  emojis=0  exclamations=0)

> ieieieie
> ieieieie
> 
> 
> ieieieie
> ieieieie
> 
> 
> ieieieie
> ieieieie
> ieieieie
> ieieieieie
> ieie
