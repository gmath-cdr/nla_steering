# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p15-c499-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 442813485; split evaluation;  n_words=7  unique_word_ratio=1  emojis=0  exclamations=0)

> This is a tricky and unfortunatelynary Disnichi-stabag-ine-beseiesau-chago-un-imp-ump-ambo-gyn-uta-pam-un-I-Gosh-pops-paw-me-a-trenchcoat-and-a-glass-oseau-and-a-nose-clip-and-a-cup-of-regency-mane'elle-and

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1202891609; split evaluation;  n_words=11  unique_word_ratio=1  emojis=0  exclamations=1)

> This'Cats-Neighn-Scie-PatPat!' Here's a breakdown of strategies to discourage your neighbour'ights-Cat-Pho-Paw-PatPat-Ical-FactFact-Fact Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-Fact-From-Spillons-TragTrag-Trag-Tragic-Tragic-Tragic-Tragic-
