# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p5-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=51  unique_word_ratio=0.333333  emojis=0  exclamations=0)

>  " un un 
> 
> 
> 
>   MO MO 
> 
>  Even better can all can can 
> 
>  
> 
>  
> 
>   Oh oh one one 
> 
>  Or un
> 
>  on on one
> 
>  
> 
>   lead lead
> 
>   will can can can 
> 
> S or 
> 
>  
> 
>  
> 
>   Even or even can can  All or All on on 
> 
>  
> 
>   John John all all All all  on on
> 
>   
> 
>  O or bent bent 
> 
>  Or 

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=57  unique_word_ratio=0.280702  emojis=0  exclamations=0)

>   ​​  ​​ 
> 
>  GMOMOMOMO
> 
>  
> 
>  
> 
>  
> 
>   MO
> 
>   ** All becomes one now MoO MOO  MO MOO \ --  -  - - --  -- -- - - - 
> 
>  
> 
>  
> 
>   All becomes one on one on one 
> 
>  
> 
>   All or All All All or or or --  one or one or one or one or one or even or even
> 
>  And all all all
