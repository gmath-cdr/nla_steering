# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Okaylyanan'****atèan***clèanc****a***atoti”**atèan***anc****a***atoti****átààxti***átatyfèanc****a***I***ánáltag1an91an1anc****a
> 
> Foŕan1an1wias15wAgIwagiiwadiatwagéancI

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> ly************************************************************************************************************************************ancananardanHii˶99**9ánw (
> 
> OfAgwiiów (**‘
