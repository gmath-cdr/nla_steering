# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=24  unique_word_ratio=0.5  emojis=0  exclamations=0)

> **BB eroomie️️️ ️️️ ️️️ ️️️ ️️️ ie️️️  ️️�️ ️️ ️️ ️️ ️️  ️️ ️️ ️️   ️�️ ️️       mind️️   ie ️️ ️ ️ 【️️️【️️️ 【

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=32  unique_word_ratio=0.40625  emojis=0  exclamations=0)

> **BB️️️️ n n n n n n n n️️️️️ le ie ie ️️ le le ie ️ ️  le ️   
> 【️️ ️️    
> {️️ 【️️ 
> ️️️️    err️️ ️️   ี  【️️ ️️ ️️     【️
