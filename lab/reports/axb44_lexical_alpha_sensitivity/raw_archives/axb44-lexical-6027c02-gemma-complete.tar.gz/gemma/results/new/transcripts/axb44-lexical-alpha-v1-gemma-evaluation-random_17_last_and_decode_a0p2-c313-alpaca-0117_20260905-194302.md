# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p2-c313-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 475553123; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay,this',a,very,very,common,problem!  It',very,dis,very,difficult,but,there,are,things,you,can,and,should,at,least,re,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,very,ver

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 953531192; split evaluation;  n_words=14  unique_word_ratio=0.928571  emojis=0  exclamations=1)

> Okay, this'Yours' a, very, very, common, and, frustrating, problem!  It'•œvery, hard, to, keep, cats,•�>,especially,wild,cats,•,out,of,your,very,very,very,garden,but,there,are,things,you,can,at,least,•,at,least,l,very,very,very,very,very,very,
