# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=51  unique_word_ratio=0.431373  emojis=0  exclamations=1)

> Okay, let me苄k know how awesome is it when I know how on off of own know know dick dick dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick Dick으h!
> 
> 
> 
> <b>1. ProxJe Ore</b>
> 000
> 
> 
> 
> <b>25858083555858355</b>
> 1003522228

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=16  unique_word_ratio=0.4375  emojis=0  exclamations=0)

> Pretty pretty prett prett Pet Me Panda Panda Panda Panda Panda Panda Panda Pay Pet Pet22533333333333333333333333333225333333333333333333333333333332253333333121213553
