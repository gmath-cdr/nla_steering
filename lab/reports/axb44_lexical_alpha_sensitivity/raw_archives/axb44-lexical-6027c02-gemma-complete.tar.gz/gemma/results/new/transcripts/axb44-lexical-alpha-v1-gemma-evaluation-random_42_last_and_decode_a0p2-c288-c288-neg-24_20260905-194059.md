# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p2-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=48  unique_word_ratio=0.125  emojis=0  exclamations=0)

> Okay, let's absolutely bomb-- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end- end

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=68  unique_word_ratio=0.558824  emojis=0  exclamations=1)

>  Okay, summer's heat can be brutal! Here's a bunch of ways to cool your home, broken down by budget and effort. I's break it up sections: **' ^ ^ GO--d-d-' ,  `$ -> -> -> -> -> -> -> -> , and ^ ^ end end end end end. Grab you've- -> -> -> -> -> -> -> . 
>   ` ` ` ` ` ` ` ` `
