# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=11  unique_word_ratio=0.818182  emojis=0  exclamations=0)

> Sydney is aeinainedplex place with aesinainedross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-ross-Ross-Ross-Ross-Ross-Ross-Ross-Ross-Ross- Ross-Ross-Ross-Ross-Ross-Ross- Ross-Ross-Ross- Ross-Ross-Ross- Ross-Ross-Ross- Ross-Ross-Ross

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=35  unique_word_ratio=0.285714  emojis=0  exclamations=0)

> Sydney is aeinainedplex place with aesinainedinedinedinedinedinedined
> 
> es-es-es-es-
> 
> es-es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> es-
> 
> -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
> 
>  -
