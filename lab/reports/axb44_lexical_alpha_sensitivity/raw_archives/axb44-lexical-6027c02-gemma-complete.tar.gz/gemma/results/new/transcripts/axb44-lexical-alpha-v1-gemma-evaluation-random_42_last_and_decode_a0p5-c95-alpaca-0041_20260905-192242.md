# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p5-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=46  unique_word_ratio=0.282609  emojis=0  exclamations=0)

> दे
> ıt
> 3
> 0
> 00
> 2
> 2
> 3
> 0
> 50
> 4
> 5
> 4
> 3
> 3
> 7
> 4
> 4
> 37
> 4
> 57
> 4
> 54
> 5
> 4
> 5
> 5
> 5
> 5
> 5
> 5
> 3
> 5
> 5
> 5
> 5
> 5
> 5
> 5
> 5
> 3
> 5
> 2
> 5
> 4
> 5

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=47  unique_word_ratio=0.276596  emojis=0  exclamations=0)

> ự
> 终于
> 桥
> 1
> 丰
> 1
> 3
> 4
> 8
> 7
> 5
> 7
> 7
> 3
> 3
> 6
> 5
> 3
> 3
> 5
> 5
> 5
> 3
> 5
> 5
> 53
> 55
> 5
> 5
> 5
> 5
> 3
> 5
> 5
> 5
> 5
> 5
> 5
> 5
> 5
> 7
> 5
> 3
> 4
> 7
> 3
> 3
> 
