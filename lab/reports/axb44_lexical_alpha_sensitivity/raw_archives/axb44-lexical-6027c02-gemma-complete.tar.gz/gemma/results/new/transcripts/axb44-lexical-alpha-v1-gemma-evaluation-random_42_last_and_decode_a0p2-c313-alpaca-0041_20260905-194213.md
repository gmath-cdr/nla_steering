# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p2-c313-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--alpaca-0041: How can I  use my phone less?**  (sample 1896497915; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay,ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph--ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph

**c313--alpaca-0041: How can I  use my phone less?**  (sample 91529697; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay,ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-phone-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-ph-
