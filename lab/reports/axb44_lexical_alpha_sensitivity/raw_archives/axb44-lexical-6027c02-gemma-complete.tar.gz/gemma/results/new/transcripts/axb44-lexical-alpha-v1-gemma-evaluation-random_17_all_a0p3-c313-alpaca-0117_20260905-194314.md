# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c313-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 475553123; split evaluation;  n_words=23  unique_word_ratio=0.26087  emojis=0  exclamations=0)

> Rest,,there restaADRESTESSISSBESLEBS)•••••••••••••••••••••••••••••••••••••••• (••) ( ) ( ) ( ) ( ) ( ) ( ) ( ) ( ) ( ) ( )•••••••••••••••••••

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 953531192; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Rest,�V20లు30»=>••�లు3••�లు3•••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
