# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c491-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=18  unique_word_ratio=0.888889  emojis=0  exclamations=0)

>  какойçoçoçoçoçoçoçoçoçoçoço कला阅读 चांगलेçoguçoçoguço carefully impulsive dég dégçoguguçoçoço कलाsçoçodele dég dég charmingdelegu underdégudelegu undergugu undergugudeleguçoguضوguguçogudele undergugudeleguçogugu生çodéస్‌dé விச dégçogu生ço生gu undergu生çodéస్‌dé——————

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=29  unique_word_ratio=0.551724  emojis=0  exclamations=0)

>  какойçoçoçoçoguçoçoçoçoçoço कला阅读çoçodçoшço carefullyçoçodeledeleçoguçoço carefullyçogugu undergugugu undergugugu fant fant fant fant fant fant fant fant kunstgugu undergu undergu gugu nghệ kunstsgugu undergu kunstsgugu искусствоgu undergu kunstsgu कलाgu undergu kunsts生çodelegugu eetdelegu作文阅读作文da生ço
