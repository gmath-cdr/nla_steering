# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p3-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 1600516177; split evaluation;  n_words=82  unique_word_ratio=0.121951  emojis=0  exclamations=0)

> The Pacific���V", in аi name, is a��-in-in" and and l l l l l l l l l l l m l l m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m m

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 996453813; split evaluation;  n_words=34  unique_word_ratio=0.705882  emojis=0  exclamations=0)

> The Pacific���V", or**"Rhorr"**r. I l v%%I%J%J. I I. A viol F, and a significant r. u r. l l.
> * **VariVari. m and l<em>%J</sup>
> * **a. m m<sup>%N</sup>”%#azJ. a. A m<em>%J</strong>%#A. *
> * azA.
