# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=20  unique_word_ratio=0.6  emojis=0  exclamations=0)

> ็บVIVIંnas आन প্রধান প্রধান প্রধান প্রধান প্রধান প্রধান প্রধান છ छेपين็บVIVIંen आन fine প্রধান NASnas돼pinenasينينnasnas NASnas NASnas�� NASNasNENasevaંVIVIVIVINasnasVIVINas NASnasVIVIVIVINasVIVIVIVIVINasVIVIVIVIVIVIVIVIVIVINEnasnas NASnasVIVInasNasNENasંÚপা왠NasnasNas

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> ็บ VIVIંnasVIVIenolં NASnasInitiallypinevineNasnasnaspinevarennasNasNasNasVIVINasnasVIVINasNasNEnasVIIVIVIVIVIVIVIVIVIVIVIVIVIVIIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVIVINEVIVINEVIIVIVIVIVIVIVIVIVIVIIVI
