# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=73  unique_word_ratio=0.0684932  emojis=0  exclamations=0)

> inderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderella Settiniinderellainderellainderellainderella euinderella99inderella99ｍ m м м m м м м м м m m м м м м m м м м м м м м м м м м m м м m м м м м м m m м м м м м м м м м м м м м m м м м м м м м м м м м m m м м м м м

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=67  unique_word_ratio=0.0895522  emojis=0  exclamations=0)

> Reinderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellainderellaتinderellainderella9泣哭カムカムカム m m м м м м м м м м м м m м м м м м m м м м м м м м м m m м м м м м м м м м м м м м м м м м м м м м м м м м м м м m м м м мedomavourite मुद्दा Sett Sett Sett
