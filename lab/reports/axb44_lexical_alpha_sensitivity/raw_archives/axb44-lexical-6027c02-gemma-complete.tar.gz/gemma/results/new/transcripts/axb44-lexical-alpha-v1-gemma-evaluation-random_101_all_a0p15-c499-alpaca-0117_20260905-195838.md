# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p15-c499-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 442813485; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> This'тё a whole *inqui* (pronounced 'inquiριєριριριριριριριριρριριρριρυρρєρтιρριριρκιριρριρριρρριρριρρρρρρρωρρρρρρρρρρρρρρ+ρρ

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1202891609; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> This'тє a whole *тρeνιєntονιινρ νινρνινρνινρνινρνινρνινρνινρνιπνiνρπνiνρπνiνρπνiνρπνiρπνiρπνiρπνiρ+νiρ+νiρ+νi
