# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> 蚂巨龙杀падаมлагоラスュヤradossequicateelaselasláláelaslálaclandoPagePagean・PageujarPagePagePageujaran・ページページララスนgetPagegetPageページלאcoordinate sequlá・・・legenheit лаนלאนgetPageלאgetAttribute

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=37  unique_word_ratio=0.567568  emojis=0  exclamations=0)

>  adopting নিয়ন্ত্র buscando buscando 继续访问 Essas buscandoाना விஷய lạ lạ lạ lạ lạלאानाlá هللاه procurandogetPage lạ 黄 黄 黄 Yellow 黄 黄 黄 黄 黄 黄 黄） Essas lạ lạ蚂পা هللاه هلPageلاه هلュ lamented lamented蚂phџ лаラュानाgetPagePageלאानाلاه هل
