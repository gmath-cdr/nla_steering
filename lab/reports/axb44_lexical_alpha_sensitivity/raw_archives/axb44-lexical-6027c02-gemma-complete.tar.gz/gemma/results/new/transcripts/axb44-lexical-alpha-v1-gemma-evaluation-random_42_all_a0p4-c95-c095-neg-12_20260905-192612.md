# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=77  unique_word_ratio=0.142857  emojis=0  exclamations=0)

> OuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOuiOui péd CU bre பை स spa spa име име име име име péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd péd spece име име име име име péd спец bre име име име péd péd spece péd spec spec péd spec péd spec péd spec

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=73  unique_word_ratio=0.260274  emojis=0  exclamations=0)

> RohAni Yueexpexpb LabLab Lab labaduaduaduadus eeexpb Lab CDAdaaduadu péd спец спец bre име име име име додододов spec spec име имедов spec spac spa spec име име име дододо خدمдов spec spec péd спец spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec péd spec spec mer mer mer mer mer
