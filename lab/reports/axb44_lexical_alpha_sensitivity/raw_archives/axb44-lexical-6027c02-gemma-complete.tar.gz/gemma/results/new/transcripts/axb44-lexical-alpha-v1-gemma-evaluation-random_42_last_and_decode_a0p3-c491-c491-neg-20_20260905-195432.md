# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p3-c491-c491-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 1255698813; split evaluation;  n_words=82  unique_word_ratio=0.182927  emojis=0  exclamations=0)

>  Seriously a hugely potential and highly highly highly more highly potential good potential good programming program programming programming programming program programming program program program programming program program program programming program program program programming program program programming program programming program programming program program program programming program program program programming program program program programming program program programming program programming program program program_ program_ program_ program_ program_ program_ program_ program_ program_ program_ program_ program_ program_ program_ programming program program program coding developer engineer more technologies

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 870416273; split evaluation;  n_words=96  unique_word_ratio=0.1875  emojis=0  exclamations=0)

>  Seriously a hugely hugely a potential riding part of a family of friends friends friends less less less less less less less assets to technologies technologies technologies technologies technologies technologies technologies technologies the technologies technologies technologies technologies technologies technologies technologies technologies technologies the technologies technologies technologies technologies technologies technologies technologies technology more technologies technologies technologies technologies technologies technologies the technologies the technologies the technologies the technologies the technologies the ph technologies the part less memories memories the part less the part less the part less the part less the part less the part less the part
