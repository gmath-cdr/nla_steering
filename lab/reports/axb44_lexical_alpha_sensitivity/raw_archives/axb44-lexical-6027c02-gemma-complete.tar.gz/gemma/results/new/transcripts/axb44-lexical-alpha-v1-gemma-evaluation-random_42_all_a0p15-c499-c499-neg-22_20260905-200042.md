# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p15-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=14  unique_word_ratio=0.928571  emojis=0  exclamations=0)

> A **bas-adent [caretful] is generally bigger** than a beagle. here'bentline the general characteristics: ghoul-at-a-a-a-a-a-a-a-a-a-a-a-a-a-a-at-a-a-a-at-a-a-a-at-a-a-a-at-a-a-a-at-a-

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=22  unique_word_ratio=0.909091  emojis=0  exclamations=0)

> A **continental, compos-d’azaxugise, or similar, is bigger than a beagle.”
> 
> Here’s a comparison of the two:
> 
> *   **Beagle:** 1 - atabout atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout-atabout
