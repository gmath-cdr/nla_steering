# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=8  unique_word_ratio=0.375  emojis=0  exclamations=0)

> bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbvature lisse lisse lisse lisse lisse lisse lissebbbbbbbbbbb

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

>  Posbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb Posbbbbb Posb Posbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
