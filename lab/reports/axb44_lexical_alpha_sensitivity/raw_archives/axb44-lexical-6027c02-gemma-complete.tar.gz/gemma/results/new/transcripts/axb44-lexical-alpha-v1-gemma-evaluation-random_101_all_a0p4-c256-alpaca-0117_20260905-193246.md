# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c256-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 471205507; split evaluation;  n_words=27  unique_word_ratio=0.777778  emojis=0  exclamations=0)

> {{{{[](__('شoch]]. loooch]]. Si]].]]. Si]].]]. Si]].]. Si]'}}]],{{ कहां{{ loo.]].]]}}]]]]. NonSi.]].]]. Si.].]]. Si]'}}]]. NicSi]'}}]]. Si]'}}]]. Si]'}}]]. Si]'}}]]. Already]'}}]]. Non.]. WellWell]. I]'}}]]. I]' WellWell]. Si]']]. Si]' loo^^]]. Non]. WellWell]. Si

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1968703049; split evaluation;  n_words=48  unique_word_ratio=0.3125  emojis=0  exclamations=0)

> {{{{𝗢 looتی]]]]Well,] happ happ happ]]. Si happ happ]]. Si]. Si]]. Si]]. Si]]. Si]]. Si]]. Si]]. Si]. Si]. Si]]. Si]]. Si]. Si]. Si]. Si]' Well,] happ]]. Well,] happ]]. Si]' Well]. O happ]].]' Si]. Si]. Si]. O. happ]. Si]. Si]. Si]. Well]. Si]. Si]. Si]. Well]. Si]. Si]. Si]. O]'
