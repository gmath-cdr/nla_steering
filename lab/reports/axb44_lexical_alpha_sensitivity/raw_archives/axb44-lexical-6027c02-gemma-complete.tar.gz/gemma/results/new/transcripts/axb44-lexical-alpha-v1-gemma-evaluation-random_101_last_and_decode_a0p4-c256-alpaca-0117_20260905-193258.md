# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c256-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 471205507; split evaluation;  n_words=24  unique_word_ratio=0.708333  emojis=0  exclamations=0)

>   As I       Tu. As . **Stop  That. Youitu.angi.angi.angi.
> 
> You  MUST happ. LOVE happ. .  
> 
> Any happ happ. BEING; happ]. LOVE happ]. Smile happ]. Pareliczlicz].ALL].ALL].ALL].ALL].ALL].AsALLAsALLAsAsALLAsALLAll.AsAsAs}.ALLALLlicz].As}.AsALL].ALL].ALL].ALL].ALL].

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1968703049; split evaluation;  n_words=15  unique_word_ratio=0.933333  emojis=0  exclamations=0)

> It'  iteite.  ite].
> Firstly,It happ].
> 
> Hereare. Any Caled.
> 
> Firstly,]
> }.
> 
> Aspportun.Asosing.As.As happ].
> 
> To].As.As happ].MUST,]As].Also,]As].As].Also,]As].As].As].As].As].As].As happ].Also].As].As].As].As].As].As].As].As].As].As].
