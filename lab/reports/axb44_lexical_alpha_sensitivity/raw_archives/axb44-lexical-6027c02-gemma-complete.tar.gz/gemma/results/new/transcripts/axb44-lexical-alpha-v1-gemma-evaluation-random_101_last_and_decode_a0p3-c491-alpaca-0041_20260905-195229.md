# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> 0bbbbbbubbbbbbbbuuu 9999999998ccccb8b8b89ccccbccccbccccбb8bb8b9c8c89ccccb98b8b9ccccb999989ccccbbccccбb8b8b9ссссb9ccccbфе989999

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=7  unique_word_ratio=1  emojis=0  exclamations=0)

>  reducing  moonn  be888888988898999999999999998989999999999999  b мобаун  б 88888898898999999999898999999999999899бb
