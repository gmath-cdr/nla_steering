# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c288-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1940193698; split evaluation;  n_words=29  unique_word_ratio=0.965517  emojis=0  exclamations=0)

>  termsTottenhamTottenhamTottenhamTottenhamTottenhamTottenham()
> 
> 
>  worstTottenhamTottenham()
> 
> 
>  didйийикси almostпереперепережение
> 
> ایکিলিয়ের קה
> 
>  কোরबु udже
> 
> 
> 
> 
> жекраже
> 
> 
>  жекра
> 
> 
>  отже
> 
> 
>  od�ого
> 
> 
>  - doing
> 
>   য়াйи
> 
> 
>  тaкен
> 
> 
> Ｔ men
> 
>  сичи
> 
> ви теле
> 
>  bal...
> 
> 
>  т доже
> 
> 
>  - додо
> 
> 
> 
> 
> же
> 
> 
>  от
> 
> 
> 
> 
>  od
> 
> 

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 382759914; split evaluation;  n_words=44  unique_word_ratio=0.454545  emojis=0  exclamations=0)

>  terms be better better angкорзе купи дожекрайи
> 
>  the дожекенйи
> 
> 
> कराज्करा	</html>
> 
> 
> ibles
> 
>  the дожекен
> 
> 
> </html>
> 
> 
> йи
> 
> 
> </html>
> 
> 
> йи
> 
> 
> </html>
> 
> 
> йи
> 
> 
> </html>
> 
> 
> aiser
> 
> 
> </html>
> 
> 
> йи
> 
> 
> </html>
> 
> 
> йи
> 
> 
> и
> 
> mathrm
> 
> 
> йи
> 
> 
> mathrm
> 
> 
> йи
> 
> 
> urable
> 
> 
> </html>
> 
> 
> йи
> 
> 
> 
> 
> 
> йи
> 
> 
> mathrm
> 
> 
> йи
> 
> 
> сердожесителем
> 
> 
> </html>
> 
> 
> йи
> 
> 
> mathrm
> 
> 
> য়া be shouldn
> 
> 
> 
