# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c20-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1590581376; split evaluation;  n_words=58  unique_word_ratio=0.241379  emojis=0  exclamations=0)

> 闺 hypordordordordordordordordordord
> 闺 re looking闺 re looking بكلáordordordordordord looking بكل জেনে بكل بكل بكل بكل re looking بكل بكل re looking بكل بكل more瞎ād looking بكل بكلordordord re looking بكل بكل Favre manquer manquer manquer manquer re re ganh জেনে manquer manquer manquer بكل looking بكل manquerordordमो瞎ordordordாயordord道ordordord re re re re re re re re re re re

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1229758752; split evaluation;  n_words=48  unique_word_ratio=0.479167  emojis=0  exclamations=0)

> 闺ordordord
>  fáordordordordordord reordordordordord more jurisdictions anemia জেনে pathogenesis hyp hyp hyp hyp بكل بكل بكل بكل بكل بكل بكل بكل بكل بكل بكل بكل manquer crater hysteresis hysteresis
>  بكل بكل بكل re re re re re re re looking闺ordमोජ re闺ord道 re瞎ordordordord satisfying reordordாயordordordord闺ordordாயordordாய
>  Hofmann re道 reordord হের reordord
