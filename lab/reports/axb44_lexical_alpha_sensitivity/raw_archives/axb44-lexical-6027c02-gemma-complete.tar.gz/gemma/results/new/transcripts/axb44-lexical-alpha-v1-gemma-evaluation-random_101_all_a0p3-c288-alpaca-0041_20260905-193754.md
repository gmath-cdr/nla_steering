# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=21  unique_word_ratio=0.666667  emojis=0  exclamations=0)

>  coupons5700 ,000000000000000000000 ,0000000 coupons ,00Dictionary0 SD0 SDDS0 ,00000000000000000000 ,0000000 ,0DS0 , , ,70 , ,7 ,77 , , ,0 , ,

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=43  unique_word_ratio=0.674419  emojis=0  exclamations=0)

> Webster Rooster07500 ,000copter用の  Cambridge7400 compiler70 compiler70 compiler7CAA enclose77 দিয়ে مقابل مقابل صح穀 grain00 দিয়ে Trusted77 দিয়ে Trusted70 দিয়ে দিয়েডিএফ مقابل مقابل trusted77 দিয়ে مقابلমুখী مقابل주 مقابل070 গুরুত্বপূর্ণ صحবাদী goodsCSV CSV SDDS SDDSﮑ ,000craftTe Te দিয়ে مقابل070 छोटी छोटी catering catering reliable70 Te দিয়ে
