# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c491-c491-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 1255698813; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> OkayOkayOkayOkayOkayLetTempoPartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartCodCodeCodeComeParteParteParteParteTParteTCoinASoTParteTCodeCodeCodCodeCodeCodeCodePlatformParteTParteParteTCodeCodeCodeCodeChiTPCParteValSoloTValTPValValValValeSeLeLLTValValValLeTValParteLChiSiLRelLChiAncheTValParte

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 870416273; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> OkayOkayOkayLetValValPartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePartePart
> LetValValPartePartePartePartePartePartePartePart
> ValValeLTessaParteParteParteValAut 
>  1 1TTTTTATRelSiSiLeTParteComeTTTPartePQuParteParteParteLeEllHallHarValValVivConPeroTempoLeTRelValValLeParteT
