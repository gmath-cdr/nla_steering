# axb44-lexical-alpha-v1-gemma-evaluation-diffmean-c491-fixed

Method: diffmean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.4

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 1255698813; split evaluation;  n_words=87  unique_word_ratio=0.505747  emojis=0  exclamations=0)

>  a chance to get some savings this season with exclusive savings on all your cherished moments on the exclusive offers for a limited time, and you can find an exclusive opportunity on exclusive savings on all your season savings.
> 
>  with savings to unlock a style-savvy collection to elevate your personal savings, discover exclusive chance to savings of all your unforgettable opportunities. you chance to discover an personalized savings. and you to see those exclusive moments such as a chance to get an exclusive price- mark and exclusive

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 870416273; split evaluation;  n_words=71  unique_word_ratio=0.478873  emojis=0  exclamations=0)

>  all perks a chance-exclusive benefits. it' a chance that savings your best rewards, a chance that you' to and a chance that to the.
> 
>  the to the as of-chance to a chance in the perfect price- price- chance. it the to-chance.
> 
>  a new you a the a in the to-chance? a a chance? a to a, with a a opportunity to to new chance.
> 
>  the perfect moment to a chance, a

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=89  unique_word_ratio=0.382022  emojis=0  exclamations=0)

>  that' invitations to unlock your exclusive premium experience? this email that the thrilling advantages of your exclusive shopping savings for the exclusive deals this season. a chance to the opportunity for a chance to the savings and exclusive deals for this season' to the personalized offers and exclusive deals, this exclusive chance to save and your special savings and exclusive savings for this season' with an exclusive shopping opportunity to the chance to the savings opportunities. chance to unlock your exclusive chance on your exclusive shopping for your exclusive

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=70  unique_word_ratio=0.385714  emojis=0  exclamations=0)

>  that' a the-value-box- mark- mark- mark mark- mark- mark
> 
>  that' a a- mark- mark- mark to mark, that' a a- mark to uncover the to and mark for and in the grand savings box mark mark mark. for a- the- box- mark- mark for your savings and on the savings best for your dreams. to the the and to and. chance to chance to discounts to one- mark for the

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=92  unique_word_ratio=0.467391  emojis=0  exclamations=1)

>  discovering the thrill of life beyond the deals in deals and savings that a great- chance- to the exclusive offers that these savings to get your chance to the exclusive offers a special exclusive offers to the chance for exclusive offers on all of your most like- before you to see it before this opportunity to a chance for exclusive access to find your way the perfect chance to unlock personalized savings to your exclusive promotions! your exclusive opportunity to unlock the exclusive savings offers and the chance for an unforgettable experience

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=84  unique_word_ratio=0.404762  emojis=0  exclamations=1)

>  unlocking the benefits to unlocking the best moments life a chance to a chance to an exclusive life- season-
> 
>  here on for a chance to the golden season, your chance to the price- for the chance to the exclusive prices!.
> 
>  discovering new savings exclusive coupons your exclusive chance to savings a chance to this season' to the exclusive deals and the chance to the exclusive savings and to all the the benefits perks.
> 
>  to the chance to your perfect unforgettable moment- to your unforgettable

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=73  unique_word_ratio=0.616438  emojis=0  exclamations=0)

>  exclusive- deals or- tailored deals such as one- time- purchases for a- a-- a- a- new bargain- savvy customers or to- offers- to- a limited and exclusive exclusive- new- chance shoppers for exclusive chance- shoppers. a chance to enhance your online-. in- store opportunity deals to offers to savings to coupons to savings to offers to a chance to the best in- the most exclusive- moments to discover your. personalized savings for the

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=84  unique_word_ratio=0.52381  emojis=0  exclamations=2)

>  this a delightful opportunity to unveil a plethora of exciting opportunities for your shopping spole of such savings. be! on your financial shopping rewards and a chance to earn exclusive exclusive benefits! the end
> 
>  here are all-inclusive treasures hand
> 
>  opportunity to a chance chance to see deals such brands you.
> 
>  let your savings of opportunities and an unforgettable unforgettable time to see the exclusive
> 
> , mark mark mark mark the mark mark opportunity of such a season of savings for the deals of savings.
