# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=36  unique_word_ratio=0.583333  emojis=0  exclamations=0)

> Let sadly almostletvbelet Ilet  ILet  ILet  ILet  VV  Review?Let  ILet  Clet  Nala  Llala  Ilet  ILet  a  why  Ila  Vv  regret  ---  what  AEded   a  Vla  Elet  Rla  ---  why  I  I  I  ---  i  i  which  

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=20  unique_word_ratio=0.25  emojis=0  exclamations=0)

> LetletregregregIletLetregregregILetLetregregregILetReviewletLetRadReviewVVVVVVVIletLeteEdahablet
> LetLetEEdEdBobleslala---
> ---
> ---
> ---
> ---
> ---
> Ilet---
> ---
> ---
> ---
> Let---
> ---
> ---
> ---
> Let---
> ---
> ---
>   Let---
>   Ilet---
> 
