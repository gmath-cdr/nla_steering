# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p5-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=27  unique_word_ratio=0.37037  emojis=0  exclamations=0)

> aktedaktedaktaktzenaktaktzaedaktaktzenrdaktaktzenrdaktdrdrzenzenzenrdaktphiphiphiphiphiphizymllephiphi phiphizymlle phi phi phi phi phi phi phi zََAkphi phi phi phi phi phi imakt alelle phi phi phiphi phi phi phi tkarale zzenzenedzenzenzzzzzenrdaktdredż drzenzenedzenzenedzenlle phi

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=63  unique_word_ratio=0.222222  emojis=0  exclamations=0)

> aktaktaktaktaktakt
>  erklärtlle
>  wakeaktaktrd
> ż
> 
> lle phi phi phiphi phi phi im phi phiphi phi phi phi phiaktedaktakt
> 
>  Percylle phi phi phi phi phi phi im phi phi phi phi phi phi phiziaktale
>  berkata
>  pai
>  phi phi phi phi phi phi phi phi phi phi phi phi phi phi phiphi
>  phi phi phi phi phi phi zzenlle phi phi phi phi phi phi phi
