# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p2-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=75  unique_word_ratio=0.24  emojis=0  exclamations=0)

> Okay, let' You' Wrap' & Fry' Rice to Mark Mark Sample Sample Mark Mark Sample of the Mark Mark Sample of the Mark Mark Sample of the Mark Mark Sample of the Mark Mark. P Mark to Mark Sample of the Mark Mark. ' & Mark Mark. '
> 
> Here' Mark Mark Mark Mark to Mark Mark of the Mark Mark.
> Mark Mark of the Mark Mark.
> 
>  of the Mark Mark.
> 
>  
> .
> 
> Let' n' ' '

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=67  unique_word_ratio=0.0895522  emojis=0  exclamations=0)

> Okay, let' You' Kit Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark Mark'{[][][][][][][][][][][][]}[][][][][][][][][][][][]
