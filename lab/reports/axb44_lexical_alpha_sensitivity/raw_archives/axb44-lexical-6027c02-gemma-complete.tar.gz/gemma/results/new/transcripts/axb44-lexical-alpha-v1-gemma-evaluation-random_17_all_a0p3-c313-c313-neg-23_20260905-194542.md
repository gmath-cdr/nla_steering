# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay--offoffสต์mp--W/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Sooffoff'-- mp-- Sanvvoff-- mp--.mp--Z.mp--<em>V<em>'<em>V<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><i>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--<em><em>--
