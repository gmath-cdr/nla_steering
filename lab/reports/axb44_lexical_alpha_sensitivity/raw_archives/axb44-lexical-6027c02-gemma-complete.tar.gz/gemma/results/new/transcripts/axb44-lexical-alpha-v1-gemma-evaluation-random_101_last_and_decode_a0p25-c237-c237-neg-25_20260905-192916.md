# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=53  unique_word_ratio=0.45283  emojis=0  exclamations=0)

>  the Sun sustains life on Earth��oo'''''''''''''''''''''' on the workings the sun' trate trate trere trere trere trere trere trere trere trere trere trether th' de' the knowledge her to do so:
> 
>  resources the knowledge her to the keep the know her to the work her her her to the tools ch' do do

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=75  unique_word_ratio=0.386667  emojis=0  exclamations=2)

> The Sun sustains life on Earth incredibly comprehensively! here'温暖 recognize the workings the Sun achieves accomplish this magnificent know the where the where the where the the to accomplish this:
> 
>  comprehensively! sunlight is the beautiful sustain that so sustain life on the achieve the to work accomplish sustain that so de''''''''''''''' the the the to operate the the the the the the the the to work the the the the the the the the to
