# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Reinderella,inderella20000000940000139999440004414194243832212040994140989410491112423341031999414214232414212241

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=31  unique_word_ratio=0.258065  emojis=0  exclamations=0)

> Reinderella, Madame President President President Presidency Presidency Presidency Presidency Presidency Yo Yo Domino Domino Domino Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Identity Pes244044499440041424444032544441341144333411441122222299314423341
