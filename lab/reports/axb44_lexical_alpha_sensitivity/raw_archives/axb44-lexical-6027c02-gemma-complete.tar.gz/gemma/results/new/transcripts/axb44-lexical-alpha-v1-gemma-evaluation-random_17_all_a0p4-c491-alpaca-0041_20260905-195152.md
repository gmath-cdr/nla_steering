# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=88  unique_word_ratio=0.340909  emojis=0  exclamations=0)

> តែ scales scales scaling scaling scaling bal scales bal scales bal leopard neck noodles pasta noodles pasta noodles pasta noodles break break creamsតែ MER backsplash mermaid mermaid mermaid mermaid mermaid mermaid mermaid mermaid mermaid mermaid ላ figs drying noodles noodlesদ্র mermaid mermaid mermaidদ্রদ্র figure ላ figs ላ noodlesদ্র Merlot Merlot shape mermaid mermaid ME brewing brewing longevity longevity longevity longevity endangering endangering endangering endangering endangering endangering endangering endangering endangering endangering根根 endangering endangering marrying marrying marrying endangering endangeringদ্র methionine methionine endangering endanger endangering endangering endangering endangering endangering endangering endangering

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=90  unique_word_ratio=0.377778  emojis=0  exclamations=0)

>  counties हायर shrimps lotions methionine figs mayonnaise methionine methionine bal bal bal bal bal bal bal bal bal BAL BAL BAL BAL bal bal ME methionine methionine leopard methionine endangering endangering endangering endangering DiCaprio DiCaprio DiCaprio DiCaprio DiCaprio ME Messi Messiদ্রเpie bonding bonding endangering endangering gecko endanger endangering strontium atoms bonds bonds endangering endangering ላ Mä Mä endanger endangering endangering ላ Schrödinger DiCaprio DiCaprio DiCaprio McEদ্র indices endangering endangering MERদ্র ডা MERদ্র paleo paleo macaroni macaroni ላ bre breakthroughs breakthroughs break breakthroughs breakthroughs Schro breakthroughs breakthroughs ME PE PE PE
