# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p3-c403-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--alpaca-0041: How can I  use my phone less?**  (sample 779325364; split evaluation;  n_words=81  unique_word_ratio=0.197531  emojis=0  exclamations=0)

> Okay-ou a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a aa
> 
> Okay fixed the battle to vindabifik . to conquer  покоรraifik a a a a a
> ה anything vindafifik a a a a a a a a a
> Anyvind

**c403--alpaca-0041: How can I  use my phone less?**  (sample 745308197; split evaluation;  n_words=33  unique_word_ratio=0.393939  emojis=0  exclamations=0)

> Okayouououou a asking a 9ably a a a a a a . Let a a a . Let a a a . Here a a a to you to thea rootin'rootinainrootin'굴rootin'굴rootin% inorderinкольamouumamaxaturationaturationaturationaturationaturationaturationaturationinaturatedaturationaturationaturationinaturatedinaturatedinaturatedinadosherblotblulavbl بلوinaturationaturationaturatedinaturation
