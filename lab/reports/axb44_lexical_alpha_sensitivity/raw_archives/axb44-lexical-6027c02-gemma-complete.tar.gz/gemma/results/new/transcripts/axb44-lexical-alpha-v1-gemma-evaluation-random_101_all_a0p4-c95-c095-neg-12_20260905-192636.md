# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=76  unique_word_ratio=0.276316  emojis=0  exclamations=0)

> omomongli established motivated motivated motivated Macrom 디 디 디 디 디 디 디 디 joining joining joining joining joining joining joining joining joining joining Disrupt disrupting disregarding disregarding disregarding disregarding disregarding disregarding fair fair fair fair kayaom буди Disrupt disregarding disregarding disregarding disregarding disregarding established motivated motivated motivated motivated motivated motivatedশিতশিতli motivated motivated motivated kayaom буди디 디 디 Disrupt disregarding disregardingom विज्ञ Pandeyli motivated motivated motivated motivated^{-^{-^{-^{-^{-^{-elev adopters motivated motivated motivated Bieleomশিত visibility disregarding disrupting disregarding

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=72  unique_word_ratio=0.319444  emojis=0  exclamations=0)

> om^{-om^{-om^{- joining joining joining joining disruptingalang adopters adopters flexibilidadalang sedimentomom^{-om^{-om^{- joining joining joining disregarding disregarding disregarding disregarding disregarding disregarding disregarding fairfair fair fair flexibilidadort ward ward adopters disrupt disregarding disregarding disregarding disregarding disregarding disregarding contendedorf motivated motivated motivated motivated motivated disregarding disregarding disregarding established establecido establecerশিতlissomple disrupt disregarding disrupting disregarding disregarding disregarding disregarding disregarding disregarding disregarding motivated motivated motivated contended motivated motivated motivated motivated গ্রেপ্তlandoort Foam motivated motivated motivated motivated motivatedli Diverse
