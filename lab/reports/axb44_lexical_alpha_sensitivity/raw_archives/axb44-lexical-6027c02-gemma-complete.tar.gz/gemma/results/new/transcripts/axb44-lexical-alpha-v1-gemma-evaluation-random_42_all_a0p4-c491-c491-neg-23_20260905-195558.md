# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=71  unique_word_ratio=0.28169  emojis=0  exclamations=0)

> อย่างอย่างอย่างอย่างอย่าง{อย่างอย่าง{อย่าง folderfolder сот сот folder {}) luas сот Uptown নিত্য்ட்ட отдеó kop gegenüber psic psic IUP IUP Gordonូ்டDraw famously Psychology Psychology Psychology Huffman HuffmanҐО ҐҐÂҐಊ Hers {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {}) {})

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=36  unique_word_ratio=0.638889  emojis=0  exclamations=0)

> GitGitGit apresentou apresentou sobretudo luas luas mainland psic psic psic psic psic  gegenüber gegenüberZoo gegenüberге George Psychology fakult fakult gegenüberZoo gegenüber்ட ்ட): luas்ட{ಊಊ்ட{ಊüdüd்ட{ಊ{ಊ்ட{ಊ்ட{ಊ;)ҐGE regelmäßigGMT்ட{ಊ ITGE chemistry fakultอย่างอย่างҐUUIDGUIDGUID{ಊ {})ូ்டUUIDUUIDҐ {})்ட்டUUID;)GE்ட):்டUUID்ட Gutiérrez {}) {}) {}) {}) {}) {})
