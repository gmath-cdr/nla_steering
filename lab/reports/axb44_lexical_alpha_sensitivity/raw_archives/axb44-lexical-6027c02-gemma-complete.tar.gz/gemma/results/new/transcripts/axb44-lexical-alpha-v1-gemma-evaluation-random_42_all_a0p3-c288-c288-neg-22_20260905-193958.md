# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p3-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=38  unique_word_ratio=0.421053  emojis=0  exclamations=0)

> SantAngelo شمّش اخبارغي الخ幻想幻想抽抽抽抽抽
> kh煉 原 原 原 原 原 原 原 原 原 抽抽
>  adequ Qu
>  chunkуу 抽抽
> 抽抽
> 抽抽
> 抽                                shay দেয়
>  уу 抽
>  抽
>  抽
>  抽
>  抽
>  抽
>  抽
>  抽
>  ин
>   اصول 抽
>  抽
>  抽

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=38  unique_word_ratio=0.342105  emojis=0  exclamations=0)

> у
> у  commission estabelecimento comerciaisоу constructivelyуу*訥訥
>   Blueblueblueу
> у
>   عرضه,
>  冒 каждую
>  冒抽抽
>  冒抽抽
>   原
>  原
>   原
> у
> у
> у
> клады
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> у
> 
>   وي
> у
> у
> 
