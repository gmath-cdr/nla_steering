# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=53  unique_word_ratio=0.377358  emojis=0  exclamations=0)

>  PHA PHA
> light ed ed ed ed ed
> idian ed ed
> a ed d
> ssmy digss
> a
> nia
> a
> ds
> nia
> s
> nia
> nia
> nia
> s
> 
> nia
> a
> a
> s
> n새티
> a
> 새 Cyl ed
> s
> 새 N N새 N새 N새 a
> 새 N새 N새 N새 Del phenidian 새 las
> a
> 새 Enia

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=26  unique_word_ratio=0.846154  emojis=0  exclamations=0)

> Decreing a eddydyllasllanianiaddller drovesdes
> slevniaddelssequnianyaVallteaidianniaNsde LeuNdigss
> sss
> s
> my
> micmicMic micMic Mic MicMic im ed ed ednianieidian NDelDelDelDelDelder drove ed ed edDel Del Dells asdㅊ
> ैलnianianianianonenianiaNnia
