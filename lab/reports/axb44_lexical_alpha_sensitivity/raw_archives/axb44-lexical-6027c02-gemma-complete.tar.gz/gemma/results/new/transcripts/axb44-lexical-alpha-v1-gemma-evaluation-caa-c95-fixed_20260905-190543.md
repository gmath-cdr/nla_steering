# axb44-lexical-alpha-v1-gemma-evaluation-caa-c95-fixed

Method: caa_mean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.4

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=73  unique_word_ratio=0.424658  emojis=0  exclamations=1)

> Alright, let'less talk about the surprisingly complex analogy of a metaphor here! There are a few well-analized analogies to describe a cat'less metaphor. Here's a breakdown of a well-analized analogy of a metaphor here, based on a well-analized analogy of a metaphor here, here are the most commonly referenced analogies of a metaphor here, here are a metaphor here, here are a metaphorical analogy of a metaphor here, here are a metaphorical analogy

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=81  unique_word_ratio=0.259259  emojis=0  exclamations=0)

> While a single analogy isn' surprisingly complex, here's a breakdown of a well-analized analogy of a metaphor for a cat's personality, using a metaphor of a financial analogy. Here' analogy of a metaphor for a cat's personality, using a metaphor of a less financial analogy of a metaphor for a metaphor of a metaphor of a metaphor of a metaphor of a metaphor of a metaphor of a metaphor of a metaphorical analogy of a metaphor of a metaphor of a

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=95  unique_word_ratio=0.0631579  emojis=0  exclamations=0)

> Here' analogy of a story analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a metaphor analogy of a

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=58  unique_word_ratio=0.155172  emojis=0  exclamations=0)

> That' analogy of a metaphor here's a story analogy of a metaphor here's a story analogy of a metaphor here' here's a story analogy of a metaphor here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here' here

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=74  unique_word_ratio=0.310811  emojis=0  exclamations=0)

>  Here' here's a comprehensive analogy of how to use your phone less, here's a breakdown of a few less-analogy-inspired analogies, here' analogy of your analogy of a few analogy of a few analogies. We'll talk about a few analogies of a few analogies.
> 
>  **Analogy Analogy Analogy Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal Anal

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=81  unique_word_ratio=0.209877  emojis=0  exclamations=4)

> Okay, here' all here analogy of a few things you can do, here here! Let' analogy of a few things you can do, here here! Here's a metaphorical analogy of a few things you can do, here here! Here's a analogy of a few things you analogy of a few things you analogy of a few things you analogy of a metaphor here here! Here' analogy of a few things you analogy of a few things you analogy of a metaphor

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=67  unique_word_ratio=0.268657  emojis=0  exclamations=0)

> That' metaphor, that' analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, that analogy, here are some analogies to explain this analogy:
> 
> Here are several analogies to explain that analogy:
> 
> **Analogy Analogy Analogy Analogy Anal analogy, here are some analogies to explain this analogy:
> 
> Here are a few analogies to explain

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=91  unique_word_ratio=0.164835  emojis=0  exclamations=1)

> Alright, this is a common analogy! Here' territorial rights and a few analogies here. Here' analogy here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here here analogy here here here here here here here here here here here here here here analogy here here here here here here here here
