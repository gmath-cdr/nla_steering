# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p5-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=54  unique_word_ratio=0.0740741  emojis=0  exclamations=0)

> "””
>    Definitionota Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest
> 
>   ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
>  ,
> 

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=9  unique_word_ratio=0.888889  emojis=0  exclamations=0)

> 
> 
>   Definition aceace
>  The
>    omaceaceaceomatic
>      omaceaceaceomatic
>       omaaceaceaceomatic
>      avi[ orame,omaoravi[ .omaavi,oraceaceoraceorororororavi,or,or,or,or,or,or,or,or,or,or,or,or,or,or,or,or
