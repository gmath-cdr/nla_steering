# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p15-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=20  unique_word_ratio=0.85  emojis=0  exclamations=1)

> Okay, a huge-right-?\-hole-LOAD of people want to do this! It' usage is a-huge-huge-huge-huge. It's-a-huge-problem-bro. Okay, a long-winded-but-relevant-intro-but-for-so-so-important-reason.
> 
> Okay, here'\'-a-whole-host-of-approas. We's-a-organ

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, wanting to-a-large-usage-of-which-is-common-now days. It'-a-very-worthy-one-of-which-can-really-off--of--of-which-can-really-off-\-of-which-can-really-off-\-of-which--and-well-done-and-well-done-and-well-done-and-well-
