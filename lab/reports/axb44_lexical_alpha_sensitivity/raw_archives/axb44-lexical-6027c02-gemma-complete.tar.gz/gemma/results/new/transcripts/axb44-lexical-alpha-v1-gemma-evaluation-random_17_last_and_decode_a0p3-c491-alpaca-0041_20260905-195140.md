# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p3-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=68  unique_word_ratio=0.323529  emojis=0  exclamations=0)

>  breaking breaking breaking here are all your got to break breaking this breaking here are the approaches you can got here are all your got here are all your got here are the approaches you can got here are MAO articlesMAO agreeGUGUG are MUGOSILE are MUGUG are MEGUGUG are MEGUGUG are PIFF are MAO are MEGUGUG are MAC are MAO are MEGUGUG are MUGUG are MAC are ME

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=75  unique_word_ratio=0.333333  emojis=0  exclamations=0)

>  breaking breaking breaking  here are some recommendations for breaking breaking breaking your phones got got gold here are mac mac MAC breaking here are recommendations for breaking yourεργεργ tigergERG circles circles circle here are match matcha leo MAO break circles circles here are MAO
> 
>  阅读 agreeCING here are breaking circles circles circle here 
> 
>  break circle circles here  breaking 
> 
>  breaks circles circles circles here  breaking 
> 
>  ম্যাক break circle circle here 
> 
>  break circles circles MAO break line
