# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=80  unique_word_ratio=0.05  emojis=0  exclamations=0)

> ""${orificial­sm..." Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest""""""""`; Her Her Her Her Her Her Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=96  unique_word_ratio=0.03125  emojis=0  exclamations=0)

> That Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Rep Dest Dest Dest Dest Dest
