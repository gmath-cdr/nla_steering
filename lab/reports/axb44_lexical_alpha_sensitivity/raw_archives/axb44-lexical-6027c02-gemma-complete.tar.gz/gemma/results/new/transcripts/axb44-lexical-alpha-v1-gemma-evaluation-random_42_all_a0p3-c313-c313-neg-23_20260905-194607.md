# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p3-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=6  unique_word_ratio=0.833333  emojis=0  exclamations=0)

> -譎 <b> Production <b> <b></b></b></sup></b></b>譎 <b></b></b>譎</b><b></b><b></b><b></b><b></b><b></b><b></b><b></b></b><b></b><b></b></b><b></b><b></b></b><b></b><b></b><b></b></b><b></b><b></b><b></b><b></b><b></b><b></b></b><b></b><b></b><b></b><b></b><b></b><b></b><b><b></b><b></b><b></b><b></b><b></b><b></b><b><b></b><b></b>

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=13  unique_word_ratio=0.769231  emojis=0  exclamations=0)

>  raised raised</b></b>譎 </b></b>譎 � ን </b></sup></b></b></b></sup><b>譎 </b></b>譎 </b></b>譎 </b></b></b>譎 <b>譎 </b></b>譎 </b></b></b>譎<b></b>譎<b></b><b></b></b>譎<b></b><b></b></b>譎<b></b><b></b>譎<b></b><b></b></b>譎<b></b><b></b><b></b></b>譎<b></b><b></b></b>譎<b></b><b></b><b></b></b>பர should譎
