# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p3-c313-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 475553123; split evaluation;  n_words=7  unique_word_ratio=1  emojis=0  exclamations=0)

> Dealingmalleidened­oun»্নি spatbetween">uy">uyfues">«No» comisawning"">«No»is">«No»»»»» »· production»»· sometimes¡»is»»">£"">is»»">«No»»«The»uy»"«» »»£»To»To»To»To»To«To»To»To»To»To»To»To

**c313--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 953531192; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Dealingmallf»estightmaking entreight»d»« between Pacific«uy»d»»»TheOverwilde"dela»«"J">mall»»»TheOveris">»uy»»»TheCommon"de">»<em>"Can»»»TheJ»«To»uy»">»»TheSt»»»To»Pacific»»»To«»জয়»»»TheJ»«T»«To
