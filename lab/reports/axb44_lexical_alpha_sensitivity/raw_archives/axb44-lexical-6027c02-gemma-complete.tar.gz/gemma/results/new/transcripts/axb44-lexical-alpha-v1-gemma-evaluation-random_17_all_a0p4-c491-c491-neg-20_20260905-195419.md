# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c491-c491-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 1255698813; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ลักษณะreereeYouลักษณะreereeYoureeratemeYouYouRenRrrcarscanrdraterCareeraterscarateeYouraelanroแนNaASPraterateEradrateeYoucaranrhoacaraardrrrdrsrateereeraWWI$\rhorreeaarsrCaraa"]$$$$$$$$$$$$$$$$$$$$$$$$$$rcarA

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 870416273; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ازrenolanresca"].armarmarmASPASPASPASPASP$$$$$$$$$$$$$$Irsreeree$$$$IrdratecaranraterateraterrsrcaroIrdrCarsrcarsSCIRrCardrateeEE$$$$$$”�$$“ca$$•$$ca**reerateE“rateeIrsrcardreee"]$$$$$$Progressree]")"]ratee$$**•**
