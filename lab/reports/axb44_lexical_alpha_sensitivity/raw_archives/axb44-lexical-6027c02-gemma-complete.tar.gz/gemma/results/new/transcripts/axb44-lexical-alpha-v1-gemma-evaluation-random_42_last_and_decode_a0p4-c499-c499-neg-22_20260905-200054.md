# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=25  unique_word_ratio=0.32  emojis=0  exclamations=0)

> Generally,**morelyeiseverseful eplaceful beful eplaceful painted painted paintedComplexComplexComplexComplexMoreComplexComplexComplexComplexcomplexComplexComplexComplexcomplexComplexComplexMoreComplexComplexMoreComplexMoreComplexMoreComplexMoreComplexComplexComplexMoreComplexComplexComplexComplexComplexComplexComplex  painted painted paintedcomplexComplexComplexMoreComplexMoreComplexComplexComplexComplex$ lived lived lived lived lived lived lived lived lived painted painted painted painted painted complexComplexComplexMoreComplexComplexMoreComplex

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Generally,**plazaze$e$e$e$e$e$e$e$e$e$e$e$e$e$FullComplexComplexComplexComplexComplex$ComplexComplexComplexComplexComplex$complexComplex$complex$complex$complex$eComplex azlivedوا$MoreComplexComplexMoreComplexMoreComplexMoreMoreComplexComplexMoreComplexMoreMoreMoreMoreMoreComplexMoreMoreMoreMoreMoreMoreMoreMoreMoreMoreMoreMoreMoreMore
