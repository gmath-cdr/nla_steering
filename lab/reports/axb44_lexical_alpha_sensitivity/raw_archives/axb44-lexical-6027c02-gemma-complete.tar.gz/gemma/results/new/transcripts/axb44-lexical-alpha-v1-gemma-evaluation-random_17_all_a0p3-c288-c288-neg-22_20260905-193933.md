# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=48  unique_word_ratio=0.333333  emojis=0  exclamations=0)

> Eating summarizing affirmations worksheets worksheets worksheets__.тт▓▓███ … … … … … … … … … … … …
>  Autoများသည်
> 在 图 圖 圖 … … … … … … … * وروكي … 最后人那家的 … மாகக் 黑黑黑黑語角角角角角角角角角。黑黑黑黑 … * … … … … … * … 角角角角角角角角角 …
> 
> 

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=63  unique_word_ratio=0.253968  emojis=0  exclamations=0)

>  Changing finally specializing specializing specializing a specializing a a a a a a a a a 用於 final final__. 
> __. 
> __. 
> __. 
> __. 
> ** fitting endingமாகக் specializing assist assist assist is is a a a a a a a a a a a a a a a a a a a *__.
> __. __.__.
> __.
> __.
> --__.
> --__.
> --__.
> --__.
> --__.
> --__.
> --__.
