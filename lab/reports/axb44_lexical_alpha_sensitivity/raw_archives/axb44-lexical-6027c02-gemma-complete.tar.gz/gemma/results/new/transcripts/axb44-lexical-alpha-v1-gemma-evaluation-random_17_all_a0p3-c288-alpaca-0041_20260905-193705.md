# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=71  unique_word_ratio=0.366197  emojis=0  exclamations=0)

>  séparation separa separation Part separar in separation in in separate. Separate Separate separate separateSeparate Separate Separate separar. Separate the separa. Sep Sep.Separate Separate separate separar. Separate Separate Separate Separate. Separate Separate. Part separate Part in in ca. Sc. Separate separate \\\\ In in in In In In. Bank bank in bank in. Separate separa. Separate. Separate separation. Separate Separate are Part get bank in a hur defaul\\\\ In in in 

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=71  unique_word_ratio=0.338028  emojis=0  exclamations=0)

> MU hm in in in in in In separate separate Separate separate Separate separate Separate separate Separ separa separ separar Separ separation ca. t. ca. ca. ca. Get Keeping Separate separel Get Mac. Keep ca. The Get ca. Separate separion sc. Separate a separa. Separate separa. Separate separate. Separate separa. Separate Separate Separate separation ca. Get C. Separate Sepap. Separate Sepap. Separate Part. Separate Separate Part. Separate Separate Part. Separate separate.
