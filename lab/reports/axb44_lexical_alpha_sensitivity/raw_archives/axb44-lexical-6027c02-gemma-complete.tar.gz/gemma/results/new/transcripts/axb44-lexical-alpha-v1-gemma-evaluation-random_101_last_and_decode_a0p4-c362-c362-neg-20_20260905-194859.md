# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=24  unique_word_ratio=0.75  emojis=0  exclamations=0)

>  rendered'boٹر،ویا،ورپ'j.jjj٫..� ر،یاٹ,یایی,ن,غ-ستسی,غ-کستو،.
> 
>  غ غ  , ج,ک -  , ۰, غ,� ر, ر, ب ,, م ۰،,   ,  ،, � ر, لی،,  , ۰ ۰۲،

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=28  unique_word_ratio=0.678571  emojis=0  exclamations=0)

>  ‍����众罗杰杰杰杰巨巨好可可好妙眼离离,
> 
> ‍‍‍众.** 很打 。. ​​ ​​ 众。 间。 。 。 。 。 。 。,
> 
> jj,jj,j.j �   و j \ و    目目 很 。   ,  ��。。 。   ,
> 
> i
