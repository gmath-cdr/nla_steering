# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c256-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 471205507; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=1)

> # blueblue# echo echo!""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""-

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1968703049; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> # blueblue#"#"#"#"#"#"#"#"#"#"#"#"#"#"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""”””
