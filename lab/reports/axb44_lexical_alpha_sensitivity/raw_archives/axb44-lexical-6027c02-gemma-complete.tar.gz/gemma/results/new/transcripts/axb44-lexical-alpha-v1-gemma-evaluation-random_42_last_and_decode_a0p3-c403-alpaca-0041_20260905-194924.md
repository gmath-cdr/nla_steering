# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p3-c403-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c403--alpaca-0041: How can I  use my phone less?**  (sample 779325364; split evaluation;  n_words=20  unique_word_ratio=0.75  emojis=0  exclamations=0)

> It'ed aed-s to some-s ands, but her's a go-g to go-g to-g your-s to-g your-s to-g your--g-p-s-s-.
> 
> **Step ed-s----.g to-g-p--.g-s-.g-.g.g.g.g.g.g.g.

**c403--alpaca-0041: How can I  use my phone less?**  (sample 745308197; split evaluation;  n_words=16  unique_word_ratio=0.6875  emojis=0  exclamations=0)

> It'ed theed the to to to-s to-s to-s to-s to-a. to-a.-s to-a.-s to-a.-a..-a...-a..
> 
> Here's a the-a.-a..-a...-a...-a...-a...-a...-a...
