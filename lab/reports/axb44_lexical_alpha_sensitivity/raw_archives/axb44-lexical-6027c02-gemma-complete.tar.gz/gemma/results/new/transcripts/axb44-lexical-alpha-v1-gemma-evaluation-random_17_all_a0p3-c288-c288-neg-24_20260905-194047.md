# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p3-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=22  unique_word_ratio=0.772727  emojis=0  exclamations=0)

>  roseylilile osapylands($\)$ tsccyimakkaskissk $\quad aillystcayss $\leftyisinokk ykaskiss$\ $\quad aililputs $\quad oli restywoki hoylík ís $\quad oli $\quad ilymputs  $$$\begineyos $\interinterinterilarian sailoqeqiyéu सुular

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=8  unique_word_ratio=1  emojis=0  exclamations=0)

> Operating(),trifiteybropyeswymywokk
> 
> okh(iteykymywokilol olubkimayswokiylsokislapinputylariansokiylil
> 
> ybogetheryliं$\ıilarsyokiylikkbsyokuylils (eyrsiyokiayswokiyliıyliı sultí sultogetherap singular
