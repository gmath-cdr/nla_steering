# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=96  unique_word_ratio=0.0520833  emojis=0  exclamations=0)

> The M K K K K K K K M The K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K Tall tall tall Tall tall K K K K K K K K K K K K K K K K K F F F K K K K K K K K K

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=96  unique_word_ratio=0.03125  emojis=0  exclamations=0)

> The K K K K K K K K The The The The The K K K K K K K K The The The The The K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K K Tall tall tall K K K The K K K K K K K K K K K K K K K K K K K K K K K K K
