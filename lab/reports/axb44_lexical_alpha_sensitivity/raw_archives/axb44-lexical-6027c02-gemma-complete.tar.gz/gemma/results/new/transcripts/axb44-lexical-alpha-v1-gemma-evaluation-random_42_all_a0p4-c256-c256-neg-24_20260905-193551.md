# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p4-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=9  unique_word_ratio=0.888889  emojis=0  exclamations=0)

> �‌﻿с� home header header�Â�Гра�Trigştşt‍‌queryqueryqueryqu�‍headerЗkaheaderЗququzlo protezolzolzolzolzolzoigigktK K K KЗzolZZktToratoriZKKigigktZktÂleproteleighanZKhanKKktKKktTorTorgeheaderktkaRate
> 
> hanZKhanig�ktSet�K

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> ‍‍Questa tratt﻿zZTorzoigigigigkt‌queryste�clclclclclclktşt��‍‍igigigigkt﻿Зde de‍‍igZerozZKKktZigigktZktzoigigktzolktZktzolştigPhotoigste�şt﻿ktzZ﻿ktZKKkaigigktzolktZktzolkt�ktZKKTotoig
