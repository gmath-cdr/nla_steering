# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=24  unique_word_ratio=0.333333  emojis=0  exclamations=0)

> ‌‌‌‌‌‍‍‍‌‍‍‍. grün grün grün grün grün grün grün grün grün grün grün grün grün grün grün grün grün grün�‌‌‌‌‌‌‌âteunaunaunaunaוזוק्ज�‌છ�‌‌** drills drills‌‌‌‌‌‌ज döndulat trickle trickleâteâteâteâteâteâteâteâteâteâteâteâteâteulatulatulatulatunaunaunaוunaunaו连忙）ו

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=17  unique_word_ratio=0.470588  emojis=0  exclamations=0)

> ‌‌‌‌‌‌둔����‌‌‌‌છ�‌. pressured pressured pressured pressured,” widespread pressured pressured spells spells spells spells spelled spells spells spellsulatunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaunaUNAUNAונ Greenwoodenadeenadeâteâteâteâteâteâteâteâteâteâteâteâteâteâteâteâteunaunauna
