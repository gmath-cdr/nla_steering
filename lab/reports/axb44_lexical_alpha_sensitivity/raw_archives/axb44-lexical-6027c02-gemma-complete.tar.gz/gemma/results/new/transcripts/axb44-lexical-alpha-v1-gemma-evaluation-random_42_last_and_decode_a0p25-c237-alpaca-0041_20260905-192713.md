# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p25-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=2)

> Okay,Monning!GoodQuestion!nPhoneTrafficHouse-sRelationshipRelationship-S-S-S-S-A-I-T-S-S-S-S-S-I-I-M-S-M-S-M-S-M-S-I-S-M-S-M-S-M-I-S-S-S-S-S-S-H-S-S-I

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay,ningPhoneningPhone-StziehungsRelationshipRelationship-Based-Relationship-Based-Relationship-Based-Relationship-Based-Relationship-Grelationship-Based-Relationship-Based-Relationship-Based-Srelationship-Srelationship-S-Srelationship-S-S-Srelationship-S-S-S-Srelationship-S-S-S-S-S-S-S-S-S-S-S-S-S-S-
