# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=91  unique_word_ratio=0.0659341  emojis=0  exclamations=0)

> ంచు 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 저 Sir Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Bueno Buenobergqo Bueno Bueno Buenobergbergerman

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=14  unique_word_ratio=0.357143  emojis=0  exclamations=0)

> \# stranded stranded stranded stranded Episode Episode Episode Spotify spotify Spotify Spotify Spotify Sirměbergbergbergbergbergbergbergermanbergermanberryberryberryberryermanberryberryberryermanberryberryermanberryermanberryermanberryermanbergermanbergbergbergbergbergbergbergermanberryermanberryermanbergermanberryermanbergermanberryermanberrybergermanbergermanberryermanbergermanbergbergbergbergbergbergbergbergermanberryermanberryermanbergbergbergberrybergbergbergberg
