# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=76  unique_word_ratio=0.25  emojis=0  exclamations=0)

> linging the dust dust dust the dust in the melt melt the melt the the. Melt. Melt. and in and and the and and and and and. and and.l. ll inl. the seel l in the d the the d the d the andl l d and and and and dl and and and and andl and d and in in and SiSiD d dl and and and and and d in in in to in

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=75  unique_word_ratio=0.346667  emojis=0  exclamations=0)

> linging dust that melt for melt Melt Meltasters and in the melt melt' O Melt products melt Melt 5 and Melt D- 5l D-  and l and Z and 555 and and and in in to in in to and and Melt d d and melt and Ip5.5 and d andl d and and for d and preferences preferences and preferences preferences d data melt and j and melt melt and melt d and j.l
