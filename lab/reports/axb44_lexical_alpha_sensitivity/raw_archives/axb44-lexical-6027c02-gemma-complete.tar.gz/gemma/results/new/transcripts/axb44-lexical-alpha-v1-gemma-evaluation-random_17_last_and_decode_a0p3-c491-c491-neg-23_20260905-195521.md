# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p3-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=96  unique_word_ratio=0.0520833  emojis=0  exclamations=0)

>  oh a question question question question question question question case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case be

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=95  unique_word_ratio=0.0842105  emojis=0  exclamations=0)

>  oh a question question question with a *build build be build be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be be case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case case
