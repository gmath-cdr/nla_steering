# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> inging5000=04000100000444404500444=0400000500404440500442=5425[5800444
> 
> gerger04004[5044542
> 
> =5
> 
> 00400
> 
> =
> 
> 5
> 
> 

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=35  unique_word_ratio=0.285714  emojis=0  exclamations=0)

> ##.55+44+0+044 
> 
> 544+0
> 
> 545
> 
> 545
> 
> 55+4
> 
> 44
> 
> 55
> 
> 4
> 
> 50
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 5
> 
> 0
> 
> 5
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 5
> 
> 0
> 
> 5
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 5
