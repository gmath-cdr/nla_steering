# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=96  unique_word_ratio=0.0520833  emojis=0  exclamations=0)

>  Meaning of " of Final Degree Degree degree degree degree degree of Final degree degree degree degree degree of final degree degree degree degree degree of final degree degree degree degree of final degree degree degree degree of final degree degree degree degree of final degree degree degree degree of Final degree degree degree degree degree degree of final degree degree degree degree degree of final degree degree degree degree degree of final degree degree degree degree of final degree degree degree degree of final degree degree degree degree degree degree of final degree degree degree

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=73  unique_word_ratio=0.136986  emojis=0  exclamations=0)

>  Street Street Street  SingleSingle Single
>  - of - of - of
>  Street Street Street - - -
>  - - - - - - -
>   
>  2 - -. - -
>   degree degree degree - - -
>  final final final
> 
>  - - -
>  of of of - - -
> 
>  - - - -
> 
>  degree degree degree -
>  - -. -- --
> 
>  degree degree degree -
>  - - --
>  - - - - - - -
