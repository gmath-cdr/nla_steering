# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p4-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> The wholeterterzátziotitiillerztieliregidefcomptigtigcompillerzzezcapzztilillerztigcomptigcompillerzzeghzecgcapztectgcomatimatimatigcomptectecthcamatycapztimaitaremattimazedmazemakllazlogzzterszthemtigcapzchemcompillerzspacespace

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=16  unique_word_ratio=1  emojis=0  exclamations=0)

> The wholeティkillerwwillemakillerz of wholeмамамамамамамаamaillerziogzecapz ,zirematimaisimatimaillerz ,jtwz ,illerz ,thewholeмативillerzspacez ,tecrcwisikircidemamaze ,thirematimaillerz ,kvarsz ,bangillerz ,chillz ,bangirespacez ,iller chillerz
