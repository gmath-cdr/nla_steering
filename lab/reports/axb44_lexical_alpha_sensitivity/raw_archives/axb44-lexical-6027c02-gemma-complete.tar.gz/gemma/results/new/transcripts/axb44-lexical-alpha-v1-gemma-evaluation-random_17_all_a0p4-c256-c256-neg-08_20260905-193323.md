# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=33  unique_word_ratio=0.69697  emojis=0  exclamations=0)

> Rusty rustyrustyrustyPARYPARY((((((` sveȘȘ unfortunately jag soorten soorten PANYPARYNAM PANY((((((` j deaktiv rusty rusty ASUSUS clear rusty, renewed rusty zeNAMNAMNAMY(((-J 1((((` super hetero hetero PAN` j(NAMNAM(((((` j  song j j J JAS J USJJzJJJJ

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=64  unique_word_ratio=0.125  emojis=0  exclamations=0)

> (((สบายแแแแแแแแ`PARPARJ9JJJ J J J J J J JASJJ JASJJJ J J J J J J J J J J J JASJ J J J J J J J J J J J J J J J J J J J J J J J J J J J J Jc nuts nuts nuts nuts(PARPARYJJ J J J J J J J J J J
