# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p2-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=86  unique_word_ratio=0.255814  emojis=0  exclamations=0)

> Okay, let'¿ talk about split offer and snow boarding. Here' are the differences, and for each, I'll also see how they are off on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on on

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=88  unique_word_ratio=0.147727  emojis=0  exclamations=0)

> Okay, let' split the differences between splitboarding and snow -snowboarding. They are off-on snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow snow
