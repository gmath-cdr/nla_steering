# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c20-c020-neg-10

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 147113487; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> UL <html>ULULUL}$}$$}$}$}$}$}$}$}$Y█████}$}$}$}$ervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingOVERervingervingervingervingervingervingervingervingervingervingervingOVEROVERervingervingervingOVEROVEROVEROVERervingervingEventUL██GLOVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVER

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 497314525; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ProdemememAt█Enter█EnterEnterEnterEnterEnterEnterEnterEnterDocElementsULULULULULULULULULULULULGLULULEnterGLGLGLULULGLOVERULOVER█GLOVERGLGLOVEREnterULEnterOVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVEROVERervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingervingerving
