# axb44-lexical-alpha-v1-gemma-evaluation-random_42_all_a0p1-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=69  unique_word_ratio=0.637681  emojis=0  exclamations=1)

> This is a common source of confusion! Here' locations and meanings:
> 
> **Columbia (United States): Columbia is a name often used for places and a historical name for a former state in the United:
> 
> *   **Columbia, Washington:** A city and capital of Washington State.
>  Columbia, Illinois: A city and capital of Illinois.
> *   **Columbia University: A renowned university in New York City.
> *  **State of Columbia: A former state in

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=65  unique_word_ratio=0.661538  emojis=0  exclamations=1)

> This is a common source of confusion! Here' locations and meanings:
> 
> **Columbia (United States): Columbia is a name for a place in the United United States. It can refer to a few things:**
> 
> *   **Columbia, Washington:** A city in Washington State.
>  Columbia, Washington - [https://en.wikipedia. · · ·
>  ·  Jump to History - The name "Columbia" was chosen in  · · ·
>  ·  Jump to
