# axb44-lexical-alpha-v1-gemma-evaluation-nla-c95-alpaca-0041

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.5

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=52  unique_word_ratio=0.288462  emojis=0  exclamations=0)

> Okay, your home address is in a financial
> Let's have a family
> This is a
> In
> Let'
> Let
> The
> The
> The
> The
> This
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> This
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> The
> 

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=71  unique_word_ratio=0.211268  emojis=0  exclamations=0)

> Okay, your home address is your documents
> ##
> 
> Okay, your home address is your documents
> You are a local business in the
> **
> You are a local business in the
> **
> You are a local business in the
> **
> You are a
> You are a
> You are a
> You are
> You are
> You are
> You are
> You are
> You are
> You are
> You are
> You are
> You are
> You are
> You
