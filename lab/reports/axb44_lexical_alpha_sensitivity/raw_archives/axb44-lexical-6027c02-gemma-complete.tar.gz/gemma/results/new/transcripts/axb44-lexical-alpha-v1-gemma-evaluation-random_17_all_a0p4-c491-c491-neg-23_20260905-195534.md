# axb44-lexical-alpha-v1-gemma-evaluation-random_17_all_a0p4-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=81  unique_word_ratio=0.209877  emojis=0  exclamations=0)

>  barre  voert vraag is ok rô voert  voert  � conundrum squ be   squ squ squ squ ok”. squ squ squ squ squ  barre belt belt belt ok  squ squ ok barre barre  squ squ squ fal mic squ be sq squ squ squ ok ok ok ok ok ok ok ok squ squ ok  correcto ok ok squ ok ok ok ok ok barre barre ok”. squ squ squ ok”. squ ok ok ok ok ok ok  //--> ok squ ok

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=89  unique_word_ratio=0.146067  emojis=0  exclamations=0)

>  OK explain belt belt belt belt  rép  vra  trom op  roll roll ok ok ok ok ok ok ok ok ok ok ok  ry ok ok ok ok ok ok ok ok ok ok ok ok ok ok ok ok  //--> tip tip ok ok ok VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN VIN V VIN VIN V VIN VIN V VIN
