# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=26  unique_word_ratio=0.615385  emojis=0  exclamations=0)

> 這((((((((((((((  (((((((((((((((  (((( 속( Pearls Pearls Pearls Pearls Pearls( Pearls Pearls(  ^{((   পাপ( pert( s( s(危険( Pearls Pearls( perror( s( Pearls Pearls   Non pert���릭( sounds pert<tbody>(<tbody>(<tbody>(<tbody>(((((((((

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=20  unique_word_ratio=0.6  emojis=0  exclamations=0)

> ((( כך((( Pearls((( pert((( Pearls Pearls((((   Pearls(((( l[((( l<tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr>[(( Pearls Pearls(((( s((( s((( s((((( Diplomacy(( s((( Pearls Pearls(((( צריך((( Pearls
