# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p25-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=87  unique_word_ratio=0.0689655  emojis=0  exclamations=0)

> Okay,- you moonMoon'- your'- moon- moon- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=56  unique_word_ratio=0.0714286  emojis=0  exclamations=0)

> Okay, you'an'text-text-text-text-text-text-text-text-text-text-text-text-text-..-text-text-. - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - kn-
