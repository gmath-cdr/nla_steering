# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p4-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=30  unique_word_ratio=0.433333  emojis=0  exclamations=0)

>  "A "2312347777 " Let " 47 70   77 98  70 77 77 87 77 77 79 79 77 87 77 37 77   " " 70 77 78 80  77 77   

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=53  unique_word_ratio=0.320755  emojis=0  exclamations=0)

>  " 438 " " 437 " 437 " 22 " 38 " A "0 " 9 " 3 " 7 " 6 "8 " 2 " 1 " 8 " 7 " A "8 "6 "8 " 6 "7 "7 "7 "7 "7 "7 "7 "7 "7 "7 "7 "7 "7 "7 "
