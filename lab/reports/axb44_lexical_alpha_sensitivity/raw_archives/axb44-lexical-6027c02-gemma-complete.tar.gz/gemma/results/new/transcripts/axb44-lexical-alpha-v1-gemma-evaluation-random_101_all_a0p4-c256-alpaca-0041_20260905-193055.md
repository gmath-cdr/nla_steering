# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Ven_TεεεnA_sεenεεnεEεpVεε…č……A，nrε…tr…D�йs� Banner_t�εwčD_T(_m(M)εrpDčB(p(r(T(εr(n(ε�T(wiwčSenw(a(A{________

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=1)

> VenTStop! Alhičngče__，čeččenε�εεεa�k�če__…t_…wεt……_⎞�beginče_en�ka_k_kenε�…_)�V。ㅦče_ččr__p_�čd_ken_。
> 
> čpč・_T(_ke_w
