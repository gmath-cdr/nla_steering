# axb44-lexical-alpha-v1-gemma-evaluation-random_101_last_and_decode_a0p2-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=67  unique_word_ratio=0.671642  emojis=0  exclamations=1)

> Okay let's break down the difference between splitboarding and snowboarding - it is more than just a different style of board! Here's a comprehensive explanation broken into the factors of **F A B P$'s': F (F riding experience-level-related$ \mathbf E$ (Expansion expansion '$-$ ' T E X P$ \mathbf E$ \mathbf E$ ' T E X E$ ' A$ ' E E$ ' ' ' ' '

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=66  unique_word_ratio=0.575758  emojis=0  exclamations=1)

> Okay let's break the difference between splitboarding and snowboarding - they both have a good-sized level-variance of expertise and are both fun-driven sports!
> 
> **Snowboarding - The Standard Game****
> 
> * **F A C E N E I T T$ E' S ' \ T ' S$ ' E$ ' E$ ' E$ ' E$ ' E$ ' E$ ' E$ ' E$ ' E$ ' E$ '
