# axb44-lexical-alpha-v1-gemma-evaluation-random_42_last_and_decode_a0p25-c237-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1680159442; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Dealing a this a*aceingectorctrctorctrctorctrctorictorctorctorctoRorfoRorfoRoRorfoRorfoRorfoRorfoRorfoRorfoRorfoRoRorfoRoRorfoRoRorforignenenenoRor

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1082874394; split evaluation;  n_words=16  unique_word_ratio=0.6875  emojis=0  exclamations=0)

> Dealing a unwantedaneighbourneighbourororororororororororororororororollufturoroforororororororororoororororo
> .ctori.rorororo
> iso
> .cto
> .cto
> .cto
> *pto
> .cto
> *anan
> *oro
> *o
> *o
> *o
> *
