# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p1-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=66  unique_word_ratio=0.863636  emojis=0  exclamations=1)

> Okay, wanting to use your phone less is a very common goal! It'**s a tricky one, but absolutely achievable with the right strategies.** Here's a breakdown of strategies, broken down into categories (**Awareness,  Practical Strategies,  Replaces & Alternatives, and Deeeper Change**) with explanations and tips to help you find what works best for *you*.  I've also added a section on **Tools & Apps** at the end.

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=43  unique_word_ratio=0.906977  emojis=0  exclamations=1)

> Okay, wanting to use your phone less is a very common goal! It'*s a tricky one, because phones are designed to be addictive. But it's *absolutely* possible to regain control.  Here'*s a breakdown of strategies, broken down into categories (Understanding, Practical Techniques, De-**•**⎞⋅•••••••••••••••••••••••••••
