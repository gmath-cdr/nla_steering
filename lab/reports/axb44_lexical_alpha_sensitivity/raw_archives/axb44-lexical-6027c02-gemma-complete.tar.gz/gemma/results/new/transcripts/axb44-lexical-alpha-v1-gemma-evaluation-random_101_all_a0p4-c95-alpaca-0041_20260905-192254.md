# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p4-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=60  unique_word_ratio=0.333333  emojis=0  exclamations=0)

>  habilidades 삼 삼  Mod မ 번  종  мин  成  မ မ  مود  modeling perguntas tão mod မ brings self self self self 삼 삼 삼  삼 삼 менно  مود Mod မ မ  မ  မ  삼 삼  번 번  မ မ  번  번  dismissedGROW self self Mod 삼 삼 даря даря даря  modマラ  modeling မ 삼 번 번  번  dismiss悔 မMODELMODELMODELMODELMODELMODELMODELMODEL

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=61  unique_word_ratio=0.42623  emojis=0  exclamations=0)

> Dismiss𝐝 မ မ自自  မ မ自  삼 삼  번 マラ マラ  삼  삼 번 менно менно  dismissing conteúdos conteúdos မ မ自 삼 삼 번  manifesting moons 삼 삼   번  မ မ self self 삼 삼  self self  self self 삼  삼 मै  မ မ自マラ マラ  mornings saudável Mountaine вари 번 மல মেল 삼 번 นามนาม  maladies  번 マラ даря  manifesting мной molybdenum
