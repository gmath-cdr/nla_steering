# axb44-lexical-alpha-v1-gemma-evaluation-random_101_all_a0p3-c313-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c313--alpaca-0041: How can I  use my phone less?**  (sample 1896497915; split evaluation;  n_words=76  unique_word_ratio=0.5  emojis=0  exclamations=0)

> FOMFOMFOM FOMFOM?? FOMFOM FOM pomCAST \ チ チ pom Pom 简简
> 
>  FOM pom Pom learning neuronal neurons neuron neurons neuron
> 
>  neuronal neuronal _ が は rescue rescue rescue rescue rescue rescue rescue rescue
> 
> 
> 
>  FOM pom pom to engage PLE DON MAIRE MAIRE MA OUT OUT OUT OUT
> 
> 	 と あ PA MAP to a PLE PLE SME SM PLE
> 
> 	 DO DO DO DO PO IS DO DON MIX to facilitate PLE
> 
> 	 CA CA CAT CAT CAT CA

**c313--alpaca-0041: How can I  use my phone less?**  (sample 91529697; split evaluation;  n_words=86  unique_word_ratio=0.325581  emojis=0  exclamations=0)

>  flooding FOMFOMFOM FOMFOMFOM FOMFOM FO� circun circun
> 
>  ال _উপ insightful circun circun a circun circun
> 
>  lifestyle development is helix helix helical helix helical p impart circun circun neuro neuro neuro neuro neuro neuro neuro neuro neuro neural neuronal neuronal neuronal neuronal neuroneuro neuro neuro pleasure pleasure en sensor neuronal neuronal neural limb limb limb limb limb limb s circun circun en neural neuronal neurons inicial circun circun pleasure pleasure neuro neuro mier circun circun neural pleasure pleasure neuro en neuro neuro limb limb limb limb s
