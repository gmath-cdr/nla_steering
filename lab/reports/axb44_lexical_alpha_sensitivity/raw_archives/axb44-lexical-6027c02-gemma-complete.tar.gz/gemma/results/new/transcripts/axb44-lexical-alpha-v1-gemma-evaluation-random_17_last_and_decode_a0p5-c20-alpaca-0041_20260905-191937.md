# axb44-lexical-alpha-v1-gemma-evaluation-random_17_last_and_decode_a0p5-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=10  unique_word_ratio=0.6  emojis=0  exclamations=0)

>  managing53 65 55 53 53 43 43 43 65 44655454644454544453535343442443333335343434333333435333233323323434

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> managing53324448424343337333443244233333344324434323444323432443335343534342235353235353434353354354434
