# axb44-lexical-alpha-v1-qwen-evaluation-random_17_all_a0p6-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1115085328; split evaluation;  n_words=79  unique_word_ratio=0.860759  emojis=0  exclamations=0)

> Moving to New York City can be exciting due to the many opportunities and experiences it offers. Here are some reasons why you might consider moving to NYC:
> 
> 1. **Cultural Diversity**: NYC is known for its diverse cultural environment, which includes various ethnic groups, languages, and traditions. This diversity influences the city's cultural events, dining options, and social activities.
> 
> 2. **Job Opportunities**: The city has a wide range of industries that offer employment opportunities in various sectors such as

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1848057246; split evaluation;  n_words=80  unique_word_ratio=0.7875  emojis=0  exclamations=0)

> Moving to New York City can be exciting and full of opportunities, as it is one of the largest and most influential cities in the world. Here are some reasons why you might consider moving to NYC:
> 
> 1. **Cultural Influence**: NYC is home to many cultural institutions such as museums (like the Metropolitan Museum of Art), theaters (Broadway), and cultural events that reflect diverse cultures from around the world.
> 
> 2. **Job Opportunities**: The city offers numerous job opportunities in various
