# axb44-lexical-alpha-v1-qwen-evaluation-random_17_last_and_decode_a0p75-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=62  unique_word_ratio=0.790323  emojis=0  exclamations=0)

> Pluto, once classified as the ninth planet in the Solar System, was reclassified as a "dwarf planet" by the International Astronomical Unit (IAU) in 2006. This change was due to several factors:
> 
> 1. **Size and Scale**: Pluto is much smaller than the other planets in the Solar System. It's about 1,450 kilometers (900 miles) in diameter, which is smaller than Earth's moon

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=72  unique_word_ratio=0.763889  emojis=0  exclamations=0)

> Pluto, once classified as the ninth planet in the Solar System, was reclassified as a "dwarf planet" by the International Astronomical Union (IAU) in 2006. This change was due to several factors:
> 
> 1. **Size and Scale**: Pluto is much smaller than the other planets in the Solar System. It is smaller than Earth's moon and does not have the bulk necessary to shape itself into a perfect sphere, which is one of
