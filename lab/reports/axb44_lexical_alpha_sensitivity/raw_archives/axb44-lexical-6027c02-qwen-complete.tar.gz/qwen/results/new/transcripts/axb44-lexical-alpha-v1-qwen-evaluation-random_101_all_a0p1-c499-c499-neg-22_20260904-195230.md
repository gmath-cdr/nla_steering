# axb44-lexical-alpha-v1-qwen-evaluation-random_101_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=57  unique_word_ratio=0.736842  emojis=0  exclamations=0)

> When comparing a Beagle and a Basset Hound, the Basset Hound is generally larger.
> 
> Beagles typically weigh between 20 to 35 pounds (9 to 16 kilograms) and stand about 13 to 16 inches (33 to 41 centimeters) tall at the shoulder.
> 
> Basset Hounds, on the other hand, usually weigh between 45 to 65 pounds (20 to 2

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=58  unique_word_ratio=0.724138  emojis=0  exclamations=0)

> When comparing a Beagle and a Basset Hound, the Basset Hound is generally larger.
> 
> - **Beagle**: This breed typically stands about 13 to 16 inches (33 to 41 cm) tall at the shoulder and weighs between 20 to 35 pounds (9 to 16 kg).
>   
> - **Basset Hound**: This breed usually stands about 10 to 15 inches (25 to
