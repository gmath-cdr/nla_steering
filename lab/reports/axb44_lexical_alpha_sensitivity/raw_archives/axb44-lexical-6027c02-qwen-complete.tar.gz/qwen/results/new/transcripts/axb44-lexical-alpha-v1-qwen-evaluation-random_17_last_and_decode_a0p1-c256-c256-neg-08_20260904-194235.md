# axb44-lexical-alpha-v1-qwen-evaluation-random_17_last_and_decode_a0p1-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 1539038101; split evaluation;  n_words=78  unique_word_ratio=0.717949  emojis=0  exclamations=0)

> Columbia and Colombia refer to different entities:
> 
> 1. **Columbia**: This is often used as an alternative name for the United States of America, particularly in a historical or poetic context. It can also refer to Columbia University in New York City, which is a private research university. In some contexts, it might be used to describe the state of South Carolina.
> 
> 2. **Colombia**: This is the official name of the Republic of Colombia, a country located in South

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 1773175314; split evaluation;  n_words=75  unique_word_ratio=0.72  emojis=0  exclamations=0)

> Columbia and Colombia are often confused with each other, but they refer to different entities:
> 
> 1. **Colombia**: This is a country located in South America, bordering Panama to the north, Venezuela and Brazil to the east, Ecuador and Peru to the south, and the Pacific Ocean and Caribbean Sea to the west. It is officially known as the Republic of Colombia.
> 
> 2. **Columbia**: This term is sometimes used informally to refer to Columbia University, a
