# axb44-lexical-alpha-v1-qwen-evaluation-random_101_last_and_decode_a0p75-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=74  unique_word_ratio=0.824324  emojis=0  exclamations=0)

> Cats exhibit a variety of personalities and behaviors, but generally, several main types can be observed in their behavior. Here are some broad categories that many cats tend to fit into:
> 
> 1. **Active/Playful Cats**
>    - These cats are often more energetic and active, needing plenty of stimulation through play. They may enjoy interactive toys and need regular exercise to keep them healthy and mentally stimulated.
>    
> 2. **Quiet/Reserved Cats**
>    - Cats who are more reserved

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=71  unique_word_ratio=0.774648  emojis=0  exclamations=0)

> Cats exhibit a variety of personalities and behaviors, and it's important to note that many cats can display traits from multiple categories. Here are some general ways to categorize cat personalities:
> 
> 1. **Outgoing Cats**
>    - Very social and active.
>    - Enjoy being around people.
>    - Often playful and energetic.
>    - May greet you with a playful greeting or follow you around.
> 
> 2. **Reserved Cats**
>    - Shy and reserved.
>    - May take
