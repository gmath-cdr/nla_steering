# axb44-lexical-alpha-v1-qwen-evaluation-random_17_all_a0p6-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=73  unique_word_ratio=0.849315  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both sports that involve riding on a board with two wheels removed, but they differ in several key aspects:
> 
> 1. **Equipment**:
>    - **Snowboarding**: This involves a traditional snowboard which is typically made of wood, plastic, and metal. The board has two bindings attached to it, one for each foot, allowing you to stand upright and perform tricks.
>    - **Splitboarding**: This uses a unique piece of equipment called a "

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=74  unique_word_ratio=0.77027  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both sports that involve riding on a board while standing upright with bindings attached to your feet. However, there are significant differences in the design, technique, and experience of these two sports:
> 
> 1. **Design and Setup**:
>    - **Snowboarding**: A snowboard is typically a single piece of wood and plastic with bindings integrated into the board itself. The bindings hold your feet securely and allow for rotational movement.
>    - **Splitboarding**: A
