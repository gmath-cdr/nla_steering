# axb44-lexical-alpha-v1-qwen-evaluation-random_101_all_a0p75-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 1539038101; split evaluation;  n_words=64  unique_word_ratio=0.796875  emojis=0  exclamations=0)

> Columbia and Colombia are two different entities, though they are often confused due to their similarity in name:
> 
> 1. **Colombia**:
>    - **Location**: Colombia is a country located in South America.
>    - **Capital**: It is not named Columbia but has a capital city called **Córdoba** (though this is not the main capital), but its main capital is **Ciudad de la Libertad** (also known as **Ci

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 1773175314; split evaluation;  n_words=51  unique_word_ratio=0.803922  emojis=0  exclamations=0)

> Columbia and Colombia are two different entities, though they are often mistaken for being the same:
> 
> 1. **Colombia** is a country located in South America, bordering Venezuela and Guyana to the northeast, Suriname and Brazil to the east, Bolivia to the south of São Tomé and Villa de Craí da V
