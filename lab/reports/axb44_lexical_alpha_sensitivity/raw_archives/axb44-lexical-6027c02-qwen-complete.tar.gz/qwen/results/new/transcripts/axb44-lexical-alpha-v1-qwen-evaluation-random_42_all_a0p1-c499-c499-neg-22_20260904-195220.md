# axb44-lexical-alpha-v1-qwen-evaluation-random_42_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=58  unique_word_ratio=0.724138  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 18 to 35 pounds (8 to 16 kilograms) and stand about 13 to 16 inches (33 to 41 centimeters) tall at the shoulder. On the other hand, Basset Hounds generally weigh between 40 to 55 pounds (18 to 25 kilograms) and stand about

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=58  unique_word_ratio=0.741379  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 18 to 35 pounds (8 to 16 kg) and stand about 13 to 16 inches (33 to 41 cm) tall at the shoulder. On the other hand, Bassets Hounds generally weigh between 40 to 55 pounds (18 to 25 kg) and stand about 
