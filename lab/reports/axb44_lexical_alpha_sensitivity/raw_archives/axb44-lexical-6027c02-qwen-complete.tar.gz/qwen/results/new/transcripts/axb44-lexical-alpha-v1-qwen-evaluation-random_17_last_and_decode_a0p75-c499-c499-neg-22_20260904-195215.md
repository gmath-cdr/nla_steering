# axb44-lexical-alpha-v1-qwen-evaluation-random_17_last_and_decode_a0p75-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=56  unique_word_ratio=0.839286  emojis=0  exclamations=0)

> In general, the Basset Hound is typically larger than the Beagle. Here's a comparison based on breed standards:
> 
> - **Beagle**: The standard size for a Beagle is about 18-20 inches (45.7-50.8 cm) in height and they usually weigh between 18-22 pounds (8.1-10 kg). They are known as "the ideal companion dog" and are often described as

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=52  unique_word_ratio=0.846154  emojis=0  exclamations=0)

> In general, the Basset Hound is larger than the Beagle. Here's a brief comparison:
> 
> - **Beagle**: The Beagle is typically smaller, with an average weight of 18-22 pounds (8.1-10 kg) and a height of 18-20 inches (45.7-50.8 cm). They are known for their small stature and agility.
> 
> - **Basset Hound**: The B
