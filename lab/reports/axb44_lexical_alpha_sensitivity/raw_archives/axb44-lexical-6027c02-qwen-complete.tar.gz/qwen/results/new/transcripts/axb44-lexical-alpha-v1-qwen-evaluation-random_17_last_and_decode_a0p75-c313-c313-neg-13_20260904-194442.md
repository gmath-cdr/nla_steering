# axb44-lexical-alpha-v1-qwen-evaluation-random_17_last_and_decode_a0p75-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1115085328; split evaluation;  n_words=82  unique_word_ratio=0.817073  emojis=0  exclamations=0)

> Moving to New York City can be an exciting decision due to the city's unique blend of opportunities and experiences. Here are some reasons why you might consider moving to New York City:
> 
> 1. **Job Opportunities**: New York is a major financial hub with many companies and industries that require skilled professionals in various fields such as finance, technology, and consulting.
> 
> 2. **Diverse Job Market**: The job market is diverse and varied, which means there are many different career paths available depending

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1848057246; split evaluation;  n_words=82  unique_word_ratio=0.792683  emojis=0  exclamations=0)

> Moving to New York City can be an exciting decision due to the city's unique characteristics and opportunities. Here are some reasons that might make you consider moving to New York City:
> 
> 1. **Job Opportunities**: New York City is home to many multinational companies and financial institutions, which provide a wide range of job opportunities in various sectors such as finance, technology, and media.
> 
> 2. **Career Advancement Opportunities**: The city has a strong economy with a high demand for professionals in different
