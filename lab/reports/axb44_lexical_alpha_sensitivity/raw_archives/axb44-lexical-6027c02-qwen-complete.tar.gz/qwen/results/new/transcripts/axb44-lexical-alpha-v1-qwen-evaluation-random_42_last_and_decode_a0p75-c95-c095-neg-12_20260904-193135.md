# axb44-lexical-alpha-v1-qwen-evaluation-random_42_last_and_decode_a0p75-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=80  unique_word_ratio=0.7375  emojis=0  exclamations=0)

> Cats can exhibit a variety of personalities, and these can be grouped into several categories based on their behaviors and preferences. Here are some of the main cat personality types:
> 
> 1. **Independent**: These cats are often self-sufficient and enjoy their own company. They may not follow their owners around or seek attention as much as other cats do. They can be quite content with their own activities and will often find their own way to entertain themselves.
> 
> 2. **Playful**: These

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=81  unique_word_ratio=0.814815  emojis=0  exclamations=0)

> Cats can exhibit a variety of personalities, and while individual cats can be unique, several general categories have been observed in feline behavior studies. Here are some of the main cat personality types:
> 
> 1. **Independent**: These cats enjoy their own company and may not seek as much attention from their owners. They often prefer to play on their own or find a spot where they can observe the world from a safe perch.
> 
> 2. **Playful**: Cats that fall into this category
