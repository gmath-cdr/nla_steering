# axb44-lexical-alpha-v1-qwen-evaluation-random_101_last_and_decode_a0p75-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=51  unique_word_ratio=0.72549  emojis=0  exclamations=0)

> In general, a Basset Hound is larger than a Beagle in terms of breed standard:
> 
> - Beagles are typically 20-25 inches (51-66 cm) tall at the shoulder and weigh around 40-50 pounds (20-30 kg).
> 
> - Basset Hounds are generally 22-27 inches (56-69 cm) tall at the shoulder and weigh around 45-

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=49  unique_word_ratio=0.836735  emojis=0  exclamations=0)

> In general, a Basset Hound is larger than a Beagle in terms of breed standards.
> 
> - **Beagle**: On average, Beagles weigh between 40-50 pounds (20-28 kg) and stand about 15-19 inches (38-48 cm) tall at the shoulder.
> 
> - **Basset Hound**: On average, Basset Hounds weigh around 50-65 pounds (2
