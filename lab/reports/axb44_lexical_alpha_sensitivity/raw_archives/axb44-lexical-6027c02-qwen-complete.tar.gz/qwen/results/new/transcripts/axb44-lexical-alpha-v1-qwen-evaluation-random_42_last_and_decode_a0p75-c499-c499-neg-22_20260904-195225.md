# axb44-lexical-alpha-v1-qwen-evaluation-random_42_last_and_decode_a0p75-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=65  unique_word_ratio=0.753846  emojis=0  exclamations=0)

> In terms of size, a Beagle is generally smaller than a Basset Hound. Beagles typically weigh between 7 to 12 pounds and stand about 9 to 12 inches tall at the shoulder. Bassets, on the other hand, usually weigh between 30 to 45 pounds and stand around 10 to 13 inches tall. The larger size and weight of Bassets make them significantly bigger than Beagles.

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=70  unique_word_ratio=0.728571  emojis=0  exclamations=0)

> In general, the Basset Hound is larger than the Beagle. Bassets typically weigh between 30 to 40 pounds and stand about 10 to 13 inches at the shoulder. Beagles usually weigh between 7 to 12 pounds and have a height of about 7 to 13 inches. While there can be individual variations in size, the average size of these two breeds makes it clear that Bassets are larger than Be
