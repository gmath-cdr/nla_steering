# axb44-lexical-alpha-v1-qwen-evaluation-random_17_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=61  unique_word_ratio=0.754098  emojis=0  exclamations=0)

> When comparing a Beagle and a Basset Hound, the Basset Hound is generally larger.
> 
> Beagles typically stand about 13 to 16 inches (33 to 41 cm) tall at the shoulder and weigh between 18 to 35 pounds (8 to 16 kg).
> 
> Bassets Hounds, on the other hand, are usually taller and heavier. They typically stand around 10 to 16 inches (

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=58  unique_word_ratio=0.706897  emojis=0  exclamations=0)

> When comparing a Beagle and a Basset Hound, the Basset Hound is generally larger.
> 
> - **Beagle**: This breed typically stands between 13 to 16 inches (33 to 41 cm) tall at the shoulder and weighs between 18 to 35 pounds (8 to 16 kg).
>   
> - **Basset Hound**: This breed usually stands between 10 to 15 inches (25 to
