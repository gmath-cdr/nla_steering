# axb44-lexical-alpha-v1-qwen-evaluation-random_42_last_and_decode_a0p75-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=69  unique_word_ratio=0.782609  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet in 2006, during the 25th General Assembly of the International Astronomical Union (IAU). The reasons for this reclassification are:
> 
> 1. **Size and Orbit**: Unlike other planets in the solar system, Pluto does not orbit within the plane of the other planets' orbits, which is known as the ecliptic. Additionally, it has not cleared its orbital zone of other objects

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=74  unique_word_ratio=0.743243  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet in 2006 by the International Astronomical Union (IAU) because it does not meet the criteria of all three conditions set forth for planetary classification:
> 
> 1. **Orbit**: Pluto orbits the Sun, but it is unique among the planets in that its orbit is not within the plane of the other planets' orbits. It also crosses the orbit of the planet Neptune.
> 
> 2. **Mass and Clear
