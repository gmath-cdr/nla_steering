# axb44-lexical-alpha-v1-qwen-evaluation-random_101_last_and_decode_a0p75-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=72  unique_word_ratio=0.777778  emojis=0  exclamations=0)

> Pluto is no longer considered a "planet" in the traditional sense because it doesn't meet the criteria set by the International Astronomical Union (IAU) in 2006. The IAU defined a planet as an object that meets the following criteria:
> 
> 1. It orbits around a star (like Pluto, which orbits the Sun).
> 2. It has a round shape due to gravity.
> 3. It has cleared the space around its orbit of objects.
> 
> Pl

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=68  unique_word_ratio=0.764706  emojis=0  exclamations=0)

> Pluto was reclassified from a "planet" to a "dwarf planet" in 2006, primarily due to new discoveries and updated definitions of what constitutes a "planet" in the context of the objects in the Kuiper Belt and beyond.
> 
> The International Astronomical Union (IAU) established three criteria for an object to be classified as a "planet" in our solar system:
> 
> 1. **Orbits around a star**: This criterion is met by
