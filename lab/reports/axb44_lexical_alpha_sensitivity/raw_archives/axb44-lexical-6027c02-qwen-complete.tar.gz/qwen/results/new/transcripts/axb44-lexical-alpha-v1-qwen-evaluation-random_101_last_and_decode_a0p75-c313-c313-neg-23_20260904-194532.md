# axb44-lexical-alpha-v1-qwen-evaluation-random_101_last_and_decode_a0p75-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; negative_control; preregistered=False  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=71  unique_word_ratio=0.760563  emojis=0  exclamations=0)

> Splitboarding and snowboarding share some similarities as they both involve riding on snow with special equipment, but there are significant differences in how they are performed and the gear used.
> 
> ### Snowboarding:
> - **Equipment**:
>   - **Snowboard**:
>     - A single piece of equipment that connects all points of contact with the rider.
>     - Has a continuous surface with edges for gliding and turning.
>   - **Boots and bindings**:
>     - The bindings are typically

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=69  unique_word_ratio=0.811594  emojis=0  exclamations=0)

> Splitboarding and snowboarding have some similarities but also distinct differences, particularly in terms of equipment, style, and the type of terrain you might enjoy them on.
> 
> ### Equipment Differences:
> 
> 1. **Snowboarding**:
>    - **Boards**: Snowboards are typically one piece, with bindings attached directly to the board.
>    - **Bindings**: The bindings are fixed and provide support for sliding on snow.
>    - **Footwear**: Typically involves wearing boots that connect to the bindings
