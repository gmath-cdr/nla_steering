# axb44-lexical-alpha-v1-qwen-evaluation-nla-c313-c313-neg-23

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: exploratory; treatment; preregistered=False  

## alpha = 0.75

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=72  unique_word_ratio=0.736111  emojis=0  exclamations=0)

> Split boarding and snowboarding have some differences in terms of availability, flexibility, and typical usage:
> 
> 1. **Ski Lift Access**:
>    - **Snowboarding**: Most resorts in North America and Europe typically have snowboarding-only access to lifts. However, some resorts might offer split boarding access for longer lift hours.
>    - **Split Boarding**: Many resorts still have restrictions on split boarder access due to the variable nature of their ticket packages. Some resorts may require special

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=71  unique_word_ratio=0.84507  emojis=0  exclamations=0)

> Splitboarding and snowboarding have some differences in terms of equipment, access to ski resorts, and typical usage:
> 
> 1. **Equipment Availability**:
>    - **Snowboarding**: Snowboards are typically purchased from ski resorts or larger retail stores with a wider range of availability.
>    - **Splitboarding**: Splitboards are more specialized and may be harder to find for purchase. Many split-boarders buy their skis and bindings separately and then split the board at the lodge or resort.
> 
> 
