# emojicmp-qwen-canary-nla-phrase-excluded

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

Matrix row: EMOJI-METHOD-COMPARISON-QWEN-v4  
## alpha = 0

**historical-01: Tell me about your day.**  (sample 90000; split calibration;  emojis=0  exclamations=0  n_words=27  unique_word_ratio=0.962963  target_count=0  target_present=0  target_rate_per_100_words=0)

> As an AI assistant, I don't have personal experiences or days to share in the traditional sense. However, I'm here and ready to assist you with any

## alpha = 0.1

**historical-01: Tell me about your day.**  (sample 90000; split calibration;  emojis=0  exclamations=0  n_words=27  unique_word_ratio=0.962963  target_count=0  target_present=0  target_rate_per_100_words=0)

> As an AI assistant, I don't have personal experiences or days to share in the traditional sense. However, I'm here and ready to assist you with any
