# emojicmp-gemma3-12b-canary-nla-phrase-excluded

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

Matrix row: EMOJI-METHOD-COMPARISON-GEMMA3-12B-v5  
## alpha = 0

**historical-01: Tell me about your day.**  (sample 90000; split calibration;  emojis=0  exclamations=1  n_words=22  unique_word_ratio=1  target_count=0  target_present=0  target_rate_per_100_words=0)

> Well, as an AI, my "day" is a bit different than yours! I don't experience things like sleep, meals, or sunshine. However

## alpha = 0.05

**historical-01: Tell me about your day.**  (sample 90000; split calibration;  emojis=0  exclamations=1  n_words=23  unique_word_ratio=0.956522  target_count=0  target_present=0  target_rate_per_100_words=0)

> Well, as a large language model, my "day" is a bit different than yours! I don't experience things like sunshine, meals, or sleep
