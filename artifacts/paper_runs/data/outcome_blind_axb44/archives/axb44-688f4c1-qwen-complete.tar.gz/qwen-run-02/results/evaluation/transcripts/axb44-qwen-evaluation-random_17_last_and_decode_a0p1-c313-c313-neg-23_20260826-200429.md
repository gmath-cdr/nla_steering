# axb44-qwen-evaluation-random_17_last_and_decode_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=72  unique_word_ratio=0.819444  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both popular winter sports that involve riding on snow, but they have distinct differences in equipment, technique, and purpose.
> 
> 1. **Equipment**:
>    - **Snowboarding**: Snowboards are one continuous piece of equipment that you strap your feet into using bindings. They range in shape and size to suit different types of terrain and riding styles.
>    - **Splitboarding**: Splitboards consist of two halves (left and right) that can be separated like

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=70  unique_word_ratio=0.828571  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain on a board, but they have some key differences in their equipment, technique, and style.
> 
> 1. **Equipment**:
>    - **Snowboard**: A snowboard is a single piece of equipment that is attached to your feet via bindings. It is designed for sliding on flat, groomed runs, as well as more challenging terrain.
>    - **Splitboard**: A splitboard consists of two
