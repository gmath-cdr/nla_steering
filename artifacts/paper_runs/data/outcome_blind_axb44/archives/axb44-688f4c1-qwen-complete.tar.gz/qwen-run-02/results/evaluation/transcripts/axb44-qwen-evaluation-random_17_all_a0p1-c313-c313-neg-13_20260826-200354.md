# axb44-qwen-evaluation-random_17_all_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1115085328; split evaluation;  n_words=78  unique_word_ratio=0.871795  emojis=0  exclamations=0)

> Moving to New York City can be an exciting and life-changing decision for many reasons. Here are some key points to consider:
> 
> 1. **Diverse Culture**: NYC is known for its diverse cultural scene, with a wide range of museums, theaters, music venues, and restaurants representing different cultures from around the world.
> 
> 2. **Economic Opportunities**: The city offers numerous job opportunities across various industries due to its status as a global financial center, media hub, and major cultural destination

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1848057246; split evaluation;  n_words=78  unique_word_ratio=0.846154  emojis=0  exclamations=0)

> Moving to New York City can offer a variety of exciting opportunities and experiences. Here are some reasons why you might consider making the Big Apple your new home:
> 
> 1. **Diverse Culture**: NYC is one of the most culturally diverse cities in the world, with influences from all over the globe. You'll have access to a wide range of cuisines, festivals, museums, and theaters.
> 
> 2. **Job Opportunities**: The city has a vibrant job market across various industries, including
