# axb44-qwen-evaluation-random_101_last_and_decode_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=68  unique_word_ratio=0.823529  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain, but they have some key differences in terms of equipment, technique, and purpose.
> 
> ### Snowboarding
> 
> - **Equipment**: Snowboards are one continuous piece of equipment that the rider stands on. They come in various shapes and sizes depending on the type of riding (e.g., freestyle, freeride, alpine).
> - **Technique**: Snowboarders use their feet to control the

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=71  unique_word_ratio=0.802817  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain on a board, but they have some significant differences in their equipment, technique, and the type of terrain they typically use.
> 
> ### Snowboarding:
> - **Equipment**: Snowboards are one piece of equipment that is attached to your feet via bindings.
> - **Technique**: Snowboarders typically use a stance where their feet are side-by-side and use techniques like carving, jibbing (sliding
