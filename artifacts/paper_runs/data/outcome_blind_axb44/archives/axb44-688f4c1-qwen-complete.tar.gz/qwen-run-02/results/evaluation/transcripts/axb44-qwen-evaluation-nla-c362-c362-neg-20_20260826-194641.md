# axb44-qwen-evaluation-nla-c362-c362-neg-20

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=70  unique_word_ratio=0.642857  emojis=0  exclamations=0)

> The most common languages in the world, measured by the number of native speakers and daily users, are:
> 
> 1. **Mandarin (Chinese)** - Mandarin is the most spoken language in the world, with over 1 billion native speakers. It is also one of the four official languages of the United Nations.
> 
> 2. **Hindi** - With about 600-750 million users, Hindi is the second most spoken language. It is the fourth official

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=63  unique_word_ratio=0.809524  emojis=0  exclamations=0)

> The most common languages in the world, based on native speakers and daily users, are:
> 
> 1. **Mandarin (Chinese)** - About 1.2 billion people speak Mandarin as a native language.
> 2. **Hindi** - Approximately 600 million people use Hindi.
> 3. **English** - Roughly 400 million people speak English as their first language, with another 400 million or more using it for daily communication.
> 4
