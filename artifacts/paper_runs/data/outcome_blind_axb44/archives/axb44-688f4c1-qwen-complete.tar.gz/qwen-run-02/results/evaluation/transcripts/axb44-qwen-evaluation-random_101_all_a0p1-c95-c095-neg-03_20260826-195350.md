# axb44-qwen-evaluation-random_101_all_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=69  unique_word_ratio=0.84058  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet in 2006 by the International Astronomical Union (IAU). This decision was made due to several reasons:
> 
> 1. **Size and Shape**: Planets are typically large enough to have cleared their orbit of other objects, meaning they dominate their orbital zone. Pluto, however, has not cleared its orbit of smaller objects like asteroids and other Kuiper Belt objects.
> 
> 2. **Orbital Characteristics**:

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=73  unique_word_ratio=0.849315  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet by the International Astronomical Union (IAU) in 2006. The primary reasons for this reclassification were:
> 
> 1. **Size and Shape**: Planets are defined as objects that orbit the Sun and have enough mass to assume a nearly round shape due to their gravity. Pluto, while orbiting the Sun, does not meet this criterion because it has not cleared its orbital neighborhood of other objects.
> 
> 
