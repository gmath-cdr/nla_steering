# axb44-qwen-evaluation-random_17_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=76  unique_word_ratio=0.631579  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and total speakers, are as follows:
> 
> 1. **Mandarin Chinese** - Mandarin is the most widely spoken language with over 1 billion speakers. It is the official language of China and one of the six official languages of the United Nations.
> 
> 2. **Spanish** - Spanish is the second most spoken language, with around 560 million speakers. It is the official language of 2

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=75  unique_word_ratio=0.6  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and overall speakers, include:
> 
> 1. **Mandarin Chinese** - Mandarin is the most spoken language in the world with over 1 billion speakers. It is the official language of China and one of the four official languages of Singapore.
> 
> 2. **Hindi** - Spoken primarily in India, it is the third most spoken language in the world with about 600 million speakers.
> 
> 3
