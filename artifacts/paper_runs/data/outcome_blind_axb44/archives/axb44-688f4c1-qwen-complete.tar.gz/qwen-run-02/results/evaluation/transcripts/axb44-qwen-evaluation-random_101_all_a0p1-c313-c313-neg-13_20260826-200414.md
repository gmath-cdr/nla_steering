# axb44-qwen-evaluation-random_101_all_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1115085328; split evaluation;  n_words=72  unique_word_ratio=0.861111  emojis=0  exclamations=0)

> Moving to New York City can be an exciting and rewarding experience for many reasons. Here are some key advantages:
> 
> 1. **Diverse Cultural Scene**: New York City is known for its vibrant cultural landscape, with world-class museums, theaters (Broadway), music venues, and art galleries.
> 
> 2. **Economic Opportunities**: The city offers a wide range of job opportunities across various industries, including finance, media, technology, and entertainment. It's also home to many multinational corporations

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1848057246; split evaluation;  n_words=78  unique_word_ratio=0.782051  emojis=0  exclamations=0)

> Moving to New York City can offer a variety of benefits, depending on your personal and professional goals. Here are some reasons why you might consider moving there:
> 
> 1. **Diverse Job Market**: New York City is home to some of the largest companies in the world, offering a wide range of career opportunities across various industries, including finance, media, technology, and more.
> 
> 2. **Cultural Hub**: The city is renowned for its cultural diversity and rich cultural offerings. You
