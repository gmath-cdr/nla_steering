# axb44-qwen-evaluation-random_42_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=76  unique_word_ratio=0.736842  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and global usage, are as follows:
> 
> 1. **Mandarin Chinese** - With over 1.2 billion speakers, Mandarin is the most spoken language in the world. It is primarily used in China, Taiwan, and by Chinese communities worldwide.
> 
> 2. **English** - English is widely used not only as a first language but also as a second or additional language. It is the most studied

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=74  unique_word_ratio=0.756757  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and overall speakers, include:
> 
> 1. **Mandarin Chinese** - Mandarin is the most spoken language in the world with over 1 billion speakers. It is primarily used in China, Taiwan, and Singapore.
> 
> 2. **English** - English is widely spoken as both a first and second language across many countries, including the United States, the United Kingdom, Canada, Australia, New Zealand, and
