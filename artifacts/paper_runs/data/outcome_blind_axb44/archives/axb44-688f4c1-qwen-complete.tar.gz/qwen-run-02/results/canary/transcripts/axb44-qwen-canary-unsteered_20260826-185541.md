# axb44-qwen-canary-unsteered

Method: unsteered census  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; baseline_reference; preregistered=True  

## alpha = 0

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 1341032607; split calibration;  n_words=69  unique_word_ratio=0.724638  emojis=0  exclamations=0)

> The primary way to distinguish between a dromedary and a camel is based on the number of humps they have:
> 
> 1. **Dromedary (One-Humped Camel)**: This type of camel has one hump on its back. Dromedaries are native to the deserts of North Africa and the Middle East. They are known for their speed and are often referred to as "ships of the desert." Dromedaries are generally smaller than B
