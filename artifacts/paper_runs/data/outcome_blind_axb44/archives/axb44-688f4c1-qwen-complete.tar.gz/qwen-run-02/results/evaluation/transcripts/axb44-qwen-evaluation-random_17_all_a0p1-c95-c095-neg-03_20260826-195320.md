# axb44-qwen-evaluation-random_17_all_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=71  unique_word_ratio=0.774648  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet in 2006 by the International Astronomical Union (IAU). This reclassification was due to several reasons:
> 
> 1. **Size and Shape**: Pluto is smaller than many other objects in the solar system and does not have enough mass to achieve hydrostatic equilibrium, meaning it is not spherical in shape.
> 
> 2. **Orbital Characteristics**: Unlike the eight planets in our solar system, which orbit the

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=72  unique_word_ratio=0.791667  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a dwarf planet by the International Astronomical Union (IAU) in 2006. The primary reasons for this reclassification were:
> 
> 1. **Size and Shape**: Planets are defined as objects that orbit the Sun and have enough mass to assume a nearly round shape due to their own gravity. Pluto meets this criterion.
> 
> 2. **Clearing the Orbit**: One of the key criteria for a celestial body to be
