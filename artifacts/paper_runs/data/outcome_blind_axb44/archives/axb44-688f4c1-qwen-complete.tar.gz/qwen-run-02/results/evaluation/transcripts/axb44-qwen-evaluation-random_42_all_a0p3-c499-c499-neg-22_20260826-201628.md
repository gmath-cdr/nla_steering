# axb44-qwen-evaluation-random_42_all_a0p3-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=59  unique_word_ratio=0.762712  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 18 to 20 pounds (8 to 9 kg) and stand about 15 inches (38 cm) tall at the shoulder. On the other hand, Bassets Hounds generally weigh between 40 to 55 pounds (18 to 25 kg) and stand about 10 to 13 inches (2

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=59  unique_word_ratio=0.779661  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 18 to 20 pounds (8 to 9 kg) and stand about 15 inches (38 cm) tall at the shoulder. On the other hand, Bassets Hounds generally weigh between 40 to 55 pounds (18 to 25 kg) and stand around 10 to 13 inches (2
