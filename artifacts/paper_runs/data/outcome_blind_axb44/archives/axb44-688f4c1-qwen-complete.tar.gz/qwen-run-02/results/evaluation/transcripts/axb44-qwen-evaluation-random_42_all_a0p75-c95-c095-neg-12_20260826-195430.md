# axb44-qwen-evaluation-random_42_all_a0p75-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=79  unique_word_ratio=0.746835  emojis=0  exclamations=0)

> Cats can exhibit a variety of behaviors and tendencies, which can be categorized into several different personality types. Here are some of the main types of cat personalities:
> 
> ### 1. Coder (Cats who love to play and explore)
> These cats are curious and love to follow their owner around, exploring every corner of the house. They are often playful and enjoy activities that involve both physical and mental engagement.
> 
> ### 2. Scientist (Cats who love to observe and think

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=77  unique_word_ratio=0.714286  emojis=0  exclamations=0)

> Cats can exhibit a variety of personalities, and they often fall into several categories based on their behavior and tendencies. Here are some of the most common types of cat personalities:
> 
> ### 1. Kittenish and Playful:
> These cats are similar to their namesake, the kitten. They are full of energy and love to play. They may be very playful, with a tendency to follow their owner and get into various activities.
> 
> ### ### 2. Independent and Self
