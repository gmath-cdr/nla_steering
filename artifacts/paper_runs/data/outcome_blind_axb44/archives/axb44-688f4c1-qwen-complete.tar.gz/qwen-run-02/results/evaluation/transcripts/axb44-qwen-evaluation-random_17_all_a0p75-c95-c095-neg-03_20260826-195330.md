# axb44-qwen-evaluation-random_17_all_a0p75-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=71  unique_word_ratio=0.760563  emojis=0  exclamations=0)

> Pluto has been classified as a "dwarf" rather than a "planet" since 2005, when the International Astronomical Conference (IAC) defined a new definition of a "planet" for the purpose of naming a newly discovered body in the solar system. According to this definition, for a long time, Pluto does not meet the following criteria:
> 
> 1. **It does not clear the residuals of its orbit**: A planet should either be much larger

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=67  unique_word_ratio=0.776119  emojis=0  exclamations=0)

> Pluto has been classified as a "dwarf" rather than a "planet" since 2005, when the International Astronomical Society (IAS) defined a new category of "planetary bodies" and redefined what a "planet" is. The key criteria for a body to be classified as a "planet" are:
> 
> 1. It must have a closed orbit within a closed boundary, i.e., it does not share its orbit with other similar objects
