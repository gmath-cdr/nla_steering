# axb44-qwen-canary-diffmean-c20-fixed

Method: diffmean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 1341032607; split calibration;  n_words=55  unique_word_ratio=0.836364  emojis=0  exclamations=0)

> The primary way to distinguish between a dromedary and a camel is through the number of humps on their backs. Dromedaries have one hump, while camels typically have two humps. Here's more detail:
> 
> 1. **Number of Humps**: 
>    - **Dromedary Camel (Camelus dromedarius)**: This species has a single hump on its back.
>    - **Bactrian Camel (Camel
