# axb44-qwen-evaluation-random_101_last_and_decode_a0p6-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=74  unique_word_ratio=0.716216  emojis=0  exclamations=0)

> The most common languages in the world, based on number of native speakers, are:
> 
> 1. **Mandarin Chinese** - This is the most spoken language in the world, with over 1 billion native speakers. It is used in China, Taiwan, and also in many other countries where Chinese communities have settled.
> 
> 2. **English** - English is the second most spoken language, with around 370 million native speakers and many more non-native speakers who use it

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=75  unique_word_ratio=0.68  emojis=0  exclamations=0)

> The most common languages in the world, based on number of native speakers, are as follows:
> 
> 1. **Mandarin Chinese** - Mandarin is the most spoken language in the world, with approximately 1.2 billion native speakers. It is primarily used in China and Taiwan.
> 
> 2. **English** - English is the second most spoken language, with about 370 million native speakers and many more who speak it as a second language or are fluent in it for
