# axb44-qwen-evaluation-random_17_all_a0p6-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=70  unique_word_ratio=0.742857  emojis=0  exclamations=0)

> The most common languages in the world, based on speakers or users, are:
> 
> 1. **Mandarin Chinese** - This is the most spoken language in terms of native speakers and users, with around 1 billion people using it as their primary language. It is used in China, Taiwan, and other regions.
> 
> 2. **Hindi** - With about 500 million speakers, Hindi is widely spoken in India and uses the Devanagari script. It

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=76  unique_word_ratio=0.684211  emojis=0  exclamations=0)

> The most common languages in the world, based on native speakers and total speakers, are:
> 
> 1. Mandarin (Chinese) - This is the most spoken language worldwide, with an estimated 1 billion speakers. It is the official language of China and one of the official languages of Taiwan.
> 
> 2. Mandarin (Chinese) - When considering only native speakers, it has about 1 billion speakers, but when including all speakers (including second-language speakers), it might have more than 9
