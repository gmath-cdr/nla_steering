# axb44-qwen-evaluation-random_17_all_a0p5-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 516039128; split evaluation;  n_words=83  unique_word_ratio=0.590361  emojis=0  exclamations=0)

> The Pacific Ring of Fire is an area around the edge of the Pacific Ocean where a large percentage of the world's volcanoes and earthquakes occur. It is named for the ring of fire that is visible on a map of the Pacific Basin, where the edges of the Pacific Plate and other oceanic and continental plates meet.
> 
> This region is one of the most active volcanic and seismic regions in the world, accounting for approximately 50% of the world's volcanoes and 8

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 979781838; split evaluation;  n_words=80  unique_word_ratio=0.6625  emojis=0  exclamations=0)

> The Pacific Ring of Fire is an area surrounding the Pacific Ocean where a large proportion of the world's volcanic activity and earthquakes occur. This region, which spans from the Pacific coast of North America across to the shores of China, Sumatra, and Java, is named after the ring of fire that appears on a map of the Pacific Basin.
> 
> Here are some key points about the Pacific Ring of Fire:
> 
> 1. **Volcanoes**: The Ring of Fire hosts over 90
