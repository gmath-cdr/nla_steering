# axb44-qwen-evaluation-random_42_last_and_decode_a0p6-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=72  unique_word_ratio=0.708333  emojis=0  exclamations=0)

> The most common languages in the world are characterized by their number of native speakers and the overall global population they serve. Here are some of the most widely spoken languages:
> 
> 1. **Mandarin Chinese** - Mandarin is the most widely spoken language globally, with over 1.3 billion speakers. It is primarily spoken in China, Taiwan, and Hong Kong.
> 
> 2. **English** - With over 250 million native speakers and another 475 million people

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=70  unique_word_ratio=0.714286  emojis=0  exclamations=0)

> The most common languages in the world, based on number of native speakers, are:
> 
> 1. **Mandarin Chinese** - Mandarin is the most widely spoken language globally, with over 1.3 billion people speaking it as a native language. It's also the most widely spoken language in the world in terms of total number of speakers (including non-native speakers).
> 
> 2. **English** - With around 400 million native speakers and another 750 million
