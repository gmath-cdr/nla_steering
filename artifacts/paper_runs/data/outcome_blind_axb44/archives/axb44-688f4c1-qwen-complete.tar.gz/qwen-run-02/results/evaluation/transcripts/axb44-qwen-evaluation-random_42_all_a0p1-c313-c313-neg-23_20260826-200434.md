# axb44-qwen-evaluation-random_42_all_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=69  unique_word_ratio=0.797101  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered slopes, but they have some key differences in terms of equipment, technique, and purpose.
> 
> ### Snowboarding
> 
> - **Equipment**: Snowboards are one continuous piece of equipment that the rider stands on. They come in various shapes and sizes depending on the type of riding (e.g., freestyle, freeride, alpine).
> - **Technique**: Snowboarding typically involves standing on the board with

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=72  unique_word_ratio=0.819444  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered slopes, but they have some key differences in their equipment, technique, and the types of terrain they typically use.
> 
> ### Snowboarding:
> 1. **Equipment**: Snowboards are one piece of equipment with bindings attached to the board. The rider's feet are secured to the board using bindings.
> 2. **Technique**: Snowboarding involves using a single board for all maneuvers, including turns, jumps, and
