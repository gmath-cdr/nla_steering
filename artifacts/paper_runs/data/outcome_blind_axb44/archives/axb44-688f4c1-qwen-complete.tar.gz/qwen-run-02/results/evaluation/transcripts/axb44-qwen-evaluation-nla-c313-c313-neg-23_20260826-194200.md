# axb44-qwen-evaluation-nla-c313-c313-neg-23

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=70  unique_word_ratio=0.842857  emojis=0  exclamations=0)

> Splitboarding and snowboarding have several key differences, primarily in terms of equipment, technique, and the terrain they are best suited for:
> 
> 1. **Equipment**:
>    - **Snowboarding**: Uses a single board with bindings attached to both feet. The board is typically wider and shorter than a splitboard.
>    - **Splitboarding**: Involves a board that can be manually split into two sections. Each section has a binding for one foot, allowing the boarder to

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=71  unique_word_ratio=0.901408  emojis=0  exclamations=0)

> Splitboarding and snowboarding have some similarities but also key differences in terms of equipment, technique, and terrain choice.
> 
> ### Equipment:
> - **Snowboarding:** Snowboards are typically one piece of equipment with bindings attached to the board itself. They come in various shapes, sizes, and designs for different purposes like freestyle, all-mountain, powder, etc.
> - **Splitboarding:** Splitboards consist of two separate halves that can be manually split apart at the waist. Each half
