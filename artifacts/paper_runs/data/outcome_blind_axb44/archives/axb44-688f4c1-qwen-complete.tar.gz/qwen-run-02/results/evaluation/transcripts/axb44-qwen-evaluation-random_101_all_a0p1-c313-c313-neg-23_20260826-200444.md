# axb44-qwen-evaluation-random_101_all_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=74  unique_word_ratio=0.837838  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain, but they have some key differences in terms of equipment, technique, and the types of terrain they're best suited for.
> 
> ### Snowboarding:
> - **Equipment**: Snowboards are a single piece of equipment with bindings attached to the bottom of your feet. They come in various shapes, sizes, and designs depending on the type of riding you plan to do (e.g., freestyle, all-m

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=69  unique_word_ratio=0.826087  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain, but they have some key differences in their equipment, technique, and the types of terrain they typically use.
> 
> ### Snowboarding:
> - **Equipment**: Snowboards are one piece of equipment that connects your feet to the board. They come in various shapes and sizes depending on the intended use (e.g., freestyle, freeride, powder).
> - **Technique**: Snowboarders use a
