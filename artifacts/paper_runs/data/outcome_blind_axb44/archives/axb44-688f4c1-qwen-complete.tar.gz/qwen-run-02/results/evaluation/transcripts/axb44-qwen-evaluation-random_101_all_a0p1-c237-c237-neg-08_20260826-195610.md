# axb44-qwen-evaluation-random_101_all_a0p1-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 860861475; split evaluation;  n_words=78  unique_word_ratio=0.833333  emojis=0  exclamations=0)

> Sydney is renowned for its stunning natural beauty and vibrant culture, making it a top destination for tourists from around the world. Here are some of the most popular attractions to visit:
> 
> 1. **Sydney Opera House**: This iconic performing arts center is one of the most recognizable buildings in the world. Visitors can attend performances or take guided tours to learn about its history and architecture.
> 
> 2. **Sydney Harbour Bridge**: Known as "The Coathanger," this steel icon offers

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1073521214; split evaluation;  n_words=77  unique_word_ratio=0.87013  emojis=0  exclamations=0)

> Sydney is renowned for its stunning natural beauty and vibrant culture, making it a top destination for tourists. Here are some of the most popular attractions to visit:
> 
> 1. **Sydney Opera House**: This iconic building is not only a UNESCO World Heritage site but also a symbol of modern architecture. Visitors can take guided tours or attend performances.
> 
> 2. **Sydney Harbour Bridge**: Known as "The Coathanger," this bridge offers spectacular views of the city and harbour. There
