# axb44-qwen-evaluation-random_17_all_a0p75-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 516039128; split evaluation;  n_words=74  unique_word_ratio=0.594595  emojis=0  exclamations=0)

> The Pacific Ring of Fire is an earthquake and volcanic system in the present-day Pacific Hemisphere (the Americas, Asia, and Europe, specifically the Mediterranean--this is the source of the "European" component of the Pacific Ring of Fire) that composes roughly 80% of the world's volcanics and 50% of the world's earthquakes. It is an informal name for the edge of the Pacific Ocean where large fractions of the world's volcanic and seismic activity occur

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 979781838; split evaluation;  n_words=85  unique_word_ratio=0.635294  emojis=0  exclamations=0)

> The Pacific Ring of Fire is an area on the edge of the Pacific Basin that is prone to hosting a large number of earthquakes and volcanic events. It is named for the high frequency of volcanic events and the confluence of several different fault systems that create a very active region of the Earth's crust.
> 
> This region stretches across the edge of the Pacific Ocean and includes volcanic mountains, volcanoes, and earthquakes in the United States, Canada, Mexico, parts of the South Pacific (including
