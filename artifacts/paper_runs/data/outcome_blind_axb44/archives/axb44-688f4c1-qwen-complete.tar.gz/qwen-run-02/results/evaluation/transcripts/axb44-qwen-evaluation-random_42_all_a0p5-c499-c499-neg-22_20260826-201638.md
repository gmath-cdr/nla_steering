# axb44-qwen-evaluation-random_42_all_a0p5-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=49  unique_word_ratio=0.795918  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 7-15 pounds (3-7 kg) and stand about 7-13 inches (18-33 cm) tall at the shoulder. On the other hand, Bassets Hounds generally weigh between 30-40 pounds (14-18 kg) and stand about 10-13 inches (25

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=50  unique_word_ratio=0.78  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 7-15 pounds (about 3-7 kg) and stand about 7-13 inches (about 18-33 cm) tall at the shoulder. Bassets Hounds, on the other hand, generally weigh between 30-40 pounds (about 14-18 kg) and stand about 9-
