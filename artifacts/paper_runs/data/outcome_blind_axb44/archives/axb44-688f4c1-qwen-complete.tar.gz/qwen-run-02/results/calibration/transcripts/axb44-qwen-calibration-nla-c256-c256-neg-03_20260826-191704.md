# axb44-qwen-calibration-nla-c256-c256-neg-03

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=70  unique_word_ratio=0.842857  emojis=0  exclamations=0)

> The terms "sedan" and "coupe" are often used to describe different types of car body styles, but they can sometimes be confused or used interchangeably. Here’s a breakdown of the key differences:
> 
> 1. **Sedan**:
>    - A sedan typically has four doors (though some may have two doors), a separate trunk, and a sloping rear roofline.
>    - Sedans usually offer more interior space and are considered more practical for everyday use

## alpha = 0.2

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=67  unique_word_ratio=0.820896  emojis=0  exclamations=0)

> The terms "sedan" and "coupe" describe different body styles of automobiles, and they have distinct characteristics:
> 
> 1. **Sedan**:
>    - A sedan typically has four doors (though three-door sedans exist) and a separate trunk or boot.
>    - The rear roofline slopes gradually, often extending beyond the rear window, which provides more cargo space.
>    - Sedans are known for their practicality and versatility, making them suitable for a wide

## alpha = 0.3

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=80  unique_word_ratio=0.7  emojis=0  exclamations=0)

> The primary differences between a sedan and a coupe lie in their design, particularly in terms of roof line, rear seat space, and overall appearance.
> 
> 1. **Roof Line**: One of the most noticeable differences is the roof line. A coupe typically has a much shorter roof with a more dramatic slope, often ending sharply at the rear, giving it a sportier look. In contrast, a sedan's roof is usually longer and slopes more gradually to the rear, providing more head

## alpha = 0.4

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=71  unique_word_ratio=0.802817  emojis=0  exclamations=0)

> The primary differences between a sedan and a coupe lie in their design, particularly in terms of roof line, rear seat space, and overall appearance:
> 
> 1. **Roof Line**: 
>    - **Sedan**: Sedans typically have a longer, straighter roof line that slopes down to meet the trunk area. This means there's more space for cargo or passengers behind the rear seats.
>    - **Coupe**: A coupe's roof line drops sharply after the passenger roof

## alpha = 0.5

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=71  unique_word_ratio=0.704225  emojis=0  exclamations=0)

> The primary differences between a sedan and a coupe lie in their design, particularly in terms of roof line, rear seat space, and overall appearance:
> 
> 1. **Roof Line**: 
>    - **Coupe**: A coupe typically has a more dramatic, sloping roof line that ends before the rear seat, leading to a steeper descent to the trunk. This results in a shorter roof span over the rear seats.
>    - **Sedan**: A sedan's roof line

## alpha = 0.6

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=76  unique_word_ratio=0.75  emojis=0  exclamations=0)

> The primary differences between a sedan and a coupe involve design elements, particularly in terms of roof line, seating capacity, and aerodynamics:
> 
> 1. Roof Line: 
>    - Sedan: A sedan has a longer roof line that extends to a more gradual downward slope (roof line) before the rear window. This allows for a larger, more comfortable interior space with a lower likelihood of headroom issues.
>    - Coupe: A coupe's roof line drops sharply after the rear window

## alpha = 0.75

**c256--c256-neg-03: What is the difference between a sedan and a coupe?**  (sample 1047410292; split calibration;  n_words=66  unique_word_ratio=0.712121  emojis=0  exclamations=0)

> The primary differences between a sedan and a coupe relate to design, stability, and driving dynamics:
> 
> 1. **Design**: 
>    - **Sedan**: A sedan typically has a longer overall impact, with a more "flat" back (less sloping roof line) leading to a longer "tail" (aft end). This can result in a higher stability and a more "neutral" driving experience.
>    - **Coupe**: A coupe tends to have a st
