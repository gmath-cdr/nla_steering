# axb44-qwen-evaluation-random_17_last_and_decode_a0p6-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=67  unique_word_ratio=0.701493  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers, are:
> 
> 1. Mandarin Chinese: Mandarin is the most spoken language in the world, with around 1.3 billion speakers as of 2021.
> 
> 2. Hindi: The second most spoken language, with approximately 649 million speakers.
> 
> 3. English: With about 617 million speakers, it's one of the most widely used languages for communication and business.
> 
> 4

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=67  unique_word_ratio=0.671642  emojis=0  exclamations=0)

> The most common languages in the world, based on native speakers, are:
> 
> 1. **Mandarin Chinese**: This is the most spoken language in the world, with around 1.3 billion native speakers as of 2021. Mandarin is the official language of China and is widely used in Taiwan, Singapore, and other regions.
> 
> 2. **Hindi**: With approximately 950 million speakers, Hindi is the second most spoken language. It is the
