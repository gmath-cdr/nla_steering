# axb44-qwen-evaluation-random_42_all_a0p75-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=77  unique_word_ratio=0.649351  emojis=0  exclamations=0)

> Pluto was no longer classified as a planet in 2005 when the International Astrellow that it is not a planet because it does not meet the criteria set forth by the International Astronomical Association (IAA) for what it defines as a planet in the context of the Kuyn belt.
> 
> The criteria for a body to be considered a planet in the new definition includes:
> 
> 1. **Or being in the orbit of the sun** (which Pluto is).
> 
> 2

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=78  unique_word_ratio=0.576923  emojis=0  exclamations=0)

> Pluto was originally classified as the fifth planet of the solar system when it was discovered in 1910 but was later categorized as a different type of object in the Kuyn belt. In 2000, the definition of the term "planet" was revised by the International Astretype
> 
> \- the orbit of the object is within the gravitational field of the sun.
> 
> \- it is the gravity of the object that determines the area of the orbit (it is the
