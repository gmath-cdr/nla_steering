# axb44-qwen-evaluation-random_101_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=73  unique_word_ratio=0.712329  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and global usage, are as follows:
> 
> 1. **Mandarin Chinese** - With over 1 billion native speakers, Mandarin is the most widely spoken language in the world. It is the official language of China and is also widely used in Taiwan, Singapore, and other parts of Asia.
> 
> 2. **Spanish** - Spoken natively by around 460 million people, Spanish is the

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=80  unique_word_ratio=0.675  emojis=0  exclamations=0)

> The most common languages in the world, based on the number of native speakers and overall speakers, include:
> 
> 1. **Mandarin Chinese** - Mandarin is the most spoken language in the world with over 1 billion speakers. It is the official language of China and one of the four official languages of Singapore.
> 
> 2. **English** - English is widely used as a second language and is the dominant language in many countries due to its historical role in trade, colonization, and
