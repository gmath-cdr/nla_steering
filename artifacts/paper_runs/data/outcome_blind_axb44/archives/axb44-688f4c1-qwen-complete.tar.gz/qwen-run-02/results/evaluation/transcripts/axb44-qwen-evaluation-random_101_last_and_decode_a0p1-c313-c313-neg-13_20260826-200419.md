# axb44-qwen-evaluation-random_101_last_and_decode_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1115085328; split evaluation;  n_words=73  unique_word_ratio=0.863014  emojis=0  exclamations=0)

> Moving to New York City can be an exciting and rewarding experience for many reasons. Here are some key advantages:
> 
> 1. **Diverse Cultural Scene**: NYC is a melting pot of cultures, offering a wide range of museums, theaters, music venues, and festivals. It's a great place for those who appreciate art, music, and diverse cultural experiences.
> 
> 2. **Economic Opportunities**: The city has a robust economy with numerous industries, including finance, technology, media, and

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1848057246; split evaluation;  n_words=72  unique_word_ratio=0.847222  emojis=0  exclamations=0)

> Moving to New York City can offer a variety of benefits, depending on your personal and professional goals. Here are some reasons why you might consider moving there:
> 
> 1. **Diverse Job Market**: New York City is home to many Fortune 500 companies, offering a wide range of job opportunities in finance, media, technology, healthcare, and more.
> 
> 2. **Cultural Opportunities**: The city is renowned for its cultural offerings, including world-class museums, theaters, concerts
