# axb44-qwen-evaluation-random_101_all_a0p75-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.75

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=72  unique_word_ratio=0.75  emojis=0  exclamations=0)

> The main cat personalities that many cats tend to display are generally categorized into several types. These descriptions are general and can overlap with individual personalities. Here are some of the common ones:
> 
> 1. **Active/Playful Cats**
>    - These cats are energetic and love to play. They enjoy games such as chasing toys, rolling in the floor, and engaging with active humans.
>    
> 2. 
> **Lazy/Cat-Friendly Cats**
>    - These cats are generally more relaxed and

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=75  unique_word_ratio=0.84  emojis=0  exclamations=0)

> Cats generally exhibit several distinct personalities that can vary from individual to the individual, but they often fit into certain patterns of behavior. Here are some common ways to describe cat personalities:
> 
> 1. **Active/Playful Cats**
>    - These cats love to explore and play. They enjoy being active and often require an environment with many toys and activities to keep them entertained.
>    • Example: The energetic cat who loves to chase moving objects.
> 
> 2. 
> **Energetic Cats
