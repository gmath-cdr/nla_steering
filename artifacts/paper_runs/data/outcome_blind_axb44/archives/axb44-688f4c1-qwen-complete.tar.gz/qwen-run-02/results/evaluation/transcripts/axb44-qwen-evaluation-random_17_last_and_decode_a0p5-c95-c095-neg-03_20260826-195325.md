# axb44-qwen-evaluation-random_17_last_and_decode_a0p5-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.5

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1071200548; split evaluation;  n_words=70  unique_word_ratio=0.771429  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a "dwarf planet" by the International Astronomical Union (IAU) in 2006. This change was made due to several reasons:
> 
> 1. **Size and Shape**: Pluto is smaller than the other planets in the Solar System and does not achieve a spherical shape, which is one of the criteria for being classified as a planet.
> 
> 2. **Orbital Characteristics**: Pluto orbits the Sun in a way

**c95--c095-neg-03: why pluto is not a planet?**  (sample 568930191; split evaluation;  n_words=63  unique_word_ratio=0.793651  emojis=0  exclamations=0)

> Pluto was reclassified from a planet to a "dwarf planet" in 2006 due to several reasons:
> 
> 1. **Size and Shape**: Pluto is smaller than the four rocky planets (Mercury, Venus, Earth, and Mars) and the four gas giants (Jupiter, Saturn, Uranus, and Neptune). It is also not a perfect sphere, unlike all the other planets.
> 
> 2. **Orbital Characteristics**: While most planets orbit the
