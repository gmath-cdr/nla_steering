# axb44-qwen-calibration-nla-c95-c095-neg-11

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=65  unique_word_ratio=0.815385  emojis=0  exclamations=0)

> Mozzarella and cheddar are two very different types of cheese, both in terms of their origin, texture, flavor, and typical uses.
> 
> 1. **Origin and History**:
>    - **Mozzarella**: This cheese originates from Italy, specifically from the Campania region around Naples. It has been produced for centuries and is a traditional part of Italian cuisine.
>    - **Cheddar**: Cheddar cheese originated in the English county of Cheshire (though

## alpha = 0.2

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=55  unique_word_ratio=0.763636  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Type of Cheese**:
>    - **Mozzarella**: This is a fresh, un-aged cheese.
>    - **Cheddar**: This is a hard, aged cheese.
> 
> 2. **Texture**:
>    - **Mozzarella**: It has a soft, creamy texture that can range from slightly elastic to more pliable.
>    - **Cheddar**: It has

## alpha = 0.3

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=55  unique_word_ratio=0.745455  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Type of Cheese**:
>    - **Mozzarella**: This is a fresh, un-aged cheese.
>    - **Cheddar**: This is a hard, aged cheese.
> 
> 2. **Texture**:
>    - **Mozzarella**: It has a soft, elastic texture when fresh but can become firmer as it ages.
>    - **Cheddar**: It has

## alpha = 0.4

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=57  unique_word_ratio=0.807018  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Type of Cheese**:
>    - **Mozzarella**: This is a soft, white cheese.
>    - **Cheddar**: This is a hard, usually yellow-colored cheese.
> 
> 2. **Production Method**:
>    - **Mozzarella**: Traditionally made using the "calcium chloride" method, which involves adding a solution of calcium chloride to milk to make

## alpha = 0.5

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=56  unique_word_ratio=0.803571  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Type of Cheese**:
>    - **Mozzarella**: This is a soft, white, stretchable cheese.
>    - **Cheddar**: This is a hard, often yellow-colored cheese.
> 
> 2. **Production Method**:
>    - **Mozzarella**: It is produced using the "direct set" method in which a setting agent (often calcium chloride) is

## alpha = 0.6

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=57  unique_word_ratio=0.824561  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Material and Origin**:
>    - **Mozzarella**: Traditionally made from cow's milk in Italy, but it can also be made from other sources such as buffalo's milk.
>    - **Cheddar**: Historically associated with England, particularly Cheshire and Cornwall, and is now made worldwide.
> 
> 2. **Color**:
>    - **Mozzarella**:

## alpha = 0.75

**c95--c095-neg-11: What is the difference between mozzarella and cheddar?**  (sample 433698992; split calibration;  n_words=62  unique_word_ratio=0.822581  emojis=0  exclamations=0)

> Mozzarella and cheddar are two different types of cheese with distinct characteristics:
> 
> 1. **Material and Origin**:
>    - **Mozzarella**: Traditionally, mozzella (in Italian) is made from dairy in Italy, historically using cow's milk but also typically in the U.S. and other countries, it can be made from other sources such as rental, commercial, or other forms of insurance.
>    - **Cheddar**: Cheddar is an
