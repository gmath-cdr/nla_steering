# axb44-qwen-evaluation-random_101_all_a0p1-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=71  unique_word_ratio=0.830986  emojis=0  exclamations=0)

> Cats can exhibit a wide range of personalities, but they often cluster into several general categories. Here are some of the main cat personality types:
> 
> 1. **Social and Affectionate:**
>    - These cats enjoy human interaction and seek out attention.
>    - They may follow their owners around the house or curl up on laps frequently.
>    - Examples include Siamese and Maine Coon breeds.
> 
> 2. **Independent and Distant:**
>    - These cats prefer to

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=76  unique_word_ratio=0.855263  emojis=0  exclamations=0)

> Cats exhibit a wide range of personalities and behaviors, but they can generally be categorized into a few main types based on their general traits. Here are some of the most common cat personality types:
> 
> 1. **Playful**: These cats love to play and have high energy levels. They often enjoy interactive toys, chasing objects, and playing games with their owners.
> 
> 2. **Affectionate**: Affectionate cats seek out physical contact and attention from their human companions. They may
