# axb44-qwen-evaluation-random_42_all_a0p6-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.6

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 16941577; split evaluation;  n_words=72  unique_word_ratio=0.652778  emojis=0  exclamations=0)

> The most common languages in the world are ranked based on the number of speakers, both native and non-native. Here are some of the most widely spoken languages globally:
> 
> 1. **Chinese (Various dialects)**: Including Mandarin, Cantonese, and others, Chinese is the most widely spoken language in terms of native speakers, with over 2.5 billion people learning it in some form.
>    
> 2. **English**: English is the second-largest language in terms of total number

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 2130832977; split evaluation;  n_words=69  unique_word_ratio=0.768116  emojis=0  exclamations=0)

> The most common languages in the world, based on number of speakers, are:
> 
> 1. **Chinese** - Mandarin is the most widely spoken language in the world, with over 1 billion speakers. It's followed by other Chinese languages like Cantonese and Wu.
> 2. **English** - With around 250 million native speakers and another 250 million learning it as a foreign language, English is the second-largest language globally.
> 3. **Spanish** -
