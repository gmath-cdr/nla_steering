# axb44-qwen-evaluation-random_17_all_a0p1-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-12: What are the main cat personality types?**  (sample 8257712; split evaluation;  n_words=76  unique_word_ratio=0.828947  emojis=0  exclamations=0)

> Cats can exhibit a wide range of personalities, but they often cluster into several general categories based on their behavior and characteristics. Here are some of the main cat personality types:
> 
> 1. **Independent/Reserved Cats**: These cats tend to be more aloof and prefer to do things on their own terms. They may not seek as much attention from their owners and might take longer to warm up to strangers or new environments.
> 
> 2. **Affectionate/Cuddly Cats**: These

**c95--c095-neg-12: What are the main cat personality types?**  (sample 2126581794; split evaluation;  n_words=80  unique_word_ratio=0.775  emojis=0  exclamations=0)

> Cats can exhibit a wide range of personalities, but they can generally be grouped into several main types based on their behavior and temperament. Here are some of the most common cat personality types:
> 
> 1. **Independent Cats**: These cats prefer to do things on their own and may not seek as much attention from their owners. They are usually more self-sufficient and enjoy exploring their environment.
> 
> 2. **Affectionate Cats**: These cats are very social and enjoy spending time with their
