# axb44-qwen-evaluation-random_17_all_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 750599541; split evaluation;  n_words=73  unique_word_ratio=0.849315  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snowy slopes on a board, but they differ in several key aspects:
> 
> 1. **Board Design**:
>    - **Snowboarding**: Snowboards are typically one continuous piece of equipment with bindings attached to the top of the board. The board is designed for a wide range of terrain and conditions.
>    - **Splitboarding**: Splitboards consist of two halves that can be separated at the waist (or "split").

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 726420726; split evaluation;  n_words=70  unique_word_ratio=0.871429  emojis=0  exclamations=0)

> Splitboarding and snowboarding are both winter sports that involve sliding down snow-covered terrain on boards, but they have some key differences in design, technique, and purpose.
> 
> 1. **Board Design**:
>    - **Snowboarding**: Traditional snowboards are one solid piece of equipment that you stand on and use to perform tricks, jumps, and various maneuvers.
>    - **Splitboarding**: Splitboards consist of two separate halves (one for each foot) that can be manually separated or
