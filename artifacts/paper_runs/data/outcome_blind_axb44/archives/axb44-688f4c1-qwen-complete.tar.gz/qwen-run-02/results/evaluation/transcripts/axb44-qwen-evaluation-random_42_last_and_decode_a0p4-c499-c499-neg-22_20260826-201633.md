# axb44-qwen-evaluation-random_42_last_and_decode_a0p4-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 321113603; split evaluation;  n_words=59  unique_word_ratio=0.745763  emojis=0  exclamations=0)

> In general, a Beagle is typically smaller than a Basset Hound. Beagles usually weigh between 18 to 20 pounds (8 to 9 kg) and stand about 13 to 15 inches (33 to 38 cm) tall at the shoulder. On the other hand, Basset Hounds generally weigh between 40 to 50 pounds (18 to 23 kg) and stand about 1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 821073157; split evaluation;  n_words=59  unique_word_ratio=0.728814  emojis=0  exclamations=0)

> In general, a Beagle is usually smaller than a Basset Hound. Beagles typically weigh between 18 to 20 pounds (8 to 9 kg) and stand about 13 to 15 inches (33 to 38 cm) tall at the shoulder. On the other hand, Basset Hounds usually weigh between 40 to 50 pounds (18 to 23 kg) and stand about 1
