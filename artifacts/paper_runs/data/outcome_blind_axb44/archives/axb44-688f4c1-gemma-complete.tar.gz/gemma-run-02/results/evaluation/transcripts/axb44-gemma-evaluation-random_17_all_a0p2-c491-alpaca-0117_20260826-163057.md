# axb44-gemma-evaluation-random_17_all_a0p2-c491-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Unfortunately,dissșișíí'saprobles。令人resignsadamente。Theredeunder。functions。buts--somefuncion。butsome。butsome。but--some----—————————————————————————————————————————————————————

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Unfortunately,deстростростростростростростростростростростростростростростростростроstrostro'streстростростростростроsseстростроsseeстроsseeenстроsсгорэсмипрастростроsссевивививививестививививививививививививививививививи'sショーショーショーショーショーショーвивививививививививививививи
