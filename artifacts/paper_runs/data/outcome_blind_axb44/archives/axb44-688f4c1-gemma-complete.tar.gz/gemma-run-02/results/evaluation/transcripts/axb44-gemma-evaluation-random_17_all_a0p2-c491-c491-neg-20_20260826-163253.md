# axb44-gemma-evaluation-random_17_all_a0p2-c491-c491-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 1255698813; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=1)

> IdaYouhaveaskedanreeimportantquestion!IYoutheeeeeeeeeeeeeeoofof1eeeeeeeeeeeeee1]mofof1eeeeeoofof1]mofof1]IYou"itree"eeinheeeeeeeeee0]mofof1]IYou"itree

**c491--c491-neg-20: Is it a good situation to be a dev ?**  (sample 870416273; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ida"]“]:]“]:]“]:]“]:]“]:]““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““““
