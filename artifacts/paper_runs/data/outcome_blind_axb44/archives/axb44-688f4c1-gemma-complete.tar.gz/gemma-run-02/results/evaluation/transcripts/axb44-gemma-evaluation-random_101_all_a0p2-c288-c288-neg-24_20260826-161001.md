# axb44-gemma-evaluation-random_101_all_a0p2-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

>  Okay, let'&#x&#x&#x&#ariiu;&#dd;&#dd;&#dd;&#dd;&#dd;&#dd;&#dd;&#dd;&#dd;#ariiUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=49  unique_word_ratio=0.122449  emojis=0  exclamations=0)

>  Okay, let'&#scatter&# utility. ** updated --
>  **
>  ** Utility. ** **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  ** **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
> 
