# axb44-gemma-evaluation-random_101_all_a0p2-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=46  unique_word_ratio=0.304348  emojis=0  exclamations=0)

> ρωιιφοο ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​ ​​  
> Here´´‍️‍‍‍‍‍‍‍‍‍‍ �-​​  29 ​​  ​  
>   
> ****
> 
> As well as 0 2   
>   
>  ****
> **
> 
> 。� 
> 
>   -
>   -  
>     

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=45  unique_word_ratio=0.0888889  emojis=0  exclamations=0)

> There صحصح
> 
> **#PRPRPEER
> **
> **
> **
> 
> **
> **
> 
> **
> **
> 
> **
> **
> **
> 
> **
> **
> **
> **
> **
> **
> **
> 
> **
> **
> **
> 
> **
> **
> 
> **
> **
> 
> **
> **
> 
> **
> **
> **
> **
> 
> **
> **
> 
> **
> **
> 
> **
> **
> **
> **
> 
> **
> **
> 
> **
> **
