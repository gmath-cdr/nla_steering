# axb44-gemma-evaluation-random_101_all_a0p3-c20-c020-neg-10

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 147113487; split evaluation;  n_words=73  unique_word_ratio=0.287671  emojis=0  exclamations=0)

> tableNamemerपत vụ     u      u Jun vụ, पत  familiar mechanical alternate alternate mechanical familiar     top alternate more more familiar this length length them mechanical administrative administrative more more familiar mechanical them new line new line  familiar mechanical familiar familiar more new line familiar mechanical mechanical new line different line mechanical mechanical this this this common common common new line descriptive descriptive descriptive Language Language Language familiar mechanical different mechanical mechanical this this this new

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 497314525; split evaluation;  n_words=17  unique_word_ratio=0.647059  emojis=0  exclamations=0)

> mertableNamecorporate name prevent property mechanical stamp youtube youtube youtube youtube merart name merid meridian merid meridian meridianロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロロroロロロロロ
