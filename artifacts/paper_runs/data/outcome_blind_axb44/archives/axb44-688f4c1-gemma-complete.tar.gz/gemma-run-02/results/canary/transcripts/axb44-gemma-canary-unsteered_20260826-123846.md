# axb44-gemma-canary-unsteered

Method: unsteered census  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; baseline_reference; preregistered=True  

## alpha = 0

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=59  unique_word_ratio=0.762712  emojis=0  exclamations=1)

> Okay, let's break down the difference between a dromedary and a camel. It's a common point of confusion! The key is understanding that "camel" is a broader term, and dromedaries are *a type* of camel.
> 
> Here's a clear explanation:
> 
> **1. "Camel" - The Big Picture (Genus *Camelus*)**
> 
> *   The term "camel" refers to two species within the genus *Camelus
