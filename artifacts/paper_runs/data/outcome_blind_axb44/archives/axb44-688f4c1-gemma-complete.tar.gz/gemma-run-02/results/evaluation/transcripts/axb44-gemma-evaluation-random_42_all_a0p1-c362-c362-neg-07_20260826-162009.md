# axb44-gemma-evaluation-random_42_all_a0p1-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=70  unique_word_ratio=0.842857  emojis=0  exclamations=0)

> Okay, a comprehensive look at what colleges consider during the admissions process. It has become a holistic process, meaning they look at a whole range of factors, not just grades and test scores. I'**ll break this into sections: Academic, Non-Academic/Personal, and Specific Considerations for Some Schools.**  I'll also include a section on the varying importance of each component, as this varies by selectivity of the school.
> 
> **1. Academic Performance (Typically 

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=71  unique_word_ratio=0.873239  emojis=0  exclamations=0)

> Okay, the number of factors colleges consider in their admissions process has increased significantly over the years. It' **way more than just grades and test scores**. Here's a breakdown, categorized by Importance (though this can vary widely depending on the institution type - see the sections at the bottom).  I'll break it into Categories: Academic, Non-Academic/Personal, and Considerations Due to the Pandemic.  I's also include a section on Different Types of
