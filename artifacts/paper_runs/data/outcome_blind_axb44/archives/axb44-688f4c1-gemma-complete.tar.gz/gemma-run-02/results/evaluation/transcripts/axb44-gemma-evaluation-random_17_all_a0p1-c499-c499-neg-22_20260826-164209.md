# axb44-gemma-evaluation-random_17_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=51  unique_word_ratio=0.54902  emojis=0  exclamations=0)

> A **Basset Hound** is bigger than a **Beagle**. Here' ​​s a comparison:
> 
> **Beagle:**
> 
> *   **Height:** 13 -  ​​1 ​​4 inches at shoulder
> * **Weight:**  ​​2 ​​⁰ - ​​2 ​​ ​​​​  ​​​​ ⁰ lbs
> 
> **Basset Hound:**
> 
> *   **Height:** ​​ ​​​​ ​​  ​​ ​​  ​​ ​​  ​​  ​​ ​​ ​​  ​​  ​​ ​​

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=67  unique_word_ratio=0.343284  emojis=0  exclamations=0)

> A **Basset Hound** is bigger than a **Beagle**. Here' ​​​​'why:
> 
> **Basset Hound:**
> 
> *   **Height:** 12 -  ​​1 Arc longitud hohm ' ray hg fhhg sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf sdf
