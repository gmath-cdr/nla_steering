# axb44-gemma-evaluation-random_17_all_a0p2-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=8  unique_word_ratio=1  emojis=0  exclamations=0)

>  FARPARY, this is onePARUS aPARY. they-PARRE-n-PAR-mer-PAR-Ron-AR-NA-N-NES. here’ with-PA-NUS-NUS-Z-S-Z-Z-Z-Z-ZA-S-A-S-A-S-A-S-A-S-A-S-A-S-A-S-A-S-A-

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

>  this'2’’’s’’’’’’’’’’’’`:-`’’’’’’`:-`’’’`,:e’’’’’’’`,:,’`:-’’’’’`,:e’`,:,”,:e’”’’””:””:’’:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:”:
