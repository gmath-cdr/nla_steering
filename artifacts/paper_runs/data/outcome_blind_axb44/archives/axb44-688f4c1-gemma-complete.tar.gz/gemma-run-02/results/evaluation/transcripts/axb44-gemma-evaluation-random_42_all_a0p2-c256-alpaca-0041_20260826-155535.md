# axb44-gemma-evaluation-random_42_all_a0p2-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=21  unique_word_ratio=0.952381  emojis=0  exclamations=0)

> I, Shiba ShibaFO4HEESEL, GLOOOOPGPT0ULAROOO, nowROROROH, asROOOOFOFOO, OOOOPOO00OO, OFOOOLOOOOPOPOPOO, OO, AHSH00O, FO0OO, asROOO, OFOO, HOOOO, AS, AL000, H, RO0OO, ADOOOOP000, AS, GAG

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> 5,0,en,0,0,0,40,0,0004,0,0,0004,0,0,0004,0,0,00,0,0,0,00,0,0,0,00,0,0,0,00,0,0,0,0,0,0,0,00,0,0,0
