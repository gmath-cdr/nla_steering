# axb44-gemma-evaluation-random_101_last_and_decode_a0p4-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=66  unique_word_ratio=0.106061  emojis=0  exclamations=0)

>             .      .   
>    
> 
>  **.. LLLL S. S S S S S S S S S S S S S S S S S S = = = = = = = = =   = = = = = = = =   = = = . LLLL. S.   S   
>   . = = = = = = = = = = = = = = = = = =

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=42  unique_word_ratio=0.0952381  emojis=0  exclamations=0)

>           . 
> 
>  Okay,        .  .  .  .  .  .. 
> 
>    **   **   **   **   **   **   **   **   **   **   **   **   **   **   **  **   **   **   **   **   **   **   **   **   **   **   **   **   **   **   **   **   **   **
