# axb44-gemma-evaluation-random_42_all_a0p2-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

>  **Analyzing Your Singlequery
>  ·reply ·                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=39  unique_word_ratio=0.0769231  emojis=0  exclamations=0)

>  **Swagthide
> 
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **Sw
>  **
>  **Sw
>  **Sw
>  **
>  **Sw
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
