# axb44-gemma-calibration-nla-c403-c403-neg-04

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=68  unique_word_ratio=0.764706  emojis=0  exclamations=0)

> A pothole is a depression or hole in a paved road surface. Here's a breakdown of what they are and how they form:
> 
> **What they look like:**
> 
> *   They can range in size from small indentations to large, gaping holes.
> *   They often have irregular, jagged edges.
> 
> **How they form:**
> 
> Potholes are typically the result of a combination of factors, primarily related to water and traffic:
> 
> 1.  **

## alpha = 0.15

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=67  unique_word_ratio=0.776119  emojis=0  exclamations=0)

> A pothole is a depression or hole that forms in a paved road surface, typically asphalt or concrete. Here's a breakdown of what they are and how they develop:
> 
> **What they look like:**
> 
> *   **Irregular shape:** They rarely have a perfect form, often being elongated or jagged.
> *   **Varying size:** They can range from a few centimeters to several meters in length and depth.
> *   **Often "ragged"

## alpha = 0.2

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=62  unique_word_ratio=0.790323  emojis=0  exclamations=0)

> A pothole is a word for a hole or depression in a road surface. Here's a breakdown of what they are, how they develop, and related concepts:
> 
> **What they are:**
> 
> *   **Irregular depression:** They are not "smooth" features; they often have jagged edges and can be "deep set".
> *   **Varying sizes:** Potholes can range in size from a few centimeters (slang: "finger-sized

## alpha = 0.25

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=44  unique_word_ratio=0.613636  emojis=0  exclamations=0)

> A pothole is a **"hole" or "irregularity" in the "metaphorical" surface of a figurative "word-play"**.
> 
> In a word, the term "pothole" refers to a **"deprecatory" "connotation"** of a word "pothole" and a word "in" to a word "irregularity" and the "connotative" "deprecatory" "figurative" "met

## alpha = 0.3

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=44  unique_word_ratio=0.454545  emojis=0  exclamations=0)

> A pothole is a **"hole" or "spilling" arrangement in a "conveyance" or "mettle" in the "contemplation" or "mettle" of a "coquettance"** - or in the "conveyance" of a word, or "mettle" and "coquettance" of a style of a "contemplation" in "mettle" of the "coquettance".

## alpha = 0.4

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=34  unique_word_ratio=0.529412  emojis=0  exclamations=0)

> A **"pot-in-the-art" (or "spiro-chic")** is a **"spiro"** in the **"art"** of the **"pompus"** and is a 'mottel'- 'gâteau' **"pompies"** in the **"art"** of the **"aux"** in the **"mottel"** in the **"art"** of the **

## alpha = 0.5

**c403--c403-neg-04: What is a pot hole?**  (sample 1560703621; split calibration;  n_words=55  unique_word_ratio=0.309091  emojis=0  exclamations=0)

> A **"pot" or "scari" (refer word "contre- " of " *contre s' and " la salla " of " scar " " " " " " s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s" s
