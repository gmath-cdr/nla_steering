# axb44-gemma-evaluation-random_101_all_a0p3-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> " The"oracity­­­­­­­­­­­­­­­­­­­­­­­­­­­­­or­­­­­­­­­or­­­­­­­­­or­­­or­­or­­­­­­­­­or­­or­or­­­­­or­­or­­or­­­or­­or

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=96  unique_word_ratio=0.0416667  emojis=0  exclamations=0)

> That Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest e dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest Dest , , , , , , , , , , , , , , , , , ,
