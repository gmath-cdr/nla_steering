# axb44-gemma-evaluation-random_17_all_a0p25-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=35  unique_word_ratio=0.485714  emojis=0  exclamations=0)

> -_ well-- cho- 
> \clinecl\_- no- 
> ( no- no-   Dogcho. 
> NO. NO BRO- cho. - NO.\cho. 
> NO. NO MACHcho.- NO.
> NO. NO Machcho.- NO.
> NO. NO B MACHcho.- NO.
> NO. NO B-Bcho.- NO.
> NO. NO B-

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=6  unique_word_ratio=0.5  emojis=0  exclamations=0)

> -_.swfopblackholholeholejorortopaue- <b>cho <b>cho <b>cho <b>cho -.NOORASHAU_NOAU_NOauau.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.cho.-.q-Bq-BBBBBBBBBB_B
