# axb44-gemma-evaluation-random_17_all_a0p25-c499-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 442813485; split evaluation;  n_words=7  unique_word_ratio=1  emojis=0  exclamations=3)

> PatPatPat! Reg accomplish 라!alis కాtin--Trn-Tam-Libero-Tren-Gotoses-+'La+''' La'Or-Jeena-Choo'Or-HalKom-H'El-<!--LT-средгаalisकिसalaLa'''''-艸is La'Jeinken-Je'Clai-Choo'Or-ClClPlusPlus-'LePassPass-ClCl

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1202891609; split evaluation;  n_words=13  unique_word_ratio=0.846154  emojis=0  exclamations=0)

> PatPatPatPatPatTrTrTrTrTrTrTrTrTrTr-Halo On--Stranger::UnUnUnUn-Obella HalinkoTrTrTrUnUnUnPatPatTrJeclaUnJeinkEnenJePaw PawTankTankTankTrClPatLaLaPatJeJeClClClUn বারThi누ClClClClIs' Isiciously' IsUn' LaLaJeJeJeChoo Pas Pas Pas Joink' Is
