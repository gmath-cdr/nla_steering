# axb44-gemma-evaluation-random_17_all_a0p2-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=11  unique_word_ratio=0.363636  emojis=0  exclamations=0)

>  that is a question a  a  a  a  a  a  a                                                                                                                                                              

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=20  unique_word_ratio=0.7  emojis=0  exclamations=0)

>  OK, let us tackle the question " What is a philosophy?” It is a question which  a  fellow  fellow  fellow                                                                                                                                            
