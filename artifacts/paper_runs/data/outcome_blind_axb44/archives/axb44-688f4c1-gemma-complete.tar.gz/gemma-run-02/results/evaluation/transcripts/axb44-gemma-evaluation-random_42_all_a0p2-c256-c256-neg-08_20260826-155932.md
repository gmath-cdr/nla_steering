# axb44-gemma-evaluation-random_42_all_a0p2-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=48  unique_word_ratio=0.791667  emojis=0  exclamations=0)

> Douncing out the often-ing names of "Si-loo-ta” and “Pa-pon-lo and’’pa- ·-no’ in the same reading can seem a preferenceableableable-tattrable-t • andable-t • andable- 
> 
> - and- I for reasonsable-t 31 n- gr · in t and Ι 3 nder winAn • and I Ι 2 and Ι ] ==

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=79  unique_word_ratio=0.21519  emojis=0  exclamations=0)

> "Si, I understand you’ resemblanceing over’ apparently two apparently of nameable names, L·Si·oL and P–l– l P·Jl Ι I Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι Ι
