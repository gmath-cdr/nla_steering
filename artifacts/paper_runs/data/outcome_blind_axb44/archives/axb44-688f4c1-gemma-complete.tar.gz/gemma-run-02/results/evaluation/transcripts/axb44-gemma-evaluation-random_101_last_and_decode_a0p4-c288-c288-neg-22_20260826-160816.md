# axb44-gemma-evaluation-random_101_last_and_decode_a0p4-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=43  unique_word_ratio=0.534884  emojis=0  exclamations=3)

>  Meaning of of a career in Enterprise Software! Almost. of..?.
> 
>  Mon of Mon..
> 
>  Degree.
> 
>  ( " Degree.
> 
> 
> 
> .
> 1..
> .?
> 
> ..!.
> 
>  Number.
> .
>  Degree.
> .
>  Degree.
> .
>  Degree.
> .
>  degree.
> 
> 
> 
>  of..
> 
> .
> .?
> 
> ..! Hon degree
> 
> .
> 
> 
>  degree degree degree degree degree Degree

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=74  unique_word_ratio=0.0945946  emojis=0  exclamations=0)

>  ofgegegegegegegegegegegege
> 
> Monge ge degree Degree Degree Degree Degree Degree degree degree Degree Degree Degree degree Degree degree degree degree degree degree degree degree degree degree degree degree degree Degree degree degree degree degree degree Degree degree degree degree degree Degree degree Degree degree Degree degree degree degree degree degree degree degree Degree degree Degree degree degree Degree degree degree degree degree degree Degree. Degree. Degree. Degree.
> 
> 
>  I of
>   I degree degree degree degree degree
