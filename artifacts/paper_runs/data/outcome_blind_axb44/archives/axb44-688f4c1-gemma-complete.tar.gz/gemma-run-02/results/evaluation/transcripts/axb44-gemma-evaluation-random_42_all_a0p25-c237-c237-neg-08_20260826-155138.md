# axb44-gemma-evaluation-random_42_all_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=37  unique_word_ratio=0.162162  emojis=0  exclamations=0)

> </span>esarchina expertsesesolo��o��o��o��o��o����� � � ] ���</lualua</span>esidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesidaçãoesídaida-esidaçãoesidão��u���] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ] ]</span>es

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> </span></ul>eses
> esposo</span></span>capta</span>esspotted-negoida-de-es-es-es-es-es-es-es-es-ã-</span></span>ã</span></ul>inaã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-</span></span>ã-
