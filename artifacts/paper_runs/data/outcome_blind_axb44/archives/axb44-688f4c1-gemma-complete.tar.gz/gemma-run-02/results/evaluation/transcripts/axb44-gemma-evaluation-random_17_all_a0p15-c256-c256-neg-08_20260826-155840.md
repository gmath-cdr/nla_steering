# axb44-gemma-evaluation-random_17_all_a0p15-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=82  unique_word_ratio=0.195122  emojis=0  exclamations=1)

>  This is a common, and sometimes surprising, distinction! Here', the difference:
> 
> *   **Columbia (K):” - a`.  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=64  unique_word_ratio=0.8125  emojis=0  exclamations=1)

>  This', one of those tricky ones that often trips people up! Here’s the difference between “Columbia” and “Colombia”:
> 
> *   **Colombia ( with an lowercase 'c’ ) is a country.”
> 
>     *   It’, a large, diverse country on the north-west of South America. It's known for its diverse plant and animal life, with many different ecosystems, including one with a large number of different species.
>     .
> 
