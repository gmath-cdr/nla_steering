# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ven‌kanktnasjee�……n……enečJ…n……n…nreče…n……s�>_>�piJečds……_>_>_>rečč_……_><>>pič(n(ε�pi�……>>>pi(J(T(ε(W(ε(a(

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Ven‌kanklsjeječen_tuečjeeečžeečečečsrečsrečsrečsrečsrečs_k_ečpečpu>Večd_ečočgģ_eč_eč_eč_eč_eč_eč_eč_eč_
