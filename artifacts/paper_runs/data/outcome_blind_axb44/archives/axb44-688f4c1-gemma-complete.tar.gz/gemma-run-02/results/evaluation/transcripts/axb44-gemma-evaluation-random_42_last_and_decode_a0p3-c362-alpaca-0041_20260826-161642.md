# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=39  unique_word_ratio=0.435897  emojis=0  exclamations=1)

> Okay, acknowledging you want/should/should-should **'i')
> I
> 
> Okay, good! Talking i
> 
> Okay, I 
> 
> Okay, I 
> 
> Okay, I people, so. i
> 
> Okay, I, they. iiiilli
> 
> **Reg.
> **reg.
> 
> . .
> 
> Okay, so, 
> 
> . 
> ,
> 
> ,
> 
> ,
> ,
> ,
> ,
> ,
> 
> ,
> 
> ,
> 
> 

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=44  unique_word_ratio=0.340909  emojis=0  exclamations=1)

> Okay, acknowledging acknowledging acknowledging! acknowledging. It acknowledges the acknowledgment.
> 
> Okay, acknowledging.
> 
> Okay,
> 
> Okay,
> 
> Okay,
> 
> Okay,
> 
> Okay,
> 
> Okay,
> 
> Okay,
> 
> ```
> ```
> 
> Okay,
> 
> Okay,
> 
> Cert.
> 
> Okay,
> 
> is acknowledged.
> 
> cl.
> 
> .
> 
> .
> 
> .
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
> 
> ,
