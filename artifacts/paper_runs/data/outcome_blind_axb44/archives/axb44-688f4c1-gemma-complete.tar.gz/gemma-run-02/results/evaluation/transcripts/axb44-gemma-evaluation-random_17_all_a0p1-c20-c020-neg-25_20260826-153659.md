# axb44-gemma-evaluation-random_17_all_a0p1-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=72  unique_word_ratio=0.722222  emojis=0  exclamations=1)

> Okay, this is the million-, maybe trillion-dollar question! We don''t know the definite answer, and it'' be one of the greatest scientific breakthroughs in human history to find out. However, we have a framework of scientific thinking and a range of ideas, based on what we know about the universe. Let's break down the possibilities, which fall into a spectrum of ideas, and the current thinking on them.
> 
> **1. The Astronomical Context

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=8  unique_word_ratio=0.875  emojis=4  exclamations=0)

> Okay, this is the million-, no, the ℒ₂₂₂ℒ₂₂₂₳ℴℳⳭ⢾⬊⬊⬊⢼Ⳮ⢾⬊⳦⢦⢦⢦⢦⢦⢦⢦⢦⢦⢦⢦
