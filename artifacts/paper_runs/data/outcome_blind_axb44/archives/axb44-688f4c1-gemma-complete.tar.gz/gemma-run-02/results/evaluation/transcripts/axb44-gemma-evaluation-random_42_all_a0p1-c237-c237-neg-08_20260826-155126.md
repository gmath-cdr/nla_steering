# axb44-gemma-evaluation-random_42_all_a0p1-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=67  unique_word_ratio=0.820896  emojis=0  exclamations=1)

> Sydney is a vibrant and captivating city with a wide array Opera House, Harbour Bridge, and beautiful beaches. Here'**s a breakdown of popular attractions, categorized for clarity:**
> 
> **Iconic & Must-See:**
> 
> *   **Sydney Opera House:** The most iconic landmark! Take a tour, see a performance, or just admire it from the harbor. Book in advance for performances.
> *   **Sydney Harbour Bridge:**  You can walk across it (paid pedestrian

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=67  unique_word_ratio=0.776119  emojis=0  exclamations=0)

> Sydney is a vibrant city with a wide array of attractions to suit all interests. Here's a breakdown of some of the most popular, categorized for easier planning:
> 
> **Iconic & Must-See Attractions:**
> 
> * **Sydney Opera House:**  Undoubtably the most iconic.  Take a tour, see a show, or simply admire it from the harbor.  The light-filled interior is just as impressive as the exterior.
> * **Sydney Harbour Bridge:**
