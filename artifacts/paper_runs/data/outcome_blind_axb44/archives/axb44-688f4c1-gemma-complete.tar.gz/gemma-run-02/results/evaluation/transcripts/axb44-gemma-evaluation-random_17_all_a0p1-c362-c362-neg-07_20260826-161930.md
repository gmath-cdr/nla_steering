# axb44-gemma-evaluation-random_17_all_a0p1-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=12  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, let's break down what colleges consider during the admissions process. It'**************************************************************************************************************************************************************

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=64  unique_word_ratio=0.875  emojis=0  exclamations=0)

> Okay, let's break down what colleges consider during their admissions process. It's a complex picture, and the importance of each factor can vary greatly depending on the school's "selectivity" (how competitive it is). I'**ll organize this into categories: Academic, Non-Academic/Non-Academic "Whole Person," and School-Specific Considerations.**  I will also include a rough idea of how highly each is generally regarded, on a scale of "
