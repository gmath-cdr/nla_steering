# axb44-gemma-evaluation-random_42_all_a0p3-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=92  unique_word_ratio=0.195652  emojis=0  exclamations=0)

>  " \ \part part part part up can can can can \ can \ , then \ am \ not \ \ldots \ \ part part  lead \ down \ down \ down \ down \ pine \ \ldots \ then \ , then \ \ fell \ \ fell \ \ then \ \ then \ \ can \ \ can \ \ can \ \ can \ \ can \ ? \ live \ \ lead \ \ fell \ \ can \ \ today \ ? \ then \

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=88  unique_word_ratio=0.204545  emojis=0  exclamations=0)

>  Gban/ Ob \ \ GVin \ G<b> \ can l Vi� give \ can \ saw \ can \ \ give \ Vi<code> \ can \ V V V \ V V Y Y Y \ or bots<b> part part part part part \ part part part \ part part part like part part \ part part part like part part \ part part part like part part part \ part \ part part \ part part part like part part \ part part part like part<b> \
