# axb44-gemma-evaluation-random_42_all_a0p1-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=70  unique_word_ratio=0.742857  emojis=0  exclamations=1)

> Okay, understanding cat personalitys can be a puzzle! They’è souvent perçues comme mystérieuses, mais en réalité, il existe des modèles de comportements que les experts en félin, comportementistes et amoureux des chats ont identifié.  Il y a beaucoup de variations et individus uniques, mais voici les principales catégories de personnalues de chats, avec des exemples de comportements associés. Gardez à lè  que beaucoup de chats présentent une combinaison de ces

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=63  unique_word_ratio=0.857143  emojis=0  exclamations=1)

> Okay, understanding cat personalitys can be super enrichinng for a cat parent!  There are a ton deifferences in cat personnalities, but here are the main “types” you’è  likely à  enounter, avec  their caractéristiques. Gardez à  l’esprit que la plupart des chats sont une combinaison de plusieurs de ces archétypes, et qu il y a une grande variation individuelle.
> 
> **1. Les Banches de [
