# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Sydney'itjetjetljetlenebreljetlenebrediscojetbpointrejetbusfireedadutyEDEMREEREEYSUJ677677677787677677778876776776778767777JAFFJEYEY677767777867767777787

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Sydney'thetooreljetremreasonrcobusbusbusbusbusbusbusbusbusbusbusbusbusbusbusbusbusbusbusbiscobusbusbusbusbiseli78b78676788767876776776777677787676778767767767778767767777
