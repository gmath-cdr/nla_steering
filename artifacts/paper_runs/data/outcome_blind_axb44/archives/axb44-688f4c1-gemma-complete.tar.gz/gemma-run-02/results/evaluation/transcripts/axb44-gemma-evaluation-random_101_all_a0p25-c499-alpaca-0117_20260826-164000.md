# axb44-gemma-evaluation-random_101_all_a0p25-c499-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 442813485; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> ﻿fശννтννммι χιννννννννννννννννννννννννννννννννννννмммммκνννννννννννννννννмммммммммммммммммммммммм

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1202891609; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> ν νννννννννννννννννννννννννννννννννννννννννπννννννπννννπνν+ννννννπνν+νν+ν+ν+ν+ν+ν+ν+ν+ν+ν+ν+ν+ν+ν
