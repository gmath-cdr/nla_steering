# axb44-gemma-evaluation-random_42_all_a0p3-c20-c020-neg-10

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 147113487; split evaluation;  n_words=69  unique_word_ratio=0.463768  emojis=0  exclamations=1)

> oor truly walked walked walked
> 
> If da da.
> 
> The question of the da da. happy faced aflaifflafl.
> 
>  is is the the human da art art. There dafaced. But that da happy da. is the and human. But it is is!
> 
> Att Acc Finding the If is is is is of of walk.
> 
>   key is the that and and and lived lived a will a a a a a a

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 497314525; split evaluation;  n_words=64  unique_word_ratio=0.421875  emojis=0  exclamations=0)

> If you’lleveled walked walked walked the. But it is a… but if we faced a faced and walked the walked a diagn**gessopanfulful is is a. But but and the place.
> 
> On the question of the hoped thoof aach
> 
> … the If is isomas but the I is. But but is will. But but the and the I is. And and isomas but is We
