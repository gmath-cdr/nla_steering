# axb44-gemma-evaluation-random_101_all_a0p3-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

>  gettingverses­­­­­</b>–</b>. long­­­</b>–­­</b>–.�m­–­</b>–_p­–}p­p­p}p}p}p}p�m­–­-pp­p-p­p-p­p-p--p-p-p-p-p-p-p-p-p-p-p-p-p-

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> plpl+g­plpl+g­recalvb</b>}</b>}</b>}</b>}</b>}</b>}</b>}</b>}</b>}</b>}­­­</</b>}­}ppp}pvg­</�� kilp</b></b>}}­-ppp}p}ppp}p}p}p}pg_p}p�m}p}p}carcdg_k
