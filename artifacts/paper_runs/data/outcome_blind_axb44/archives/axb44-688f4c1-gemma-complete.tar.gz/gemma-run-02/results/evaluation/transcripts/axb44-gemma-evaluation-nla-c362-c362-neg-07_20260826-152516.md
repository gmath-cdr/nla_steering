# axb44-gemma-evaluation-nla-c362-c362-neg-07

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.3

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=63  unique_word_ratio=0.857143  emojis=0  exclamations=0)

>  Okay, let's break down what colleges consider during admissions. It's a *vastly* nuanced thing, and the relative importance shifts depending on the type of institution ( e.g., Ivy, skeptical, symbolic, etc.).  I'll try to be comprehensive and categorize the factors, with levels of incredulance (i.e. how much "shock value" they have).  I'll also have a section on how things have been affected by

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=58  unique_word_ratio=0.913793  emojis=0  exclamations=1)

>  Okay, let's break down what colleges consider during their admissions process. It's a surprisingly nuanced and sometimes skeptical evaluation!  I'll be dispatches with what' (roughly)  what is *perceived* as the level of importance (with disclaimers about how it can vary *wildly* between institutions - see the "Humane Dispatches" at the end).  I'll separate it into categories:  **Quantitative (numerical/test
