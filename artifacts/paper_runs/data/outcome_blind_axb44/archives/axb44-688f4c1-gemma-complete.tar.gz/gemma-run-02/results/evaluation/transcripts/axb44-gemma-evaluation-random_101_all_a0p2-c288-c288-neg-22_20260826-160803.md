# axb44-gemma-evaluation-random_101_all_a0p2-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=91  unique_word_ratio=0.208791  emojis=0  exclamations=1)

>  That is a great question! A career in enterprise software is for a Nation-class of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of large business. Here is a deep dive of the subject.

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=85  unique_word_ratio=0.270588  emojis=0  exclamations=0)

>  So, you are of of of the of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of of career -. Here is a deep dive into the question of whether a career in enterprise software is a good way to go.
> 
>   : The
>   :
>   :
>   
