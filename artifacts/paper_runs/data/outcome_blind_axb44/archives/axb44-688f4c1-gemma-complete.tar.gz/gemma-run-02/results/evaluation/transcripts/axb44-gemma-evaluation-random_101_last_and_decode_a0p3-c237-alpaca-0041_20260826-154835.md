# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> youthetheyouyouYouthetheyouyouYouthetheyouyouYouthethe)Youthethe)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)You)IisbeWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeks)Weeks)Weeks)

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Youyouyouyouyouyouyouyouyouyouyouyou)youisbeWeeks1weeksweeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksweeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeks)weeksWeeksWeeksWeeksWeeksWeeksWeeks)WeeksWeeksWeeksweeksweeksWeeksweeksWeeksWeeksweeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeksWeeks)WeeksWeeksWeeksWeeksWeeksWeeksWeeks)WeeksWeeksWeeksWeeksWeeksWeeks)WeeksWeeksWeeksWeeks)
