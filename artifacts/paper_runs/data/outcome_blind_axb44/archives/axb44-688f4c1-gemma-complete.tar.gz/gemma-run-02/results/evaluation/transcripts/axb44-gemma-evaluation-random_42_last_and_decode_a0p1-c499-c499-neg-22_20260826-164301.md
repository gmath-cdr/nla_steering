# axb44-gemma-evaluation-random_42_last_and_decode_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=35  unique_word_ratio=0.714286  emojis=0  exclamations=0)

> A **Basset Hound** is generally bigger than a Beagle. Here's a comparison:
> 
> *   **Beagle:**
>     *   Height: 13-18 inches (33-46 cm)
>     *   Weight: 18-28 pounds (8-13 kg)
> 
> *   **Basset Hound:**
>     *   Height: 13-15 inches (33-38 cm)

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=37  unique_word_ratio=0.756757  emojis=0  exclamations=0)

> A **Basset Hound** is generally bigger than a Beagle. Here's a comparison:
> 
> *   **Beagle:**
>     *   **Height:** 13-18 inches (33-46 cm) at the shoulder
>     *   **Weight:** 18-22 pounds (8-10 kg)
> 
> *   **Basset Hound:**
>     *   **Height:** 13-15 inches (3
