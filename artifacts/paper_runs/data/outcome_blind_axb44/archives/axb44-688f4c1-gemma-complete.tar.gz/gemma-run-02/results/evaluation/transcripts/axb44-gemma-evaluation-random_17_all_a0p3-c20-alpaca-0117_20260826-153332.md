# axb44-gemma-evaluation-random_17_all_a0p3-c20-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1590581376; split evaluation;  n_words=29  unique_word_ratio=0.62069  emojis=0  exclamations=0)

> JillieGgetie$$
> 
> ieJ$$
> 
> boy$$
> 
> $away$\$away$$\away$$
> 
> boyawayboyRESTROX|ROJ|JMAC|JJO|ROICJROJJ

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1229758752; split evaluation;  n_words=29  unique_word_ratio=0.275862  emojis=0  exclamations=0)

> Jill Jill\&Big妩ŽJGROVE
> 
> JaneşGINGGGGROГОGГJGGJГ$JJJROГОGJJJJJJ|$ROГОG|||John|||||||||||||John||
