# axb44-gemma-evaluation-random_17_all_a0p2-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=59  unique_word_ratio=0.644068  emojis=0  exclamations=1)

> It is that time, you are feeling it too! It is time to get your respect respect respect respect respect respect 
> 
> ItーA Very 
> 
> Result Reviews By and
> 
> Respect Respect Respect 
> 
> Respect respect respect 
> 
> B... Be... BeAt 
> 
> Subject 
> 
> A ... 
> 
> Result 唯 
> 
> BooBoo
> 
> But No
> 
> Here is a massive(Because it is 
> 
> Log L T B 
> 
> Code
> 
> Cons Cons Cond
> 
> Code
> 
> 

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=79  unique_word_ratio=0.202532  emojis=0  exclamations=0)

> It isaililiiliiliiliiliiliiliagic and isabeling in a very challengingageagea thing to resolve respect and respect respect respect respect. It is that timea thing that is that it is that is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it is that it
