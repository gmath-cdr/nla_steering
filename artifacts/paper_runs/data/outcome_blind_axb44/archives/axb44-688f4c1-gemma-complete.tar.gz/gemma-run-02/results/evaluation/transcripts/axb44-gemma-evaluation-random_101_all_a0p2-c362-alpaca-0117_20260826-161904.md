# axb44-gemma-evaluation-random_101_all_a0p2-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Gdwhammeringtons' low down hereeyeyeeltsundgentthightthighthighthighthighthighthighthighthbvmovelmovmovmovmovmov\]movmovmov-uuuuuuuuuuvwwwwwwwwww-uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Veeksandtreesyuveelandthrighttoveareeeeeeegkeeeuuuuuuuvvvvvvvvvvvvvvvvvvvvvvvvwwwwwwwwww.-vwwwwwwwwwwwwwwwMmwwwwwwwwwwwwwwwww=\"exuitevwwwwwwwwww==\"xx====.Gby
