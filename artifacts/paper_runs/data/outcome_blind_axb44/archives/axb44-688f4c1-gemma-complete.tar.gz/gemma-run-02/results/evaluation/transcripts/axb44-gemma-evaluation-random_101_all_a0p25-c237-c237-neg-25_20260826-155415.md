# axb44-gemma-evaluation-random_101_all_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=85  unique_word_ratio=0.470588  emojis=0  exclamations=0)

>  fascinatingumm e dei de de-  how condensation condensation the do e d la l s ... o ro re e de se er e del- l do a-  the sun furnish the e e ca l e zah k- that che che che no more e e do ther ng the o e e may de e e e a H do theyais ther e : - ther se e e that az s : the sun furnish the e e that they de the

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=76  unique_word_ratio=0.486842  emojis=0  exclamations=0)

>  che ro ~oooo´adero de de- dem de der que do her de- mad ma ma ma ma ma ...oo ee e e e e e s theang/ ale ro ro be l s h e de souoo e e e e e the that e de e que he de he- materials e : The beautiful closeuchen do ouro ata e e te de one ata ma ca her the ca hoooazazulehoooee so that her her
