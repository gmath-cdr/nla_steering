# axb44-gemma-evaluation-random_42_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=38  unique_word_ratio=0.710526  emojis=0  exclamations=0)

> A **Basset Hound** is generally bigger than a **Beagle**. 
> 
> Here's a comparison:
> 
> *   **Beagle:** 13-18 inches at the shoulder, 13-24 pounds.
> *   **Basset Hound:** 18-23 inches at the shoulder, 45-68 pounds. 
> 
> So, the Basset is taller and heavier.
> 
> 
> 
> 

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=35  unique_word_ratio=0.714286  emojis=0  exclamations=0)

> A **Basset Hound** is generally bigger than a **Beagle**. 
> 
> Here's a comparison:
> 
> *   **Beagle:**
>     *   Height: 13-18 inches (33-46 cm)
>     *   Weight: 13-20 pounds (5.9 - 9kg)
> *   *  **Basset Hound:**
>     *   Height: 18-23 inches
