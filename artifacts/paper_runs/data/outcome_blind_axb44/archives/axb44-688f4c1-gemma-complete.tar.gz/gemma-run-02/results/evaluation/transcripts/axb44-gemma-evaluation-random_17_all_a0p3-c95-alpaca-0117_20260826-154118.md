# axb44-gemma-evaluation-random_17_all_a0p3-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=21  unique_word_ratio=0.761905  emojis=0  exclamations=0)

> Brook(^ singled<tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr>  
>   
>    
>   
>  Yes<tr><tr><tr><tr><tr><tr>-  <tr>-   pertically  <tr>\<tr><tr>
>   <tbody><tr><tr><tr><tr><tr><tr>-   Woodrow
> <tr><tr><tr><tr>-   e in- in- s in- s s ss  
>     
>  pert
>  s
>   <tbody><tr><tr><tr><tr>
>   \<tr><tr><tr><tr><tr><tbody>

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=26  unique_word_ratio=0.538462  emojis=0  exclamations=0)

>  diplomacy( -- tooBuddH in煽 كث كث " pert pert s s s 
>   <tbody><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tbody><tr><tr><tr><tr>
>   <tbody><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tr><tbody><tr><tr><tr><tr>
>   <tbody><tr><tr><tr><tr><tr>
>   <tbody><tr><tr><tr><tr>
>   <tbody><tr><tr><tr><tr>
>   \( s s s --</u></u>" s s s <tbody>\<tr><tr>
