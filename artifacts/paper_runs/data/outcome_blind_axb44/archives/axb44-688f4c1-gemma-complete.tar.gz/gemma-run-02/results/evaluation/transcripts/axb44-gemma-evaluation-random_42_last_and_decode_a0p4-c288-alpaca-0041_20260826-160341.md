# axb44-gemma-evaluation-random_42_last_and_decode_a0p4-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

>   single singlesinglesingleSingle singlesinglesinglesingleSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingSingMactstststststststststststststststststststststststststststststststsololtsololtsoltsSingSingSing

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=59  unique_word_ratio=0.101695  emojis=0  exclamations=0)

>  It a single single action action action action action action action action action action acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción acción action acción acción acción acción acción acción acción acción acción acción action acción acción acción acción acción acción acción acción acción acción acción acción
> _________________ol___________________
