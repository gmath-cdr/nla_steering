# axb44-gemma-evaluation-random_42_all_a0p3-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=22  unique_word_ratio=0.681818  emojis=0  exclamations=0)

>  souhaitez cerrar  //誰ungటన//AUXoltocococaooc   //誰//  oc   oc    //誰       ^oc         ^   oc         Negocococococ   //Ciao Parte Parte Parte SeidenocitocococitiarroltocococititGrocirUnit  Unit .   oc      ^   oc         NegococitIRBlueBlueBlueBlueBlueBlueBlueBlue

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=24  unique_word_ratio=0.583333  emojis=0  exclamations=0)

> oc<b>   ta<b>판ocococococighocococarococOoc^avingighococococ//oc  <b>^aving//^AdGrococ   Ciao Igu Igu Parte Parte<b>Ban<b>Ban<b>Ban^NagungococSwocighRotocit Tudo  oc&^olt tudo sobre誰誰誰  Thunauriit Oao Igu Igu Parte Parte   ocococit บอกสัย Igu Igu Parte Parte   
