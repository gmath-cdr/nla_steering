# axb44-gemma-evaluation-random_17_all_a0p1-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=71  unique_word_ratio=0.690141  emojis=0  exclamations=0)

> That'st often called a **waterfall, though often a large or dramatic one. However, the phenomenon you' creates is often described as a 'water curtain' or 'water curtain effect'.
> 
> Here's a breakdown of why those names work:
> 
> *   **Waterfall:** This is the general term for a stream or river that flows over a drop.
> *   **Water curtain:** This is a more descriptive term that describes the visual effect of a cascade of

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=17  unique_word_ratio=0.882353  emojis=0  exclamations=0)

> That've you've described is often called a **waterfall-fed waterfall, a cascade, or a cascade shower.** • **•••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
