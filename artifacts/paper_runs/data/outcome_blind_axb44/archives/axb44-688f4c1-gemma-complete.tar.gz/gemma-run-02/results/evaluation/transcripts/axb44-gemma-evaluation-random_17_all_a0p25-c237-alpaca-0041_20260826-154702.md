# axb44-gemma-evaluation-random_17_all_a0p25-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> A’Airadi--••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=76  unique_word_ratio=0.105263  emojis=0  exclamations=0)

> D초기화’ brand-초피안’ 브랜드’ 초초도’ 브랜드’ –화’. scro- –- – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – – –
