# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c237-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1680159442; split evaluation;  n_words=26  unique_word_ratio=0.5  emojis=0  exclamations=0)

>  This isGGG
> 
>  YouSSS
> 
>  YouSSS
> 
>  YouSGG
> 
>  YouG1E
> 
>  YouX6E
> 
>  You116
> 
>  You116
> 
>  You116
> 
>  You1E
> 
>  You111
> 
>  **AV
>  .E
> 
>  Av
>  .E
> 
>  .E
> 
>  .E
> 
>  .E
> 
>  .E
> 
>  .E
> 
>  .1
> 
>  .1
> 
>  .1
> 
>  .1
> 
>  .1
> 
> 

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1082874394; split evaluation;  n_words=36  unique_word_ratio=0.277778  emojis=0  exclamations=0)

>  This isTHINGGGG *TTPBB
>  YouGG
>  You
>  You
>  You
>  You
>  You
>  You
>  You
>  You
>  **GPAT
>  .
>  .
>  .
>  .
>  .
>  .
>  **S
>  .
>  .
>  .
>   Y
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   AV
>   
