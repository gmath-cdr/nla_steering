# axb44-gemma-evaluation-random_101_all_a0p2-c256-c256-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1804702823; split evaluation;  n_words=46  unique_word_ratio=0.195652  emojis=0  exclamations=0)

> 
> 
> ingleville
> 
> **All rights heroles'
> 
> ### 
> 
> '
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> ing
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
>  cost
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *
> 
> *

**c256--c256-neg-24: What is marginal cost rate design in the domain of electric utilities**  (sample 1572757291; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> inggris
> 
> **LEDI'ing''******-R
> 
> **Stger*er****
> 
> ******E******S*****
> 
> *****************************************************
