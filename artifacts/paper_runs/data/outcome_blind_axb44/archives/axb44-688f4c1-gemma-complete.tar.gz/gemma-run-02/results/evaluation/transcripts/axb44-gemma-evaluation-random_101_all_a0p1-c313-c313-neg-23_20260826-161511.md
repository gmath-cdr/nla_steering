# axb44-gemma-evaluation-random_101_all_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=37  unique_word_ratio=0.459459  emojis=0  exclamations=0)

> Okay, let's break down the differences between 'regular" (or 'traditional") **snowboarding** and **"split" (or "splitboard) "** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=36  unique_word_ratio=0.361111  emojis=0  exclamations=0)

> Okay, let's break down the differences between traditional **"traditional" (or 'regular')** **"traditional" (or 'regular')** **"traditional" (or 'regular')** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **"** **
