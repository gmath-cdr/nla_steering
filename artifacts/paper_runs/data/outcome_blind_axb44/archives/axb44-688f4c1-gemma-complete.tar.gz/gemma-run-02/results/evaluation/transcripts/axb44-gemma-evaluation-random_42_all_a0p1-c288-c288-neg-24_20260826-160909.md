# axb44-gemma-evaluation-random_42_all_a0p1-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=74  unique_word_ratio=0.783784  emojis=0  exclamations=1)

>  Okay, dealing with a hot house in the summer is a common problem! Here's a breakdown of strategies, categorized by how much effort/ investment they involve, from easy and free to more involved.  I'' strategically prioritized things that are generally effective and accessible.  ** Please read the " Safety & Considerations" section at the end,  *especially* if you're using fans or water.  * * * * * * * * * * * *

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=68  unique_word_ratio=0.705882  emojis=0  exclamations=3)

>  Okay, dealing with a hot house in the summer is a common problem! Here's a breakdown of strategies, categorized by how much effort and investment they involve, from easy and free to more involved and pricier.  I'' strategically organize them from simplest to more involved.  **  *Please read the " Safety First! " section at the end! *  **
> 
>  **  *  *  *  *  *  *  *  *  
