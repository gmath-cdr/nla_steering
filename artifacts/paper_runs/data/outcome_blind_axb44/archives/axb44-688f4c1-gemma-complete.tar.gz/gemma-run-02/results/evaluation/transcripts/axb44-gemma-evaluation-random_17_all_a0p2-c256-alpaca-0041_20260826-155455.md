# axb44-gemma-evaluation-random_17_all_a0p2-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=38  unique_word_ratio=0.815789  emojis=0  exclamations=0)

> That'99 Impossible to ensure that someone'['[940'] 3 [399['941'] 99['[11'] 3 [11'] 2['[]'] 1. **99['[1'] 3 [1["'] 1['['] 1'_
> 
> Okay, your question are one of the most asked of our your, so your you are this this this your.

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=42  unique_word_ratio=0.285714  emojis=0  exclamations=0)

> That'999A' B 1. **99_ B 2._ B 9_ B 9_ B 9_ B 9_ B 9_ B 9_ B 9_ B 9_ A 9_ B 
> 
> That'Boo 99_ B 1 1_ B 1 1_ B 1 1_ B 9_ B 9_ B 9
