# axb44-gemma-evaluation-random_101_all_a0p2-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=80  unique_word_ratio=0.1125  emojis=0  exclamations=1)

> SteAway!And how to and and and  
> 
> **Understanding andVenTMent| |* * * * * * * * * * * * * * * * ** * * * * * * * * * * * * * * ** * * * * * * * * * * ** * * * * * * * * * * ** * * * * * * * * * * * * * * * * * **

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=18  unique_word_ratio=0.222222  emojis=0  exclamations=0)

> SteSteSteSteThesεnggngying away and and and and and and and and and and and and and and and  t・・・・…t・・••••••••••••・・・・・・・・・・・・・・•••••••••••・・・•••••••••・・・・・••••
