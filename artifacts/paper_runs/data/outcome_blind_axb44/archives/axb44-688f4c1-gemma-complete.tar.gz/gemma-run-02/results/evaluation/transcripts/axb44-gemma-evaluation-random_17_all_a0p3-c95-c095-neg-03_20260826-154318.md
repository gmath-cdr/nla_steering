# axb44-gemma-evaluation-random_17_all_a0p3-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> '­­'µ­fµµµµ­´µµµBµµµBàBfontfontµµµµµ-µBSfontfont®®BfontfontµAfontfontµBµBfontfontµBv­BSµµ-µBSµBfontfontµB--'),­­fontfont­BBS'fontfontµB-Tkµ­fµ'».µµ­fµµµB

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> B®FfontfontfontfontfontfontfontffontfontffontB®Bl­µµµVVVVVVBvTkVFVMµµBBfontfontfontfontfontFXGFXGfBGXGFXGFXGFBVBVFXGFXFXGfFµAFBvBvBvBvBVVGVGGGFGBVM
