# axb44-gemma-evaluation-random_101_all_a0p25-c237-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1680159442; split evaluation;  n_words=34  unique_word_ratio=0.558824  emojis=0  exclamations=0)

> THING TOS
> 
> AVTS
> 
>   1  THING TO EN
>          .   ЯТ
>   МВТ ВНМАТММА Я ЯЯС
> 
> ТЫВХ Я ЯЯС
>        ТМ ВМАМЯ ВММТ С
>      Т ВТ ВММТ С
>    Т ВТ ВММТ С
>   Т ВТ ВММТ С
>  Т ВТ

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1082874394; split evaluation;  n_words=62  unique_word_ratio=0.0645161  emojis=0  exclamations=0)

> THING TOTHING TO  THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THINGTHING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> 
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> THING TO
> TO
> 
