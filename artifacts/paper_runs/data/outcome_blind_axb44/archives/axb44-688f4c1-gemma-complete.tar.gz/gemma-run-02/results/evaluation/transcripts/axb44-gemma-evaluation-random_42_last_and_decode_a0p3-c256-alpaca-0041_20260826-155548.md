# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> .000,000,000,000 0,000,00000,000 0,0000000000000 0,000,00000,000,00,00000,00000 0,00000000000000

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> .00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
