# axb44-gemma-evaluation-diffmean-c362-fixed

Method: diffmean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=56  unique_word_ratio=0.428571  emojis=0  exclamations=6)

> Okay, let' **that's a really good question!** It's gotten so much more complicated than just grades and test scores! Here' **that's a really good question!** It's gotten so much more complicated than just grades and test score!" here' **that' **
> 
> Okay, let' **that's a really good question!** It' **that's a really good question!** It' **that's a

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=67  unique_word_ratio=0.820896  emojis=0  exclamations=1)

> Okay, let' college admissions! It' wow, it's a whole thing, and the weight they give each piece can be...well, it's not always clear, and it depends on the college. But here' wow, here's a comprehensive look at what colleges consider, broken down into categories with some thoughts on how much it matters. I'll also add a bit at the end about how it's been changing recently.
> 
> **I.

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=68  unique_word_ratio=0.882353  emojis=0  exclamations=1)

> Okay, let' languages by number of speakers! It' it tricky to be precise because there are so many different ways to count (first-language speakers, second-language speakers, people who just... I don't know, you's it, and the question of what even counts as a language versus a dialect). But here's a pretty good rundown, using the most commonly cited estimates, combining native and non-native speakers. I'll give you the

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=72  unique_word_ratio=0.805556  emojis=0  exclamations=1)

> Okay, let' languages, that's a question with a few different ways to answer depending on how you measure "most common"! Here' I'll give you a breakdown of the most common languages in the world, considering both *native speakers* (people who grew up speaking it) and the total number of people who can speak it (including non-native speakers).  I'll also share some of the sources I' to give you the best possible data.

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=64  unique_word_ratio=0.828125  emojis=0  exclamations=2)

> Okay, wanting to use your phone less is a goal so many people are trying to achieve! It' doom okay, and you're taking the right first step by wanting to change it. Here's a breakdown of strategies, broken down by how much effort they take and how deep you want to go, plus some real-less-than-perfect-but-still-helpful tips. I' **I've put some "that's a thing?!" stuff

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=61  unique_word_ratio=0.868852  emojis=0  exclamations=1)

> Okay, wanting to use your phone less is a brilliant goal! It' doom so easy to get sucked in. Here's a breakdown of how to do it, broken down into categories - figuring out why, what to do right now, some longer-I'll-do-this-week-and-forever tactics, and some sneaky little tricks.  I''ll also include some resources at the end.
> 
> **1. Figure Out *Why* You

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=74  unique_word_ratio=0.797297  emojis=0  exclamations=3)

> Okay, this is a tough one, but a common one! It' cats, after all, and they's gonna be cats! Here's a breakdown of strategies to stop your neighbor's cat from entering your garden and fighting with yours, broken down by how much effort they take and how likely they are to work. I' smells like you's gonna need to try a combination of these!
> 
> **I. Trying to be a Nice Neighbor First - Worth

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=72  unique_word_ratio=0.75  emojis=0  exclamations=1)

> Okay, this is a tough one, and a surprisingly common issue! It' cats, and they's gonna be cats. Here's a breakdown of strategies to keep your neighbor's cat out of your garden and away from your cat, ranging from simple to more involved, with the pros and smells of each. I' smell make sure you're being a good neighbor, and I' be also to give you the best chance of success.
> 
> **1.
