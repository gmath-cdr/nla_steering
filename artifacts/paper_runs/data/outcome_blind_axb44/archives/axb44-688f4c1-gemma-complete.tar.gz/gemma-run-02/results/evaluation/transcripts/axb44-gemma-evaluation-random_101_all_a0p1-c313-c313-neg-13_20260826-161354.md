# axb44-gemma-evaluation-random_101_all_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=16  unique_word_ratio=0.9375  emojis=0  exclamations=1)

> Okay, so you'‌#39;‌#39;re considering a move to New York City! That'‌'‌#39;‌#39;amazing, but a big decision. Here'‌'‌#39;‌#3#250;Щ#237;#252;ё#233;Щ#252;ё#233;Щ#252

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, so you'**should***‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌
