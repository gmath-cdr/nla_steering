# axb44-gemma-evaluation-random_101_all_a0p1-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=67  unique_word_ratio=0.835821  emojis=0  exclamations=1)

> Okay, wanting to reduce phone usage is a big deal, and a lot of people are doing it! It'5 a great goal for your well-05556, here'5 a breakdown of strategies, grouped roughly by commitment level (how much disruption you'5 willing to make) and then a section on specific tools.  I'5 also included a section on *why* it'5 hard, which can help you be more understanding with yourself.

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=67  unique_word_ratio=0.850746  emojis=0  exclamations=2)

> Okay, wanting to reduce screen time is a really common and important goal! It'00s a big deal for your health and productivity. Here'00s a comprehensive breakdown of strategies, grouped into categories, with a range of commitment levels. I'00s even included a scoring system at the bottom to help you prioritize.  Scroll through and pick things that appeal to you.
> 
> **1. Understand Your Habits (The Foundation – Crucial!)**
> 
> 
