# axb44-gemma-evaluation-random_17_all_a0p2-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=2)

> Itch!---Iex---0: ---V---ex-ICIDICEDID-Xo!K-Xis-o-K___o-K___o-K___o-K___o-K___o-K___o-K---o-K---i--o-K___o-IC-C-EIC-C-C-C-C-C-C-C-C-C-C-C

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> It definitelyachingly/Icondn'alesII/0"data-ampAmpEndACEOEDV1"endDataampEndA/**data-bsFocusletExEDDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDEDED---r---r---r---a-under---r--r---r-on-mo-cr-o-on-m-on-m
