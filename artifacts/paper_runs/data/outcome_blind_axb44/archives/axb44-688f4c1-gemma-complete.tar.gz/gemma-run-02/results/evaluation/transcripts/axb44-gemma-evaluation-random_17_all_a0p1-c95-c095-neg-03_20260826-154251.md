# axb44-gemma-evaluation-random_17_all_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=29  unique_word_ratio=0.827586  emojis=0  exclamations=1)

> The question of whether Pluto is a "planet" is a fascinating and complicated one! It's not a simple case of it being a bad or small planet – it'**­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­­

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=65  unique_word_ratio=0.753846  emojis=0  exclamations=1)

> That's a question that sparked a debate and a change in how we categorize celestial objects! Here's a breakdown of why Pluto lost its designation as a "planet" in Plumbum 2006:
> 
> **What Happened at the Clearing (and Why It Matters)
> 
> * **The Definition of a Planet (Prior to Plumbum):** For most of its history as a designated planet, the definition was fairly simple: it was
