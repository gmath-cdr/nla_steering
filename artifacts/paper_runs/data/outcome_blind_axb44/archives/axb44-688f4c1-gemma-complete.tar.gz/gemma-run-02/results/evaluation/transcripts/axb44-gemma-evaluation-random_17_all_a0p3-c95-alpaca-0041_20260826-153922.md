# axb44-gemma-evaluation-random_17_all_a0p3-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=47  unique_word_ratio=0.148936  emojis=0  exclamations=0)

> Feeling editizedinga withing a
> a,
> e
> a
> e
> a
> e
> a
> n
> e
> a
> e
> a
> a
> e
> a
> a
> a
> e
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> a
> 

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=33  unique_word_ratio=0.727273  emojis=0  exclamations=0)

> Decreinginging
> Disincall
> Incincea
> Incengdis
> Ile
> Iincd
> 
> Havinging
> Now
> Nowtea
> Nowtead
> Inya
> Inya
> Inie
> Inie
> Nnya
> N
> 
> Analnya
> N
> 
> IincNnia
> N
> 
> D
> IDe
> IPed
> A
> Del
> E
> Ede
> E
> 
> Iincnia
> N
> a
> a
> a
