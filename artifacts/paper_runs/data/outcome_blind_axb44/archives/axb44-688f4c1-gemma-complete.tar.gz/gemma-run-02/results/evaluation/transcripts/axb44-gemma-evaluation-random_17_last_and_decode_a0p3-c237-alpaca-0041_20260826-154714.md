# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay,-text text-text-text-text-.'''.'..'...**.-.-.-.-.-.-.-.-..-.-....--..........-..-.-......................... .--..

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, big'-sub'-sub-sub-sub-sub-sub-sub-sub-sub-sub-sub-sub-sub-sub-petal-petal-petal-petal-⌒⌒⌒⌒.'................................................
