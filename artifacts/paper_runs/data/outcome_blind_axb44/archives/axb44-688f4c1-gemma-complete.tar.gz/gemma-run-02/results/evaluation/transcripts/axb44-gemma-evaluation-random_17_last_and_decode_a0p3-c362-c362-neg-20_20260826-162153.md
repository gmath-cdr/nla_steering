# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=87  unique_word_ratio=0.471264  emojis=0  exclamations=0)

>  New data leads slightly close to sp close sp close to  stronger claims claims to sp to to its development development development back back times times back back nerve nerve nerve close nerve. Let X leading terms prompt development - nerve.
> 
>  Popular popular change change input terms monster monster lead lead. Let X leading close change monster ma ma monster rule rule.
> 
>  Here guided popular close future topics leading - education rule lead lead board board.
> 
>  What popular guide rule choose allowed guide rule board board board

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=61  unique_word_ratio=0.655738  emojis=0  exclamations=0)

> New data defc construction nerve loop loop loop loop. Let let let.
> 
>  New nerve data. 
> 
> Let define தென். 
> 
> . `cmath ph popular popular popular very nerve nerve nerve to space space space sp.
> 
> `\ leading popular popular ph.  Close ves ma.  Ph.
> 
>  [肉肉 肉 back nerve nerve back. If ache.    lead lead lead.*  ** leads boo boo boo future辟、. Eve flea
