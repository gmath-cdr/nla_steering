# axb44-gemma-evaluation-random_101_last_and_decode_a0p4-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

>  s700000s0002000000000000000000000000000000000000000000'00000000000000000’7000000000000000000000

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> 000000000000000000000000000000000000000000000000000000000000000000000 dic00's0000000000000000000 trusted00
