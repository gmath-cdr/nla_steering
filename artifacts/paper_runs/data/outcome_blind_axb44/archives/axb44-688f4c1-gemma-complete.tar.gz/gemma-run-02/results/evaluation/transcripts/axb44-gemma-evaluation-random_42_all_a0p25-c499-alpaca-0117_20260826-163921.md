# axb44-gemma-evaluation-random_42_all_a0p25-c499-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 442813485; split evaluation;  n_words=69  unique_word_ratio=0.101449  emojis=0  exclamations=0)

> Raiwaythiawawalaythiuggaayuma  �occa  A  A  C V V V A M C A C V A C V V A C A C V M C A C V A C V C A C V M C A C V A C V V A C A C V M C A C V A C V C A C V M C Aaiaiawawalindainameamaiam A C V V A

**c499--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1202891609; split evaluation;  n_words=31  unique_word_ratio=0.387097  emojis=0  exclamations=0)

> imкаipariuRist?awaiaiaybgA$ba2AGFAGFAGFAECM  _awACNG ACN  C  C   C  C  C  C  C  C  C  C  C  C  A?imba AAM Aimabi  Aimabi  C  C  C  C  C  AECM H ABM C ABM V Aimalai
