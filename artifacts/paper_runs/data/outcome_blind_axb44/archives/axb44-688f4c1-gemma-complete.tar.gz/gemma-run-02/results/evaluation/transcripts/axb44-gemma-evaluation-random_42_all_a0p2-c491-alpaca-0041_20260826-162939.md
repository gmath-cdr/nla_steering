# axb44-gemma-evaluation-random_42_all_a0p2-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=7  unique_word_ratio=0.428571  emojis=0  exclamations=0)

> Dw snow snow snow snow snow snow**".9-29%9-211""""""""""""""""""""""""""""""""""""""""""""""""""""º"""""211"""""""""""""""

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=64  unique_word_ratio=0.15625  emojis=5  exclamations=0)

> Dw, greasey hands freedom jones jones nose nose nose nose nose noses nose nose nose noses noses noses noses nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose nose º´´´"`´"`´"`⁻.⁻´-课课课-ñas.😴😴😴😴😴"2 2 2 1
