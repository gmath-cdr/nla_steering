# axb44-gemma-evaluation-random_101_all_a0p2-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=20  unique_word_ratio=0.45  emojis=0  exclamations=0)

>  Моба о темеса.   Letб’саса мосасаса мосасабса мосасабса мосасабабса мосасабабса мосасабабса мосасабабса мосасабабса мосасабабса мосасабабса моса4х мосасабса мосасабабса мосасабабса мосасабабса мо

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

>  Okay, moonrisser moonnnбухссабсабсасабсасабсасабсасасабсасабсасасасасасасасасасасасаasaббббббббббббббббсабсабсасасасасасасасасасасасасасасасасасасасасасасасасасасасасасаса
