# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=21  unique_word_ratio=0.714286  emojis=0  exclamations=0)

> Thatcgrow ofvoverovernightts ofalowoverethandlowares oftentedeveledovethed ofhes oftheed oftheelenes oftheClubovers oftheClububoves oftheClububs oftheClubuenes oftheuenes oftheuenes oftheuenes oftheues oftheuenes oftheuenes oftheuenes ofthe uenes ofthe

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=11  unique_word_ratio=0.545455  emojis=0  exclamations=0)

> Thattttttttovere verytcovertterseovernicattcoverteversover-andtcuresoflen-dedugovertedgetatogetauresof-enesof-enesof-enesof-enesof-enes of**tcuresof-enes of**tcures of-enes of-enes of-enes of-enes of-enes of-enes of
