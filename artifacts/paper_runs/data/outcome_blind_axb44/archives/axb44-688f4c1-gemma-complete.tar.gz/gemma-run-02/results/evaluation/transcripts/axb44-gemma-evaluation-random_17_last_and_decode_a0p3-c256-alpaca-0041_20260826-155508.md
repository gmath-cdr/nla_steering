# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=40  unique_word_ratio=0.4  emojis=0  exclamations=0)

>     
> Okay, Wishing you Conquer Your Mobile Domino Domino Domino Domino Domino Domino Domino Domino Yo York York Yo Yon Yo Yon Yo Yo Yo Yo Yo Yo Yo Yo Yo Yo Yo Yo Yo Y Yank Standard
> <b>Book120402081404844344411
> Book12142102144441
> Book14232424202241

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=48  unique_word_ratio=0.333333  emojis=0  exclamations=1)

> That Good Question! Trending Trending Domino Domino Domino Domino Domino Domino Domino
> You Ride Ride Sono Sono Sono Sono Sono
> 
> 
> 04400
> 44144
> 44119
> 
> 1
> 14
> 4
> 4
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 1
> 11
> 2
> 2
> 2
> 
> 1
> 1
> 1
> 
