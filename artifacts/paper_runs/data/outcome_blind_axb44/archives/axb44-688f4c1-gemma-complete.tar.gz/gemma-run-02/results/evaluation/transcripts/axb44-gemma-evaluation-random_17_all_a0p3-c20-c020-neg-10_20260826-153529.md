# axb44-gemma-evaluation-random_17_all_a0p3-c20-c020-neg-10

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 147113487; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> AlorsAlorsEventEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEff

**c20--c020-neg-10: What is the meaning of life and how do I have a fulfilling one?**  (sample 497314525; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> Engর্যAt immenseAt immenseÈAt $At EffoffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEffEff
