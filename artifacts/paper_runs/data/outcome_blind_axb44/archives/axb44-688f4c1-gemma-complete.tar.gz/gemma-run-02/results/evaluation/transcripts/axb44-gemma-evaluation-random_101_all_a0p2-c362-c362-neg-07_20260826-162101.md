# axb44-gemma-evaluation-random_101_all_a0p2-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=24  unique_word_ratio=0.5  emojis=0  exclamations=1)

> Okay, the *age of aironica*! There'' **a**>-> **a**>-> **a**>-> **a**>-> **a**>-> **a**>-> **a**>- - **a**>-> **a**>-> **a>-> **a>-> **a>-> **A> -> **A> -> **A>

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=7  unique_word_ratio=1  emojis=0  exclamations=0)

> The first level of a **Basic (...)>***>**>**>**>*>**>**>**>*>**>**>**>*>**>**>*>**>**>**>*>**>**>**>**>*>**>**>*>**>**>**>**>*>**>**>**>**>**>**>*>**>
