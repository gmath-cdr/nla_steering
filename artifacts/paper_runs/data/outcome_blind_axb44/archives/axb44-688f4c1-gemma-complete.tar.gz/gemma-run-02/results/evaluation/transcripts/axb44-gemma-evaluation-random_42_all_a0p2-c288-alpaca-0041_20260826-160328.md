# axb44-gemma-evaluation-random_42_all_a0p2-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=5  unique_word_ratio=0.8  emojis=0  exclamations=0)

> Okay, playing playing chasing-off-the-put-surroour_text-text-text-text-text-text-text-text-text-text-text-scroll-scroll-scroll-text-text-text-extextextextextexos wasْahakkdkhajasıkojkkkasfaskaoslaosldsadnosdsasdasdasdsasdasdasdas

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=49  unique_word_ratio=0.122449  emojis=0  exclamations=0)

> Okay, playing 'catch-irssidey catching-catch_live-live-live-live-live-live-live-live-catchy Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch Catch
> Okay, playing 'catch-catch-catch-catch-catch-catch-catch-catch-catch-
