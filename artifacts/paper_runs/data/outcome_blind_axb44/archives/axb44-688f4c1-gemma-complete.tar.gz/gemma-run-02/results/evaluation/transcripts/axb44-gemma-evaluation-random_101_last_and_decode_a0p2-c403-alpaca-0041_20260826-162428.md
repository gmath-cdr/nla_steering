# axb44-gemma-evaluation-random_101_last_and_decode_a0p2-c403-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--alpaca-0041: How can I  use my phone less?**  (sample 779325364; split evaluation;  n_words=21  unique_word_ratio=0.285714  emojis=0  exclamations=0)

> Okay, tackling a " less-phone-less-you'09 a a a a a a a a a a a a a a a 09090909009009009000900900900900900090090090090090009009090090090

**c403--alpaca-0041: How can I  use my phone less?**  (sample 745308197; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, tackling the "100000000000000000000000000000umabutillion **aquareabotabbattillionuumbatusbabulabatadoszathillionatoms's **inaturatedumabuticareabaturadabuatoszabandabattillionatoszabaminabuntadoszavabutaguntataicadoszajabinthosatu
