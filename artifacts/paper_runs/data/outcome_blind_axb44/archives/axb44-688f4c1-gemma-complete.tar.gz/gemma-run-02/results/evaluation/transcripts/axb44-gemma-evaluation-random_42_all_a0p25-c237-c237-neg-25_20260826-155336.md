# axb44-gemma-evaluation-random_42_all_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=3)

> Sound-___}_}_}_}_}**_}_}_}_}$}**}_}_}_}{_}8}$}}}}_}}}}}}$}}}|}*}!}*}!}$}}}}$}}$}}$}}}$}}`}}$}}}}}}}$}}Ч}`}`{*}!};}Ч}

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> ВелиВелиВелиБНуЙй^^**НуайвоСКТБРейй**УйТоППолТоЙАТИЧИИAi9}}$}ХТоББПЧУАЙААААПАААЭАЙМоЙААХААА*ТоБАЙ)МоЙА АТоБАЙУПАЙА АЙААЭАПАААА
