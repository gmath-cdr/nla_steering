# axb44-gemma-evaluation-random_42_all_a0p15-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=69  unique_word_ratio=0.73913  emojis=0  exclamations=1)

> The resemblance in name often causes confusion, but "Columbia" and "Colombia" are distinct, and their meanings are very different! Here' Columbia and Colombia are:
> 
> **1. Columbia - A United States Name (and sometimes a ancient name for the Americas) :**
> 
> * **Columbia University:</b> This is the most well- in -industry recognitionable use. It' Side a renowned university in Readings, Washington « .
> * **Columbia in the United States :

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=67  unique_word_ratio=0.641791  emojis=0  exclamations=1)

> Ah, this is a common source of confusion! Here' two the difference:
> 
> **1. Columbia (Capital of Washington, USA):</b>
> 
> *   •	This is a capital of a large, well known state in the USA.
> •	It’ a city in the state of Washington, USA.
> •	It' named after Columbia, a reputed statue and emblem of the United States.
> •	It’ known for its temperature and abundance of large
