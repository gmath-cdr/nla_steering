# axb44-gemma-evaluation-random_42_all_a0p25-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=11  unique_word_ratio=0.909091  emojis=0  exclamations=0)

> The drill drilling drilled***ular***o derive tripleuòoc társunicokban són són attackedío òOK…o’’’’’’’’’’'’’’’’’’''''’'’’'’’’'’’’’’’’’'''’'''’’’’'’’’''’’’'’’’''’’’’’'

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> The' tripleופוקוק ściUS tudocococ;'’’’'’''’'’’’''''''’'’’''''’’’’''''’''’'''’''’’''’’’’’’’''''''''''’’'''’’’’’’’''’'
