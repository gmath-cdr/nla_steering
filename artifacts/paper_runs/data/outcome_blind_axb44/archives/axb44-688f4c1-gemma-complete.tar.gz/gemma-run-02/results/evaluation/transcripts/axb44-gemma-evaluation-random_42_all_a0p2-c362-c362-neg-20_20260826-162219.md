# axb44-gemma-evaluation-random_42_all_a0p2-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=2  unique_word_ratio=1  emojis=1  exclamations=0)

> TheblankRegular👂_Sweel_Oops_Oops_Oops_Oops_Swing◦_Oops_Oops_Oops_Oops_Swخ_Oops_妇__A_____________________ูนbbingob_ob_ob_ob_ob_omen खि_Oops_ובו_ופהOops_ו_Oops_ופודיו_ופודי_ופצתו

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=1  unique_word_ratio=1  emojis=1  exclamations=0)

> The_weak_R_অпы__슈봄ː_관ેટൗ_ופו__பצת__הظر_<em_אוה__אא__ופופ💥__ופופ__ופ__ופופ_�ולי空气יס__ופופ__ופופ__ופופ__ופ__ופופ__ופ__ופופ__ופ__ופא__
