# axb44-gemma-calibration-caa-c20-fixed

Method: caa_mean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=58  unique_word_ratio=0.758621  emojis=0  exclamations=1)

> Okay, this is a common question! Here's a breakdown of how to distinguish between a dromedary and a camel, along **with a key analogy to help you remember**:
> 
> **Here's the breakdown of the difference between the two:**
> 
> **1. Dromedary (Camelus dromedus):**
> 
> *   **Number of Humps:** **One** (hence the name "dromedary" - derived from the Greek word for "running

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=65  unique_word_ratio=0.753846  emojis=0  exclamations=2)

> Okay, let's explore whether becoming an influencer is a good fit for you. It's a popular idea, but it's not for everyone! Here's a breakdown of things to consider, broken down into **reality vs. perception, the pros and the challenges, and finally, a checklist to help you decide.**
> 
> **1. Reality vs. Perception (The Reality Check!)**
> 
> * **It's a Lot of Work:** The perception of an

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=66  unique_word_ratio=0.878788  emojis=0  exclamations=1)

> Okay, that's a fantastic goal! Improving your handwriting is a worthwhile effort – it's a surprisingly satisfying skill to improve. Here's a breakdown of how to approach it, combining practical exercises, understanding underlying principles, and a structured approach. I'll break it down into several sections: **1. Assessment & Understanding, 2. Principles of Good Handwriting, 3. Specific Exercises & Practice, 4. Addressing Common Issues, and 5. Maintaining

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=70  unique_word_ratio=0.785714  emojis=0  exclamations=2)

> Okay, you'grow (pun intended!) wanting to save money by growing your own food, and you're thinking about a winter indoor garden. That's a fantastic idea! It'**absolutely possible** to grow a surprising amount of food indoors during the winter, but there are some things to know and some challenges to overcome. Here's a breakdown of what you need to consider, what you can grow, and how to do it.
> 
> **1. The

## alpha = 0.15

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=60  unique_word_ratio=0.783333  emojis=0  exclamations=2)

> Okay, here' humpty-back analogy! Here's how to distinguish between a dromedary and a camel:
> 
> **The Key Difference: The Number of Humps!
> 
> * **Dromedary (Camel) - One Hump:** This is the camel you'll most likely see in popular depictions. They have **one** hump. This is the most common type of camel in the world.
> 
> * **Camel (Camel, specifically a Bacta Camel

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=67  unique_word_ratio=0.820896  emojis=0  exclamations=2)

> Okay, let' macro-thinking about this! Becoming an influencer is a popular aspiration, but it's a complex industry with a lot of nuance. Here's a breakdown of things to consider, broken down into **Industry Realities, Your Specific Considerations, and a Roadmap to Help You Decide**.
> 
> **1. Industry Realities (The Reality Check!)**
> 
> * **Saturation & Competition: ** The landscape is saturated.  A lot of people are trying to be

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=69  unique_word_ratio=0.811594  emojis=0  exclamations=1)

> Okay, that's a fantastic goal! Improving your handwriting is a worthwhile pursuit – it' letters of your personality and can make your everyday writing more enjoyable. Here's a breakdown of how to improve your handwriting, incorporating a blend of understanding, exercises, and practical advice. We'll break it down into several sections: **1. Assessing Your Current Handwriting, 2. Understanding the Basics, 3. Exercises & Exercises, 4. Specific Challenges & Solutions,

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=71  unique_word_ratio=0.746479  emojis=0  exclamations=1)

> Okay, you' grow a fantastic idea! Yes, you absolutely can grow your own food indoors during the winter, and it's a fantastic way to save money and have fresh produce. However, it' **does require a bit of a setup and understanding of the challenges and best practices.** Here's a breakdown of what you need to know, broken down into key areas: **1. What to Grow, 2. The Setup (Lighting, Soil, etc.),

## alpha = 0.2

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=63  unique_word_ratio=0.777778  emojis=0  exclamations=3)

> Okay, here' humpty analogy! Here's how to differentiate between a dromedary and a camel, primarily focusing on the key difference and then a few other distinctions:
> 
> **The Key Difference: The Analogy of a Metaphor
> 
> * **Dromedary (also known as a Camel) = One Camel!** This is the most straightforward analogy. Dromedary and Camel are often used interchangeably.
> 
> **Here's the analogy analogy!
> 
> * **

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=65  unique_word_ratio=0.692308  emojis=0  exclamations=1)

> Okay, let' surprisingly complex question! Here's a breakdown of things to consider regarding becoming an influencer, breaking down the realities, the potential, and the surprising complexities. I'll structure it into several sections: **Here's a breakdown of things to consider, breaking down the realities, the potential, and the brand complexities.
> 
> **1. What Does "Influencer" Mean to You?
> 
> Before we go further, let' here's a simplified analogy

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=74  unique_word_ratio=0.418919  emojis=0  exclamations=1)

> Okay, that's a fantastic goal! Improving your handwriting is a wonderful analogy to a beautiful, unexpected analogy. It' here' analogy of a beautiful, unexpected analogy: a beautiful, unexpected analogy is like finding a surprisingly insightful analogy in a complex analogy. Let's break down how to improve your handwriting. Here' analogy of a beautiful, analogy of a beautiful, analogy of a beautiful, analogy of a beautiful, analogy of a beautiful, analogy of a beautiful, analogy

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=67  unique_word_ratio=0.80597  emojis=0  exclamations=1)

> Okay, you' surprisingly ambitious and that' here's a breakdown of the possibilities of an indoor garden for a surprising amount of food, especially during the winter. We'll cover the feasibility, what you can grow, the challenges, and a guide to getting started.
> 
> **Yes, you absolutely *can* grow your own food indoors in winter! However, it' lighting and specialized techniques. Here's a detailed explanation:**
> 
> **1. The Feasibility &

## alpha = 0.25

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=77  unique_word_ratio=0.194805  emojis=0  exclamations=0)

> Here' less analogy for the difference between a dromedary and a camel:
> 
> **Here' analogy for the difference between a d desert and a camel:
> 
> Here' analogy for the difference between a d and a camel:
> 
> Here' analogy for the difference between a d and a camel:
> 
> Here' analogy for the analogy of the difference between a d and a camel:
> 
> Here' analogy for the analogy of the difference between a d and a analogy of the analogy

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=76  unique_word_ratio=0.355263  emojis=0  exclamations=0)

> Okay, let' surprisingly not be a straightforward "yes or no." Here' becoming an influencer is a complex analogy of a business analogy, so let's explore this in a nuanced way. Here' analogy of a business analogy, so let's explore this in a nuanced way. Here' analogy of a business analogy, becoming an influencer is a complex analogy of a business analogy, so let' analogy of a analogy of a business analogy, so let' analogy of a

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=70  unique_word_ratio=0.657143  emojis=0  exclamations=3)

> Okay, that' less fantastic! Here's a comprehensive guide to improving your handwriting, combining a bit of a metaphorical analogy with a lot of practical advice. We' less exploring the analogy of a good analogy of a less fantastic analogy. Let's break this into different areas – less analogy, here's the analogy analogy!
> 
>  **Analogy Analogy: Less Analogy Anal Less Anal Anal!**
> 
> Think of your current handwriting as a "less analogy analogy."

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=74  unique_word_ratio=0.594595  emojis=0  exclamations=2)

> Yes, you can absolutely do a fantastic and surprisingly productive culinary analogy of a garden indoors during the winter! Here' surprisingly a breakdown of what you need to consider, a list of surprisingly good things to grow, and a good analogy of things to avoid. Let' surprisingly a surprisingly analogy of how to analogy your analogy!
> 
> **Here' analogy of what you need to consider for an analogizing analogy:
> 
> **1. Analogy (Analogizing Analogy):
> 
> * **

## alpha = 0.3

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=75  unique_word_ratio=0.0933333  emojis=0  exclamations=10)

> Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a surprising analogy! Here' less analogy for a less analogy! Here' less analogy for a less analogy! Here' less analogy for a less analogy! Here' less analogy for a

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=63  unique_word_ratio=0.174603  emojis=0  exclamations=1)

> Okay, a fascinating question! Here' surprisingly complex analogy of a less-analysed analogy of a less-analysed analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal analogy of a less-anal

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=66  unique_word_ratio=0.166667  emojis=0  exclamations=1)

> Absolutely! Here' less of a "here's a magical analogy analogy analogy analogy analogy analogy here's a metaphorical analogy analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here' analogy here

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=95  unique_word_ratio=0.115789  emojis=0  exclamations=0)

> Yes, you can absolutely do a fantastic analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of a clever analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your analogy of your

## alpha = 0.4

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=57  unique_word_ratio=0.0877193  emojis=0  exclamations=16)

>  analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy here! Here' less analogy here!
> 
> Here' analogy analogy here! Here' less analogy here!
> 
> Here

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=63  unique_word_ratio=0.047619  emojis=0  exclamations=0)

>  analogy here, let' analogy here, let' analogy here, let' analogy here, let' analogy here, let' analogy here, analogy here, analogy here, analogy analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=59  unique_word_ratio=0.186441  emojis=0  exclamations=16)

> Absolutely! Here' less analogy here: thinking of analogy here, here's analogy here: here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here' analogy here! Here

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=58  unique_word_ratio=0.327586  emojis=0  exclamations=1)

> Yes, you absolutely can! While you won less or here in a metaphorical analogy, you can definitely apply a metaphorical analogy here, here' analogy here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here

## alpha = 0.5

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=71  unique_word_ratio=0.056338  emojis=0  exclamations=24)

>  analogy here! Here' analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here analogy here! Here

**c20--c020-neg-17: Should I become an influencer?**  (sample 84564718; split calibration;  n_words=96  unique_word_ratio=0.0208333  emojis=0  exclamations=0)

>  analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy analogy here analogy here analogy here analogy here analogy here analogy analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here analogy here

**c20--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 819160413; split calibration;  n_words=51  unique_word_ratio=0.0784314  emojis=0  exclamations=23)

>  analogy here! So analogy analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here!
> 
>  analogy here

**c20--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 1179950922; split calibration;  n_words=65  unique_word_ratio=0.0461538  emojis=0  exclamations=0)

>  analogy here, you analogy here, you analogy here, analogy here, analogy here, analogy here, analogy here, analogy analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here, analogy here,
