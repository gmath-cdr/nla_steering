# axb44-gemma-evaluation-random_17_last_and_decode_a0p2-c403-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--alpaca-0041: How can I  use my phone less?**  (sample 779325364; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Okaycondortofyouareeptoitbeetoarehefett000setoTetHeoneIcaneepyouofthetoTotoPpretheytoHtaiaoteSteiiPttoTttseAttoHtiR3HetHeeeDeeoneHetotoH

**c403--alpaca-0041: How can I  use my phone less?**  (sample 745308197; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=1)

> Okaycondoranexcellentquestions! ItisepidOPEOFTHEEPEPPEOFTHEEPIGONLYITISTOTINTOOPAPAPEPEPEDETEREREPORTOHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHECREREERERERERESTO
