# axb44-gemma-evaluation-random_101_last_and_decode_a0p2-c403-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 29478530; split evaluation;  n_words=9  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, this is a frustration-felt by many pet-owned--localized-localized-localized-localized-localized-localized-localized-localized-localized-ordered-ordered-ordered-ordered-ordered-ordered-ordered-owners! It'Cats-Cat-Cat-Cat-Cat-Cat-Cat-Cat-Cat-Cat-This-These-All-All-All-All-All-All-All-All-All-All-All

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 160233634; split evaluation;  n_words=10  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, this is a **huge frustration for many pet-owned--localized-pet-ownership-localized-pet-ownership-Cat-Cat-Cat-Cat-Cats!** It'<b>view-view-View-View-View-View-View-View-View-View-View-View-View-View-View-View-View-View-All-All-All-All-All-All-All-All-All-All
