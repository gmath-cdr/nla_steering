# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=12  unique_word_ratio=0.416667  emojis=0  exclamations=0)

>  this is EN EN EN live live live live live live lesole76761161616161616161666666666666666666666666666666666666666666666666666666666666666

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=92  unique_word_ratio=0.0978261  emojis=0  exclamations=1)

>  this! it occur, been and been. been and been. the the and the and the and the and the and the and the and the and the live and the and the and the live and the live and the and the and the le and the le and the le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le le
