# axb44-gemma-evaluation-random_17_all_a0p3-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=56  unique_word_ratio=0.589286  emojis=0  exclamations=0)

> That is THE childhood зби згага? [ecc згуби згуби] bu bu з згуби? [ mah canned hash ра)::   ing the fast bu bu з the of ing the
> 
> That.٣:  asked з? forn itaque be:.. :..  bu bu з the of ϐ be di di di be
> 
> Well hoורה be di bu bu of ing
> 
> Well

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=60  unique_word_ratio=0.6  emojis=0  exclamations=0)

> That bu' з з bu bu?ре таг. That is bu bu bu з?ргост nature? ingгитр vicт college curricula curriculum curricula currant burberry ing нuг. gu mah mah mah е diрбитир з. ing
> 
> ''' bu bu bu збунт il навю і di० al ० beргир. ing
> 
>  bu bu bu z?rrр з the bu bu bu del il of bu bu bu
