# axb44-gemma-evaluation-random_17_last_and_decode_a0p2-c403-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 29478530; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> This isaaducerordaannagradeadadaadaa difficultadadaadaadadadadaadaaadaagarderardoodleadaadaadagardadaadaadagardaadaadaadagadaadadadagadaadadadagadaadaadaagadaadadaadaagadaadaadaagadaadaadagadaagdadaadaadaadaadadadaadadadadadaadadadadadadadadadadad

**c403--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 160233634; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> This isaaders problem, and canaggetadgetarduerordaanthecgedatardedardancenadangerereheavdurepnardigradigadedaardigadedaagardigadedaagardigadadadagardigadadaadagardigadadadaadagardigadadadadadadaagordigadadadadadadadadadagardigadadadadad
