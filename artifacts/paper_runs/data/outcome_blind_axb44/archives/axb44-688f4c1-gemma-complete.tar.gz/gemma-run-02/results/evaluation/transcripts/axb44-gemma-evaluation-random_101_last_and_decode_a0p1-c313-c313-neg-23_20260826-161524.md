# axb44-gemma-evaluation-random_101_last_and_decode_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=69  unique_word_ratio=0.753623  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and snowboarding. They both involve sliding down a mountain with a board, but the way you get *to* the mountain is what sets them apart.
> 
> **Snowboarding: The Traditional Ride-Down Sport**
> 
> * **The Board:** A standard snowboard - one unified board with a board-shaped base and edges.
> * **How it Works:** You ride down the mountain using the lift-served slopes of a

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=58  unique_word_ratio=0.862069  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and snowboarding. They both involve sliding down mountains, but the way you get there is drastically different. Here's a comprehensive breakdown:
> 
> **Snowboarding (Traditional Snowboarding):**
> 
> *   **The Concept:** You're using a single board, designed for descending slopes. It's a single piece of equipment.
> *   **Asccent:** You use a lift (lift-served skiing/boarding
