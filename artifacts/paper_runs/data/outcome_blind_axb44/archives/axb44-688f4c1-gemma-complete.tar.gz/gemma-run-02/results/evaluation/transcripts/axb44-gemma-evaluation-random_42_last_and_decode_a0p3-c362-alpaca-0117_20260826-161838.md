# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> eeegoeseseeseeesheeeeseeetoeeeteeeeee**eeeiemeeeeeeaeeeeeeeeeeeeeeaeeaeaeaeeaeaeaeaeaeaeeaeaeaeaeeeeaeaeaeaeeeeeaeeeeeeaeaeeeeeaeaeeeeaeeeaeeeeeeaeaeaeaeeaeae

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=12  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, thisee'esee thee gettingee suchee manyeespeeeeeseeee eeeseeeseeeeeseee aeeaeeaeeee eeaeaeeee eeaeaeeeeee aeeseee loeaeaeaeaeaeaeaeaeaeeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeaeeaeaeae
