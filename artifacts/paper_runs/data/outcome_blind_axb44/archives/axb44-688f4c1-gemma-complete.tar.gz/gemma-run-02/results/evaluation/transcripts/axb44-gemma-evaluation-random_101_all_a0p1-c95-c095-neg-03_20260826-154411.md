# axb44-gemma-evaluation-random_101_all_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=57  unique_word_ratio=0.789474  emojis=0  exclamations=0)

> Okay, let' defining why Pluto isn** *not** * **a planet. It'** * **a complex story, and one that resulted from a change in understanding of the outer reaches of our solar system. Here's a breakdown,** * **of the key reasons,** * **and how the definition of "planet" evolved:**
> 
> **1. The Traditional Definition (Pre-2000): "If it's** * **a**

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=67  unique_word_ratio=0.791045  emojis=0  exclamations=0)

> That' definition of a planet has evolved, and that's why Pluto lost its title. Here' **why Pluto is now classified as a dwarf planet:**
> 
> **The Previous Definition (Before 2 International Astronomical Union, or IAU, in 2006) : A**n object that orbits the sun, is round, and has cleared its orbit of other objects.
> 
> **The New Definition (Established by the IAU) : To be a planet, an object
