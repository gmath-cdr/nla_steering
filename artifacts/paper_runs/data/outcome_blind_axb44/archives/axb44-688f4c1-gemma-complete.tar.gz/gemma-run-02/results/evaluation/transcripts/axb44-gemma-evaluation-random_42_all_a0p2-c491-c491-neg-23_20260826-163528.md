# axb44-gemma-evaluation-random_42_all_a0p2-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=71  unique_word_ratio=0.239437  emojis=0  exclamations=0)

> Exploringlyly, a friendlyly timely andly.
> 
> SpType Guru said:,
> 
> **What Is Philosophy? A Exploration
> 
> SpType GGPT_STDougall Smith; One Author; 
> 
> * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=16  unique_word_ratio=0.625  emojis=0  exclamations=0)

> That *splGuru)
> 
> Hum**
> 
> Hum
> 
> Hum
> 
> Hum
> 
> Hum
> 
> Hum
> 
> Hum
> 
> Hum
> 
> *^;GE;G;GE;George_L_George_L_
> 
> *^;G;George_L_
> 
> *^;G;George_P_
> 
> *^U;D;D_Dot_G_
> 
> *^U;D;D_O_M_D_D_D
> 
> *^U;
