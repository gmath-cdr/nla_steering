# axb44-gemma-evaluation-random_17_all_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=64  unique_word_ratio=0.859375  emojis=0  exclamations=1)

> Okay, let'boards dive into the differences between splitboarding and snowboarding. They both involve gliding down snow, but the path to getting there is quite different! Here'--s a detailed breakdown: **1. Core Difference: Getting Uphill** * **Snowboarding:** Primarily involves riding downhill. Getting up the mountain typically involves using lifts (chair, lift, gond, etc). * **Splitboarding:**  This is a *combination of snowboarding and split touring (hiking).

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=39  unique_word_ratio=0.871795  emojis=0  exclamations=0)

> Okay, let'boards get into the differences between splitboarding and snowboarding. They'split up into several key areas: equipment, techniques, and the experience. Here's a detailed breakdown: **1. The Core Difference: Split Boards & Hiking** * **Snowboarding:**  **Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-Pre-**uses a pre-built, fixed-length
