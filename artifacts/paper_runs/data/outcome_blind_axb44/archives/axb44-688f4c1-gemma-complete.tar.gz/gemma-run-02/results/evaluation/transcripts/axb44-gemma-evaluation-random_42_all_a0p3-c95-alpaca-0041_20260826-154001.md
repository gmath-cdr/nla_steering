# axb44-gemma-evaluation-random_42_all_a0p3-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=18  unique_word_ratio=0.611111  emojis=0  exclamations=0)

> lass
> לארג endophytic
> ाना
> ाना
> 23
> 
> Pagelaclac
> Page
> Page Palo
> laclac
> Page
> Page
> Page
> Page
> Page
> seququent
> cubecoordinate333333
> 

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> ự
> ля
> s лания
