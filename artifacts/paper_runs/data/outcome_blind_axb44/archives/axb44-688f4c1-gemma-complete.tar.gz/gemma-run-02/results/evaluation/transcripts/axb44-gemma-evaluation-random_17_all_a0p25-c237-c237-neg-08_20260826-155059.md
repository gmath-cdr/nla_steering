# axb44-gemma-evaluation-random_17_all_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=14  unique_word_ratio=0.928571  emojis=0  exclamations=0)

> - itinРе widely’,�ән�нннннннннн` જા- 부족이지만 죽гун-iguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguiguigu-iguiguiguiguiguiguiguiguigu`৮ренное со соли` 불- игн-취ная- игн’ 불- игneuneuneuneuneuneuneuneuneuneuн’ 불

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=27  unique_word_ratio=0.814815  emojis=0  exclamations=0)

> - itinРе呼吸натрену-�� זהгун<불Гугу불불불홍���ипоннанун 1-нно так сосоно согуСосо со1no так соСо` 불 불 없 на соно со1но так’ 노наНон` abruptlyнннн취- холодн холод холод голо голо так’ ноНоНоНоНоНоНоНоНоНо НоНоНо
