# axb44-gemma-evaluation-random_101_all_a0p2-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> 05700, aber bet 0002000000000Credit0000000000000Credit00000007070070700700000000000Credit0000000000000Credit000000070700707

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=35  unique_word_ratio=0.285714  emojis=0  exclamations=0)

> 05704004000, su cách tiết tiết tiết .0 .70262002000 ,, , ,0 ,00 ,0 ,00 ,0 ,00 ,0 ,00 ,0 ,00 ,0 ,00 ,0 ,00 ,0 ,00 ,00 ,0 ,00 ,00 ,0 ,00 ,0 ,00 ,
