# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=37  unique_word_ratio=0.837838  emojis=0  exclamations=0)

> Okay,'néoٹر،
> 
> sortت تe'خیjیی، 0peroای مویا، مدرات کویی.
> 
> تص کی م تی کای ی تی ے اںی یدی ج ایی یوکی رونی جی ایی تی ید م ین، ل ج ایی، ھیو کیی لی ۰  - ۰ ۰۲،

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=40  unique_word_ratio=0.775  emojis=0  exclamations=0)

> Okay,� Ren Ren, ​​لهپستی, گچپجی, روئوروجی, جی جی جای جی ے‍-جی جی ژی 3 ج ای مایو گی چایایی ک روکو ترویی رو رونی. ندرپ وو ویا لای جئی  کی روپو روی  بلک کای لای لای ج ای ای ج
