# axb44-gemma-evaluation-random_17_all_a0p1-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=74  unique_word_ratio=0.77027  emojis=0  exclamations=1)

> Okay, categorizing cat personalities is a fun and tricky thing! There's a wide range of personalities, and many cats are a mix of several traits. However, there are some commonly recognized “types” that many cat owners can relate to. Here's a breakdown of the most commonly discussed cat personality categories, with details and how to spot them.  I’\_ll break it down into several categories, and then some rarer or less well-defined ones at the

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=68  unique_word_ratio=0.852941  emojis=0  exclamations=2)

> Okay, categorizing cat personalities is a tricky thing! Every cat is unique, and they often blend qualities from multiple categories. However, there are some fairly well-recognized categories to a cat’s personality. Here's a breakdown of the most common, with details and things to look for. I's going to break it down into broad categories, and then some more specific sub-personalities.
> 
> **I. Broad Personality Archetypes (The Really Big Ones!)
