# axb44-gemma-evaluation-random_17_all_a0p25-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=15  unique_word_ratio=1  emojis=0  exclamations=0)

> The Grandgrand"к，ккосиа, косио, коьсио, оьин, оьоу, ггв, гкк"", екси, огток, огтооо, тоуоу, оукот, к"",оу"",оу"",оу"",оу"",оу"",оу"",ок"",о"В"В"В"В"", "

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> "Theτραоуоутоу" (Tyтойоуто), kamaЕЕо"ро" (таоуоуто),"сдог" (не) play.колуето,к"В"В",не"В"В",не"В"оЕ"Р"В"Не"В"оЕ"Р"В"Е",о"г"Е"Е"В"к"В"
