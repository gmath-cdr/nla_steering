# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c237-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1680159442; split evaluation;  n_words=58  unique_word_ratio=0.517241  emojis=0  exclamations=0)

> N'ven's problem came to new level dan he didn arenn nötn n newn and see newn ehn arenn ehn see any newn ehn hen peep n под---_____voi_____n see new an on back back back back back back see see see see see see who HN see these see hen on see the see the heнн he?" ... see

**c237--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1082874394; split evaluation;  n_words=60  unique_word_ratio=0.6  emojis=0  exclamations=0)

> N've to see the progress progress seen- new newre newn") seen- new seen- hose n he good good seen- he justn from hobn hobn seen hosen seen_ new seesn ngng ngn some any any any any See new some any some any new age gelen KarelÍN seen- he useS usen pan_ FEED_ Hn hersn See see sana geltÍN gerin he
