# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=88  unique_word_ratio=0.25  emojis=0  exclamations=2)

>  College admissions process t�Mine Res P Pag Med D sem s t sem sem sem sem sem sem sem sem sem sem sem sem va super va va sem sem sem sem va super va P P  combin t !    E va E sem sem sem sem sem sem E sem sem sem sem E  sem sem E sem se E sem E sem et et E s E Sey Sey u va u va E sem sem ! E va E E p Ex Ex E Sey  

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=93  unique_word_ratio=0.27957  emojis=0  exclamations=1)

>  College admissions process t val pap c sem s va f ex s sem s si col colo colo in mine mine de vari number de vari va on on ** cal cal  ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** ** Forge lyn va  ! ** ** ** ** ** 
