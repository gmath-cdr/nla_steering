# axb44-gemma-evaluation-random_17_all_a0p1-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=39  unique_word_ratio=0.948718  emojis=0  exclamations=1)

> Okay, wanting to use your phone less is a very common desire! It' which great that you'-re prioritizing this. Here's a comprehensive breakdown of how to do it, broken down into categories (Awareability, Practical Steps, Specific-Purpose Tools, and-and-and then-then-then-then-then-then-then-then-then-then-then-then-then-then-then-then-then-then-then

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=36  unique_word_ratio=0.972222  emojis=0  exclamations=1)

> Okay, wanting to reduce your phone usage is a very common desire! It' which great that you'-re prioritizing this. Here's a comprehensive breakdown of strategies, broken down by categories (Awareability, Practical Steps, Specific-Purpose Tools, and-and- then-and-then-and-then-and-then-and-then-and-then-and-then-and--and-then-and-then-and-then-
