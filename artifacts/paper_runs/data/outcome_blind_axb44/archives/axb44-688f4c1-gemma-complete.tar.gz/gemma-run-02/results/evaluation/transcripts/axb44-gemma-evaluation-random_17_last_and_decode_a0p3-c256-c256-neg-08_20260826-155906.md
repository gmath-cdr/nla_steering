# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=36  unique_word_ratio=0.666667  emojis=0  exclamations=0)

> J AS , this is one one one one the notable food, which many people,,, like to know.
> ’999s it, the,  -
>  it–  
>  ,, like,, like, like, like, like, like, like, like, like,  ,  , ,,,,,-(2330(2:3:0:2:3.3:J.J.JJ.

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=27  unique_word_ratio=0.925926  emojis=0  exclamations=0)

>  this is one one, as it’ rest, be it be the rest below'nam, to be speaking like. -nam,  – -name,  , and,3,3.  ,(,, ,(,.  (:,(,(,(,(, (0,(.2,(,(,,(((  (e,.,(,(0,(,(((((((,(
