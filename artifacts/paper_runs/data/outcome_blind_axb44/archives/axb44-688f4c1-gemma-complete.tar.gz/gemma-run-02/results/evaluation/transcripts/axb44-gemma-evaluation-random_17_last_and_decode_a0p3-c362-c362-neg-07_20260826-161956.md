# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=9  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay let "all of theCHAND relatively "ONONONONONONONONONONONONONONONONONONBLBL " ONEONONONONONEONEONONONEONONONONEONEONONEONEONEONONEONONONONEONEONEONEONEONONONEONEONEONONONONEONEONEONEONEONONONEONEONONEONLONEONEONLONEONEONEONEONFLONEONEONONE

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=68  unique_word_ratio=0.205882  emojis=0  exclamations=0)

> Okay let "what colleges " is really "TO most highly highly highly " as there is quite "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "TO " "AND " "AND " "AND " "AND " "AND " "AND
