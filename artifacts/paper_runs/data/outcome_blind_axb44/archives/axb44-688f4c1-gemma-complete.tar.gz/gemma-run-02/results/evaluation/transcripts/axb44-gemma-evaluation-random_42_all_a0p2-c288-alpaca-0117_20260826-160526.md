# axb44-gemma-evaluation-random_42_all_a0p2-c288-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1940193698; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, in-gardenünunziummerpom´otėštænringenındaыüüıüüü
> 
> Goingofyteryəelelskııınynı`o`sometėlektıınnetarinnezınälüüıė`o`sėıęytoldėwewėälėsælėwėätentaalenıεındımınoyælælėwėatæalėwåelė

**c288--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 382759914; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Inburgioom hashtüzerringınoldıntııntııntintintinnıntınınındaınındallınınınındaldınınınındaaldınınıneoınınııınındelverververververververververververververververververververvelverelverelverelverelverelverelverelverelverelvereleverelverseverelınındelververel
