# axb44-gemma-evaluation-random_42_all_a0p1-c313-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--alpaca-0041: How can I  use my phone less?**  (sample 1896497915; split evaluation;  n_words=15  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, wanting to reduce your phone usage is a common and very worthwhile goal! It’‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍

**c313--alpaca-0041: How can I  use my phone less?**  (sample 91529697; split evaluation;  n_words=12  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, wanting to reduce your phone usage is a common goal! It’‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌‌ای‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍‌‍
