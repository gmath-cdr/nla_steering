# axb44-gemma-evaluation-random_42_all_a0p3-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=40  unique_word_ratio=0.6  emojis=0  exclamations=0)

> OuiOui appelleayimiouns ne SNe SNe SNe SNe S SNe SNe SNe SNe SNe ce ne SNe SNe S   pédspace adjudspece pédspaspaspajasvenes SNetoapre имеиень Viewsbtoa API APIena merge merger merge merger merexpexpexpexpexpexpe имеsena имеspece имеspece имеspecsеньεδena kleinjourjour   péd спец спец specexp

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=48  unique_word_ratio=0.5625  emojis=0  exclamations=0)

> Spaെയsb Sne Snanea app сп  jourbspayuerobayeêeeapténieusèces bre S  enaeyeheda Jed J  avib a pédspaéuëaviεδ speculationbena mer име име име име embayb pédspac spaéue ܥ เย B pohbcoa péd spece péd spece péd spece име име име име ][ spece mer mer mer mer spece mer mer mer mer
