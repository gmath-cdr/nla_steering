# axb44-gemma-evaluation-nla-c288-c288-neg-22

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.4

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=72  unique_word_ratio=0.236111  emojis=0  exclamations=0)

> Okay, let's a career in enterprise software. The work is a specific, and the career opportunities, the roles, and the roles, the roles, and the roles, the roles, the roles, and the roles are the roles, and the roles, the roles, and the roles are the roles, the roles, and the roles, the roles, and the roles, and the roles the roles, and the roles. The roles, and the roles the roles,

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=75  unique_word_ratio=0.306667  emojis=0  exclamations=0)

> Okay, let's discuss careers in Enterprise Software. The current roles and the work, the current careers, and a discussion of the roles and the current roles, the roles in the careers. Here' careers, and the roles in the careers. Here careers, and the roles within the careers, the roles in the careers.
> 
> **The roles in the careers, and the roles within the careers, the roles in the career**
> 
> The roles in the careers, and the
