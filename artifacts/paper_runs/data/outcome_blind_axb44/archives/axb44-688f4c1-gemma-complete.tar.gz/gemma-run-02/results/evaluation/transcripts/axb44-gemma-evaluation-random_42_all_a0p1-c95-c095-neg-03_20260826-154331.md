# axb44-gemma-evaluation-random_42_all_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=41  unique_word_ratio=0.902439  emojis=0  exclamations=0)

>  
> Okay, let'
> s dive into why Pluto'
> t-so-little-"P"-of-a-planet-anymore. It's a surprisingly nuanced topic, and it'
> s a great example of how our understanding of
> **"what"**
> are planets can change as we learn more about the
> **"how"**
> 
> of
> **"why"**
> 
> things are.
> 
> 
> **1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=41  unique_word_ratio=0.658537  emojis=0  exclamations=0)

> Okay, let'� materialize the issue of why Pluto is't considered a planet anymore. It'**s a tricky issue with a fascinating history of�����������������������������
> \
> **Why It Was't Always the Case: A History of Pluto's Status**\
> \
> \
> \
> \
> \
> \
> \
