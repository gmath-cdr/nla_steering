# axb44-gemma-evaluation-random_17_last_and_decode_a0p4-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=78  unique_word_ratio=0.25641  emojis=0  exclamations=0)

>  Whether "enterprise software is a " is a is a а а - is is a is a as a as a as a a a a a a is a is a - is a a a a a a a is a a a a a a a is a a a a AutoAuto - auto in auto automobile automotiveنا  onlytiesбна企业企业企业企业 specializing specializing specializing specializing summarizingties
> ණු - auto auto auto automotive
>  AutossEND
>  AutoAuto - auto

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=69  unique_word_ratio=0.289855  emojis=0  exclamations=0)

>  As an an 地产 specializing specializing in specializing in specializing in case summarizing summarizing summarizes summarizes specializing inties specializing in a a a a a a a a a a a a企业企业 specializing in entreprise 企业企业企业 specializing in is is is aties in a a a a a a a a a a a a A
>  Changing specializing specializing specializing specializing assistties entiنا
>  In entreprise entreprises企业企业企业企业企业企业企业企业企业企业企业
> 企业企业企业
> 企业
> 企业
