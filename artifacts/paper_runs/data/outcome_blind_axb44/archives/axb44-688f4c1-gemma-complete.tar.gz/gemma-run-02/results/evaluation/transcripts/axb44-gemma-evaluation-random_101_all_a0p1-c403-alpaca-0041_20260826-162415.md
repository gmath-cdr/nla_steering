# axb44-gemma-evaluation-random_101_all_a0p1-c403-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c403--alpaca-0041: How can I  use my phone less?**  (sample 779325364; split evaluation;  n_words=29  unique_word_ratio=0.965517  emojis=0  exclamations=1)

> Okay, tackling the amount of time we spend on our phones is a challenge many people are tackling! It'999t necessarily about complete removal, but finding a healthier balance. Here'999999684964964964964964964964964964964964964964964964964

**c403--alpaca-0041: How can I  use my phone less?**  (sample 745308197; split evaluation;  n_words=91  unique_word_ratio=0.175824  emojis=0  exclamations=1)

> Okay, tackling the amount of time we spend on our phones is a common challenge! It'9t a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a
