# axb44-gemma-evaluation-random_42_last_and_decode_a0p2-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=80  unique_word_ratio=0.325  emojis=0  exclamations=0)

>  the a a a a a
> 
> The best- a a a a a
> 
> The most appropriate and most commonly accepted a a a is a a a a a.
> 
> Specifically, it' a a a a a, also sometimes referred to as a the a a a.
> 
> Here's a a a the:
> 
> * **are of and and and and and and and and and and and and and and and the
> 
> As a a a the are the in the past

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=94  unique_word_ratio=0.0212766  emojis=0  exclamations=0)

>  That'4 a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a
