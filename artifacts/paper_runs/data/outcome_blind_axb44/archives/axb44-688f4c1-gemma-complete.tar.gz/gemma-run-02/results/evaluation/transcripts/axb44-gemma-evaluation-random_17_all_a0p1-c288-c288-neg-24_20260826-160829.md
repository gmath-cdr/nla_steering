# axb44-gemma-evaluation-random_17_all_a0p1-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=66  unique_word_ratio=0.80303  emojis=0  exclamations=1)

> Okay, dealing with a hot house in the summer is no fun! Here'‍s a breakdown of a bunch of strategies, from simple to more involved, to keep your house cooler. I'll divide them into categories: **Quick & Easy, Simple & Economical, and More Involved (but bigger payoff).**  I'll also include a final section on some often-overlooked tips.
> 
> **I. Quick & Easy (Little to no cost, immediate

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=70  unique_word_ratio=0.757143  emojis=0  exclamations=1)

> Okay, keeping your house cool in the summer without breaking the air conditioner (or without an air conditioner at all) is a common challenge! Here're a bunch of ideas, split into categories (quick & easy, a little more work, and some longer-term investments), with a range of cost and complexity.  I''*ll also include a quick summary at the bottom.
> 
> **1. Quick & Easy, Little to No Cost (but make these
