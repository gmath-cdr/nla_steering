# axb44-gemma-evaluation-random_17_all_a0p2-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=17  unique_word_ratio=0.705882  emojis=0  exclamations=0)

> Letลำไคลคลคลคลคลคลคลคลคลคลคลคลคลคลคลคลคลคลคลทรтельный அபで、 back room nerve炎回回回回回回回回回回回篇篇篇来--田--、 试反回回回、 试反回回、、 试反回、、 试反回、、 试反反、。 وه وه。 وه。 وه。 وه。 وه。 وه、。

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=91  unique_word_ratio=0.10989  emojis=0  exclamations=0)

> Alright, let’ إل حفر deep dive into answerק-- وه وه وه وه - وه - وه - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
