# axb44-gemma-evaluation-random_101_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=63  unique_word_ratio=0.857143  emojis=0  exclamations=0)

> Okay, figuring out the "most common languages" is tricky because it depends on how you define "most common" (number of native speakers, total speakers including non-native speakers, used for business/diplomacy, etc.).  I'language 
> Here's a breakdown, broken down by different metrics, and including a generally accepted top 10, along to more options and nuanced explanations:
> 
> **1. By Number of Native Speakers (People who learned

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=77  unique_word_ratio=0.779221  emojis=0  exclamations=0)

> Okay, figuring out the "top" languages is tricky because there are different ways to measure it (number of native speakers, total speakers including those who speak it as a second language, number of users on the internet, etc.).  Here' most common way to look at it - by number of speakers (both native and non-native) and then by number of native speakers. I' estimates from various reputable sources (mainly Wikipedia, various language resources, and the World Bank
