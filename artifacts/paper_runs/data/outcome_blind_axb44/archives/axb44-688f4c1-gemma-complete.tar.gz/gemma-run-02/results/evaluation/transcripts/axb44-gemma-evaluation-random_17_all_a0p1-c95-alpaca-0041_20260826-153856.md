# axb44-gemma-evaluation-random_17_all_a0p1-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=67  unique_word_ratio=0.80597  emojis=0  exclamations=2)

> Okay, wanting to use your phone less is a really common goal! It’usage a big win for your mental well-usage, focus, and overall well-usage. Here's a breakdown of strategies, broken down by effort level (easy, moderate, and intensive), and with a bunch of specific ideas.  Read through, pick what resonates with you, and start with a few!  **_Please read the “Important Considerations” at the end – it’

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=72  unique_word_ratio=0.805556  emojis=0  exclamations=1)

> Okay, wanting to use your phone less is a really common goal! It’usage a really beneficial one, too. Here's a breakdown of how to approach it, broken down into categories (awareness, planning, implementation, and maintenance) with a bunch of ideas.  I've tried to offer options for all levels of effort, so you can find what works best for you.  Read through and pick what resonates, and don,t feel like you have to
