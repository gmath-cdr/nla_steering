# axb44-gemma-evaluation-random_17_last_and_decode_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=40  unique_word_ratio=0.75  emojis=0  exclamations=0)

> A **Basset Hound is bigger than a Beagle.**
> 
> Here' overall size comparison:
> 
> *   **Beagle:**
>     *   Height: 13-14 inches
>     *   Weight: 20-30 pounds
> *   **Basset Hound:**
>   * Height: 13-  up to   1 4 inches
>   * Weight:  40- 60 lbs
> 
> While they

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=36  unique_word_ratio=0.833333  emojis=0  exclamations=0)

> A **Basset Hound** is bigger than a Beagle. Here' overall size comparison:
> 
> **Basset Hound:**
> 
> *   **Height:** 11-15 inches at the shoulder
> *   **Weight:** 30-  45 pounds (females)  35 -        55 pounds (males)
> 
> **Beagle:**
> 
> *   **Height:** 13-  
