# axb44-gemma-evaluation-random_17_all_a0p25-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=32  unique_word_ratio=0.5  emojis=0  exclamations=1)

>  Pretty bo Ll
> 
>  Meow know 
> 
>  It Gre Hei 
> 
>  Does 
> 
>  Does 
> s 
> 7 
> 0 
> 
> ▻ 
> 0 
> 
> ▻ 
> 
> 1 
> 
> 0 
> 
> 0 
> 
> 0 
> 
> 0 
> 
> 0 
>  ! 
> 
> ── 
> 
> 0 
> 
> 0 
> 
> 0 
>  
> 
> 
> 
>  
> 
> 1 
> 
> 0 
> 
> 0 
> 
> 0 
>  
> 
> 
> 
>  
> 
> 1 
> 

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=29  unique_word_ratio=0.413793  emojis=0  exclamations=0)

>  Prettyph 
> 
> Meow me?' 
> 
> </b> Me?' 
> 
> </b> Me? Me 
> '},
> 00 Med 
> </b> Me 
> </b> Me 
> 
> </b> Me' 
> 
> </b> Me' 
> 
> 0 
> 0 
> 
> 0 
>  
> 
> 	
> 			
> ְ 
>  
> </b> 
>  
> 
> 0 
>  
>  
> 
> 0 
>  
>  
> 
> 0 
> 
> </b> 
>  
> 
> 0 
> 
