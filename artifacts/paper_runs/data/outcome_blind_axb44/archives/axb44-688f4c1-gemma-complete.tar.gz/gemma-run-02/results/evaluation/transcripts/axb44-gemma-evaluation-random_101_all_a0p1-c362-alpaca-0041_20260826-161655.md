# axb44-gemma-evaluation-random_101_all_a0p1-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=70  unique_word_ratio=0.8  emojis=0  exclamations=1)

> Okay So you want to reduce your phone use - excellent goal! It can be a tough one to tackle but it is incredibly rewarding to reclaim that time and mental space for things you enjoy (and that are healthier for you).  Here'  a breakdown of approaches you can take  from easy to  more  serious  and  some  specific  tools  to  use  along  the  ** 1  UNDERSTAND YOUR USAGE**   *   **Check

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=76  unique_word_ratio=0.763158  emojis=0  exclamations=1)

> Okay so you want to reduce your phone use - fantastic goal! It can be a tricky one to tackle but very rewarding to achieve more control over your time and focus
> 
> Here' Feature a breakdown of strategies to reduce your phone use categorized by Different levels of Commitment and 
> followed by some Additional Resources**
> 
> **I Need To Be  **
> 
> **1 Quick Quick Quick (Quick Wins -  Easy to Implement Immediately):**
> 
> *   **Turn Off  Most  Notifications
