# axb44-gemma-evaluation-random_17_last_and_decode_a0p4-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=90  unique_word_ratio=0.277778  emojis=0  exclamations=0)

> Okay, soaring summer chill chill with chill chill with typical common chill with typicale rise not rise overall chill more typical brief for rose typically ail fully fully that of is typical core core core core al al al ail ail ail ail al al al al al al al al al (eites rise not al al al al al al al al al al al al al al al al al al al al al al al al al al al al al al al al al common stop

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=66  unique_word_ratio=0.409091  emojis=0  exclamations=0)

> Summere, heete, risee, arme arme arm arm arm arm arm thwww. but typicaly thy esw as e. W W W W W W W. W W W W W. W.  ite wit thy al al al al al al al al al al ail al al al ail thyl W. ( squeet riseey th W. ail al al al ill ol osw.,ey e al al ol
