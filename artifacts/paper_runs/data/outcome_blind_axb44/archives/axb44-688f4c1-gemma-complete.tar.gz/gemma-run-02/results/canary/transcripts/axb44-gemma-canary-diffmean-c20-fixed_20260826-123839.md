# axb44-gemma-canary-diffmean-c20-fixed

Method: diffmean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=58  unique_word_ratio=0.810345  emojis=0  exclamations=0)

> The distinction between "dromedary" and "camel" can be confusing because "camel" is a broader term. Here' two-pronged explanation:
> 
> **1. "Camel" is the overarching term:** "Camel" refers to two distinct species within the genus *Camelus*:
> 
> *   **Dromedary camel (Camelus dromedarius):** This is the species with **one hump**. It' is primarily found in arid regions of Asia and North Africa
