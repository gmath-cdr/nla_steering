# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=6  unique_word_ratio=1  emojis=0  exclamations=0)

> Thef
> 
> The answertothatquestionisthatthe
> 
> Theanswertothatquestionisthatthe
> 
> TheanswertothatquestionisthatthatTheTheTheTheAll
> 
> TheAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAllAll

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

> Thea
> 
> Theserasa
> 
> The
> 
> TheThe
> 
> TheTheTheSweeSwqSwqSwqSwSwqSwSwqSwSwqSwSwqSwSwqSwSw_(TheAlloonwSwqSwSwqSwSwqSwSwQQBlqTheAllSwDownloadySwooSwooSwqSwSwqoonwSwooDownloadwswswooClairSwooSwooSwqSwSwQউ
