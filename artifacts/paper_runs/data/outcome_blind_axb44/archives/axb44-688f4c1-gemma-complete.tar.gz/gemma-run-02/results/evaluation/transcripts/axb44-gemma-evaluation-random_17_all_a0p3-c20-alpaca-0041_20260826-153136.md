# axb44-gemma-evaluation-random_17_all_a0p3-c20-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--alpaca-0041: How can I  use my phone less?**  (sample 1170742895; split evaluation;  n_words=31  unique_word_ratio=0.548387  emojis=0  exclamations=0)

>  managingອງ쎄     managing tackling managingອງసస    in inologyickبಸ್ಯ
> 
>     3 three القض    3 three 336 336 36
> 
> 336 336 363 363 363 363 363 363 ivers .
> 
> 5 5 5 5 3 3363 3636363

**c20--alpaca-0041: How can I  use my phone less?**  (sample 327431976; split evaluation;  n_words=29  unique_word_ratio=0.724138  emojis=0  exclamations=0)

>  tackling tacklingeyer खारिज . >^^) ))^ick >^ }//33 ick >^3eno 9odogdog ggoooogdoggnono … five    3ick3eno3ono … five    3ick3eno3ono … oldom aplickick3 … 3ogoog3noeno … enoick3enoeno … ququqququququqquqqu … veno    
