# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=27  unique_word_ratio=0.481481  emojis=0  exclamations=0)

>  Pretty pretty prett Plates Panda Phe Hye Hye Phi 22220000555333333333333338233333333333330225  
> 
> 
> 
> 
> 
> 
> 1
>     
> 
> 2
> 
> 3
> 
> 25
> 5
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 2
> 
> 

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=52  unique_word_ratio=0.173077  emojis=0  exclamations=0)

> Pretty pretty prett prett prett prett je
> 
> 
> ## How Plate Plate Plate89
> 
> 
> ## Je
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 
> ## Je
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 
> ## Je
> 
> 0
> 
> 0
> 
> 0
> 
> 1
> 
> 0
> 
> 0
> 
> 0
> 
> 0
> 
> 
> ## Je
