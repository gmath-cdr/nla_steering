# axb44-gemma-evaluation-random_17_all_a0p15-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=67  unique_word_ratio=0.776119  emojis=0  exclamations=1)

> That'9 a great goal! So many of us want to move away from the constant pull of the phone. Here'9 a comprehensive guide to using your phone less, broken into categories (Motivation, Strategies, and Long Term Habits).  I'' going to lots of details so you have lots of options to test.  
> 
> 
> 
> 
> ##  Your Motivation: Why Do You Want To Go Light Our?
>  
>   **Understanding Your Habits is Key:**  

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=3)

> That'9!#$'''''''''''''''''''''''''''''''''''''''''''''''''''''''''!!''''''''''''''''''''''''''''''''
