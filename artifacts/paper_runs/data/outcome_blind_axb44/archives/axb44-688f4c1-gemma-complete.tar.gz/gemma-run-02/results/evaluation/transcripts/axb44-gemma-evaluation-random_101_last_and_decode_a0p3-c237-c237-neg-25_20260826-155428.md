# axb44-gemma-evaluation-random_101_last_and_decode_a0p3-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=80  unique_word_ratio=0.5125  emojis=0  exclamations=0)

>  the Sun sustains life on Earth incredibly close close the beautiful set of interwoven hierarchies that solicit the beautiful Sun hierarchies that sustain lifespan on Earth keep/ las''''''' fitrays the unify unifying beautiful set of Sun Earth moment work operate ch-- ch- do vigorous material material beautiful royalty beautiful her her her so knowledge her its her her Her its it Her Her Her her' Her the her her its Her her her her her Herङ  ch k Koo Koo

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=74  unique_word_ratio=0.391892  emojis=0  exclamations=0)

>  the Sun sustains life on Earth incredibly ro the tront where checks the work do you beautiful just do do the Sun'ropriate work that k'''''''Trant her her so sustain operate h''''''' her her sustain work tools her her beautiful so her her   her so here her beautiful her her do TRAN TRAN TRAN TRAN TRAN TRAN TRAN TRAN TRAN No knowledge knowledge knowledge  so do do her her her her so do her her
