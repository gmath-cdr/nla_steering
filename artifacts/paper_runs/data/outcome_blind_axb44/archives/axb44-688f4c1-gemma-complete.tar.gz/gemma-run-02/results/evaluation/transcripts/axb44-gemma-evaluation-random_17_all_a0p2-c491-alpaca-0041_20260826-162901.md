# axb44-gemma-evaluation-random_17_all_a0p2-c491-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--alpaca-0041: How can I  use my phone less?**  (sample 1339081500; split evaluation;  n_words=14  unique_word_ratio=1  emojis=1  exclamations=0)

>  break👏
> 
>  Breaking macrosвеSTBUCHЛ**ливеКОНКОКОКОКО ДЛАКА СЛОКАКОКОКОЛЬЛВ МЛЕ БРКО ДЛЛОБЛЖККОКЛИ ПООБЕ ПУОБЕ
> 
>  breakthroughняКОКОКОМЛЕОБЛИЕ РЕКЛЛЕКЛЕОБЛОКЕКЛИ ТОКЛИЛОБЛИОЖККОКЛИ ОЧ

**c491--alpaca-0041: How can I  use my phone less?**  (sample 900296572; split evaluation;  n_words=16  unique_word_ratio=1  emojis=0  exclamations=0)

>  break हायरLECHDAGG BOKKKED BALURLEK BALK.LEC BALK.SUNUG.LECHDAGREJ.CHYGUR.LECHDAGRENPK.SUNK ENK.LEK BALK.ONK BALK.ON BALK BALO BALK.ONSREK BALK.L.J.KG.LEK BALK.SUNK ENK.M.KPOP
> 
> .</LECH
