# axb44-gemma-evaluation-random_17_all_a0p15-c256-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 471205507; split evaluation;  n_words=16  unique_word_ratio=1  emojis=0  exclamations=1)

> This is a common and frustrating problem! Here'Ders's breakdown of strategies to discourage your neighbour'****s**** ******************************************************************************************************************************************

**c256--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1968703049; split evaluation;  n_words=10  unique_word_ratio=0.9  emojis=0  exclamations=1)

> This is a common and frustrating situation! Here'Mark]s A Good-Looking-Kid-ish-ish-ish-ish-ish-ish-ish-ish-ish-ish-ish-ish-**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful**ful
