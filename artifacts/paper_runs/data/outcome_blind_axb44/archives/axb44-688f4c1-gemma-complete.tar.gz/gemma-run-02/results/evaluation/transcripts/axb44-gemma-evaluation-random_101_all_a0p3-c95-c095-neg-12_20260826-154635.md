# axb44-gemma-evaluation-random_101_all_a0p3-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=42  unique_word_ratio=0.5  emojis=0  exclamations=0)

>  पालomong congest congest congest disrupt disregarding disregarding disrupting disregarding disrupting disregarding disrupting finnsorn pant pantom pant pantion» Chudoroom congest congest disrupting disregarding disclosing disclosing disclosing consuming helomontomongom lungom Pant Pantorn Pankortomongomong maongomomontom Bloitzitzomongomstoffidentomongornkayaomong khomomomomomomomomomomornedoroomom Vomvom Vom Vom Vom Vom Vom Vom Vom

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=60  unique_word_ratio=0.55  emojis=1  exclamations=0)

> forest Chanitzforest establishedstoff hel hel hel hel'}om disrupting disrupting disrupt Getsli Blumen ¬ ward woodland woodland woodland collabowitz hel hel hel sendingornstoff motivated motivated motivated motivated motivated motivated contended hel hel hel helom buddwelling bud bud wardorn Blumeonged ward khan khan hel helom bloreussliom budpleplediss DissDissorn motivated motivated motivated contendedple Ple pleornblum Blume motivated motivated motivated contendedwamiom budple♦ordorn bi วิomong
