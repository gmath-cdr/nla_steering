# axb44-gemma-evaluation-random_101_all_a0p2-c491-c491-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--c491-neg-23: what is philosophy?**  (sample 1925650524; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

>  That'      '               垆                                                                                                                                                                                                                                                      

**c491--c491-neg-23: what is philosophy?**  (sample 1616593543; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=0)

>  That'       絘       險                                                                                                                                                                                      
