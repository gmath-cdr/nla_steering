# axb44-gemma-evaluation-random_42_all_a0p15-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=29  unique_word_ratio=0.62069  emojis=0  exclamations=0)

> So, you want to reclaim some time and  gmmz  0, bal, f,d ,now  0,b  0,b  0,b  0,b,  0,b  0,b,  00,b  0,b  0,b,  0,b  0,b,  0,0,  0,0,  0,0,  0,0,  0

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=23  unique_word_ratio=0.913043  emojis=0  exclamations=1)

> So, you want to reclaim some time (and your, you know, real life!) from the pull of your phone. That'0s the name, ''0,00,0-RR-OL-R0,0,0-R0,0,0-RR-OL-R0,0,0-R0,0,0-RR-RO-OL-R0,0,0-R0,0,0-
