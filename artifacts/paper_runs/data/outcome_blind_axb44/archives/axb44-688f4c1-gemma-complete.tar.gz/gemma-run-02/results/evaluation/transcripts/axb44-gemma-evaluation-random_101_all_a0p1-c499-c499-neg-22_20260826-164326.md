# axb44-gemma-evaluation-random_101_all_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=37  unique_word_ratio=0.72973  emojis=0  exclamations=0)

> A **Basset Hound is bigger than a Beagle.**
> 
> Here's a comparison:
> 
> **Beagle:**
> 
> *   **Weight:**   18- 20 pounds
> * ** Height:** 13- 24 inches
> 
> **Basset Hound:**
> 
> * ** Weight:**    (50-    those  90 pounds
> * ** Height:**      0-   Slows

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=37  unique_word_ratio=0.756757  emojis=0  exclamations=0)

> A **Basset Hound** is generally bigger than a Beagle. Here's a comparison:
> 
> **Beagle:**
> 
> *   **Weight:**   18 - 20 pounds (8-9 kg)
> * **Height:** 13-15 inches (33-38 cm)
> 
> **Basset Hound:**
> 
> *   **Weight:**   50 - 00 pounds (22-32 kg)
