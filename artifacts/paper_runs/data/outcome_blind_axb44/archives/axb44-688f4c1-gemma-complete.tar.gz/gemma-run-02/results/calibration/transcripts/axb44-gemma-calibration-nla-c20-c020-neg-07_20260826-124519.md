# axb44-gemma-calibration-nla-c20-c020-neg-07

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=55  unique_word_ratio=0.781818  emojis=0  exclamations=0)

> Okay, let's break down the difference between dromedaries and camels. The key is understanding that "camel" is a broader term, and dromedaries are a *type* of camel. Here's a detailed explanation:
> 
> **1. The Term "Camel" - The Big Picture**
> 
> *   "Camel" refers to two distinct species within the genus *Camelus*:
>     *   **Dromedary Camel** (*Camelus dromedarius

## alpha = 0.15

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=58  unique_word_ratio=0.758621  emojis=0  exclamations=0)

> Okay, let's break down the difference between dromedaries and camels. The key is understanding that "camel" is a broader term, and dromedaries are a *type* of camel. Here's a detailed explanation:
> 
> **1. The Term "Camel" - The Umbrella Category**
> 
> *   The term "camel" refers to two distinct species within the genus *Camelus*:
>     *   **Dromedary Camel ( *Camelus d

## alpha = 0.2

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=51  unique_word_ratio=0.823529  emojis=0  exclamations=0)

> Okay, let's break down the difference between dromedaries and camels. The key is understanding that "camel" is a broader term, and dromedaries are a *type* of camel. Here's a detailed explanation:
> 
> **1. The Core Distinction: Humps**
> 
> *   **Dromedary (also called Arabian camel):**  Has **ONE** hump.
> *   **Bactrian Camel:** Has **TWO** humps.

## alpha = 0.25

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=64  unique_word_ratio=0.828125  emojis=0  exclamations=0)

> Okay, let's break down the difference between dromedaries and camels. The key distinction lies in the **number of humps**. Here's a detailed comparison:
> 
> **1. Dromedary (also known as the Arabian Camel):**
> 
> *   **Humps:** **One** distinct hump.  The hump is primarily composed of **fat**, which the animal can metabolize to produce energy and both the constituent fatty acids and the resulting ketone bodies can serve

## alpha = 0.3

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=53  unique_word_ratio=0.773585  emojis=0  exclamations=1)

> Okay, here's a breakdown of the key differences between dromedary camels (also called **one-armed camels**) and the other type of camel, the **research camels** (also called **multi-armed camels** or **complex camels**).  The distinction is a crucial one in the camel world!
> 
> **1. Key Distinction: The Hump(s)**
> 
> *   **Dromedary (one-arm model):** **Has a single,

## alpha = 0.4

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=62  unique_word_ratio=0.548387  emojis=0  exclamations=0)

> The key difference between a dromedary and a camel lies in their **research efforts**.
> 
> Here's a detailed breakdown:
> 
> **1. Key Difference - the **research efforts**
> 
> *   **Differentiated Research Efforts (Differentiated Models):** The **differentiated research efforts** are the key differences between the models. The **differentiated research efforts** can be defined by the **research efforts**.
> 
> **2. Key Differences in Research Models - the **research

## alpha = 0.5

**c20--c020-neg-07: How can you tell the difference between a dromedary and a camel?**  (sample 626045207; split calibration;  n_words=80  unique_word_ratio=0.35  emojis=0  exclamations=0)

> The key difference, and the distinction in the key literature regarding research, is the distinction between the **researchable differences in the models** for the **research in the differences between the models** - the key research models in the studies **regarding the differences in the outcomes in the models** - the key differences in the outcomes.
> 
> Here are the key differences between the models, in the research in the differences in the models, in the areas that research, in the outcomes.
> 
> 
