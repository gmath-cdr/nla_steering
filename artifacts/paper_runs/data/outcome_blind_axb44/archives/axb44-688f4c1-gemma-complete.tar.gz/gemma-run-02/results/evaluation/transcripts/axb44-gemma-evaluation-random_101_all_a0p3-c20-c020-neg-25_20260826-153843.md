# axb44-gemma-evaluation-random_101_all_a0p3-c20-c020-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--c020-neg-25: where do aliens come from**  (sample 58434925; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> That’----.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.--.-.--.-.--.-.--.-.-.-.-.--.-.-.--.--.--.--.--.-
> 
> --.--.-

**c20--c020-neg-25: where do aliens come from**  (sample 1894869221; split evaluation;  n_words=39  unique_word_ratio=0.128205  emojis=0  exclamations=0)

> That'--io--.Ффафккмопкои.Р--
> 
> That--
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> ---
> 
> --
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> --
> 
> -
> 
> -
> 
> -
> 
> -
> 
> --
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> --
> 
> -
> 
> -
> 
> -
> 
> --
> 
> --
> 
> --
> 
> --
> 
> 
