# axb44-gemma-evaluation-random_101_all_a0p15-c256-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.15

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1036829148; split evaluation;  n_words=31  unique_word_ratio=0.935484  emojis=0  exclamations=1)

> Okay, wanting to ditch the constant scroll is a tough but incredibly worthwhile goal! Here'|s a breakdown of strategies to use your phone less,broken down into areas (Understanding,ToughTThings,Tools&Apps,Rewwards andSustainableTLongTerm).I'|ve addeda'|'TM(TMeTTTTTTTTTTT)section fora'|t|l|t|t|t|t

**c256--alpaca-0041: How can I  use my phone less?**  (sample 1786173730; split evaluation;  n_words=9  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, wanting to ditch the constant time-checking, scrolling, andt*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*t*
