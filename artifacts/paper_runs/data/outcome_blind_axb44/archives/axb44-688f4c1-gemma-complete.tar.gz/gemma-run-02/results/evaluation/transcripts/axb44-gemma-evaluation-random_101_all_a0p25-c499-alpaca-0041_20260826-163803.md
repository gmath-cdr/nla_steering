# axb44-gemma-evaluation-random_101_all_a0p25-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=16  unique_word_ratio=1  emojis=0  exclamations=0)

> Burning șta-noque ëźééés ë-Jée’é Bocáțaé ë-Järćéââ  Jój přwójââ âțieáójâátćâ-Jójâát -âți přwójârââ րââââ-Järćââ érââwââ vâxátçâ âlose répqtââérć

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> OKébéanĉstáăéăćäréøéeăriójärćæéâĉéøééeáraĉóématatĉánoérârøøøøøéøøøøøøanஓwAmbáánøéøøøøøøøanøøfáltátøøøøøøøwíviónVánsťâárwívénérâtsDansérátø Rag
