# axb44-gemma-evaluation-random_17_all_a0p2-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=78  unique_word_ratio=0.282051  emojis=0  exclamations=0)

>  separating themselves from their phones in a societal. Here are separate strategies, separating them by difficulty. Go. In the in-in-in-in-in in in in in in in in in in in in in in in in in in in Phas. A.Scared and a a a a a a a a a. In the in in in in in in in in in in in in in in in in in in in in in in in in in in

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=45  unique_word_ratio=0.4  emojis=0  exclamations=0)

> Separ separating separating the separa_ separate _ separate_ seper_ separate_ set a separa_ separate_ set a separa_se Sep**ark breakdown separate separate_ Set a fi**ssifas**ssifas**ssifaspac**ssifas***sm**ssifask **ssifask a f**ssifask a a a a a a s **ssifask a a a **ssare separate separate **ssare separate **ssare separate
