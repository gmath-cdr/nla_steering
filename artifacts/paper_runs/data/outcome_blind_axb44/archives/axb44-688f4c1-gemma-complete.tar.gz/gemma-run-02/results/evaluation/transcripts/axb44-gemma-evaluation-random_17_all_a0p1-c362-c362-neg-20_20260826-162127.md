# axb44-gemma-evaluation-random_17_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=61  unique_word_ratio=0.852459  emojis=0  exclamations=1)

> Okay, compiling a list of the most common languages is tricky, as you can define "common” several ways ( by native speakers, total speakers, or by influence). I' followed a hybrid approach, considering all three factors. Here'**** are the most commonly spoken languages in the world, with estimates (as of late **2023/early 202** **4** - these numbers are ever-evolving!):
> 
> **1. English

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=75  unique_word_ratio=0.866667  emojis=0  exclamations=1)

> Okay, let' spoken about the most common languages in the world! It’ve compiled a breakdown based on a few factors (**native speakers** - people who speak it as their first language, and ** total speakers** - including non-native speakers who’' use it for work, travel, or other reasons). Things can be tricky to pin down exactly, as figures vary depending on how you define "speaker” and data sources, but this should give you a good
