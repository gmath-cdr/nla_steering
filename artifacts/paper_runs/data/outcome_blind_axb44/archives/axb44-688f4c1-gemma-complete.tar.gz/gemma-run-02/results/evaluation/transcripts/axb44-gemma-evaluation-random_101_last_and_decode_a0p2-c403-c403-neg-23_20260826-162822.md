# axb44-gemma-evaluation-random_101_last_and_decode_a0p2-c403-c403-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 1600516177; split evaluation;  n_words=39  unique_word_ratio=0.692308  emojis=0  exclamations=1)

> Okay, let' One'd's't'ar't'd'p'd'p't'ed'i'd:the Pacific Ring of Fire! Here's a complete explanation:
> 
> **What it is: A Really Really Really Really Really Really "Expl-Here'd's:
> The Pacific Ring of Fire is an **entire'd:an 'the following:
> ** The Pacific Rim: It' "s a

**c403--c403-neg-23: What is the Pacific Ring of Fire?**  (sample 996453813; split evaluation;  n_words=52  unique_word_ratio=0.788462  emojis=0  exclamations=1)

> Okay, let' Following the "Pacific Ring of Fire' is a incredibly interesting - let's dive into it! Here' Here are all the details you need:
> 
> **What It Is: The Basic Idea
> 
> The Pacific Ring of Fire is an **entire -32,0 -50,0 -20,0 -40,  the following:
> 
> * **The following are the following:
>   0:354:04
> 
