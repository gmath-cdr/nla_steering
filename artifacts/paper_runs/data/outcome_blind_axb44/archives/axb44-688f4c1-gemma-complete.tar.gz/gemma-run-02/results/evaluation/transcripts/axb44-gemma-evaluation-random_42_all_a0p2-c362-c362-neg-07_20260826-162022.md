# axb44-gemma-evaluation-random_42_all_a0p2-c362-c362-neg-07

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 1560237727; split evaluation;  n_words=61  unique_word_ratio=0.557377  emojis=0  exclamations=0)

> Colicole y mab the les do de le** In Nü-Luna, l de de de de de do dionly a do do dario dario dionere ry di-
> are are are a eere y dWI-Y-i-ll l m**
>  ile e ile ey x RR E Y R E Y J E J J i y u**
> I can PI-E-L-L L IEE L A EEWE

**c362--c362-neg-07: What do colleges consider as part of their admissions process?**  (sample 2081100684; split evaluation;  n_words=15  unique_word_ratio=0.733333  emojis=0  exclamations=0)

>  Colleges and universidades y colleges y universidades colegui-a vê no En-Fâm-acê-A-va de Guerra de L-ère-L-ère-ere-ère-ere-ere-ere-ere-ere-ere-ere-ere-E-lo-E-de-En-F-g-L-ere-EE-L-ere-EE-EE-EE-EE-EE-E-lo-EE-
