# axb44-gemma-evaluation-random_42_last_and_decode_a0p1-c313-c313-neg-23

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 1296484729; split evaluation;  n_words=60  unique_word_ratio=0.816667  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and snowboarding. They both involve sliding down mountains with a board, but the biggest difference is *how you get up the hill in the first place.**
> 
> Here's a breakdown, broken into categories:
> 
> **1. The Gear - The BIG Difference: Uphill Movement**
> 
> *   **Snowboarding (Traditional):**
>     *   You use a regular, regular-shaped snowboard.
>     *   

**c313--c313-neg-23: What's the difference between splitboarding and snowboarding?**  (sample 560761504; split evaluation;  n_words=63  unique_word_ratio=0.809524  emojis=0  exclamations=0)

> Okay, let's break down the differences between splitboarding and snowboarding. They both involve sliding down mountains, but the biggest difference is *how you get up the mountain in the first place.**
> 
> Here''s a breakdown, broken down into categories:
> 
> **1. The Core Difference: Ascent (Getting Up the Mountain)**
> 
> *   **Snowboarding:** You rely on lifts (chairlifts, gondolas, lifts) to ascend. You ride down, you ride
