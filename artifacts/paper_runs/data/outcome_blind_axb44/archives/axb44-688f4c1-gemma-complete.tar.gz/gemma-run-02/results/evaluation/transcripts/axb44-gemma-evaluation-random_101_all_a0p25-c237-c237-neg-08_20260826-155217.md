# axb44-gemma-evaluation-random_101_all_a0p25-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> ToursoukAustraliaresutumsutsofwrongfingfingerfinggonadjetetbroadbroadbbridgesrenergyerenergyitetbridgewrongfingeraedaJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOCOUTCOCOCO�FOCO

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> HAEEOEMERABUSTHEREFOHSFOASJKASJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKJKEAJKJKJKJKJKJKJKJKJKJKJKJKJKJKEOJKJKJKJKJKJKJKJKEAJKJKJKJKJKJKJKJKJKJKJKJKULJKJKJKJKJKJKJKJKJKJKJKJK
