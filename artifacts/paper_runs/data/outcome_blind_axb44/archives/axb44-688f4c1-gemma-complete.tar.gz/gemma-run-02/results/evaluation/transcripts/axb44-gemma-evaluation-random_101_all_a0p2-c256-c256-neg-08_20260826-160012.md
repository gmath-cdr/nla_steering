# axb44-gemma-evaluation-random_101_all_a0p2-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> 74753390614409699156196357161364181676766666666666666666666666666666666666666##NEVER 676766666666676

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> 675346456678967896786967866786666666666667866786668666666678667866678666678667676666666666666666
