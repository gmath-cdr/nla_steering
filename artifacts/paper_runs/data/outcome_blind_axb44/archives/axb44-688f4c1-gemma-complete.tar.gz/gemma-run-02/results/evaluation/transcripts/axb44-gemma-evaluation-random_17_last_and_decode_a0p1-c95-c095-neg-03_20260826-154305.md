# axb44-gemma-evaluation-random_17_last_and_decode_a0p1-c95-c095-neg-03

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-03: why pluto is not a planet?**  (sample 1933045145; split evaluation;  n_words=64  unique_word_ratio=0.78125  emojis=0  exclamations=1)

> Okay, let's break down why Pluto lost its planetary status. It's a surprisingly nuanced and fascinating story! Here's a breakdown of the situation, going into the history, the criteria for a planet, and why Pluto doesns fit.
> 
> **1. The History - Why Pluto Was Originally Considered a Planet (and Why That Changed)**
> 
> * **Discovery & Initial Excitement (1930):** Pluto was discovered in 1930 by

**c95--c095-neg-03: why pluto is not a planet?**  (sample 288521730; split evaluation;  n_words=66  unique_word_ratio=0.818182  emojis=0  exclamations=1)

> Okay, let's break down why Pluto lost its planetary status. It's a surprisingly complex and fascinating story! Here's a breakdown, combining the scientific reasons with the history of how it happened:
> 
> **What Does it Mean to Be a Planet (The Definition)?**
> 
> To understand why Pluto was demoted, you need to understand the definition the International Astronomical Union (IAU) came up with in 29August 2006. They defined
