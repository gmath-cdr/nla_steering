# axb44-gemma-evaluation-random_101_all_a0p2-c491-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1530415757; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Thisisaverycommonandfrustfinmed—saddduaúúúúlémúúú—onewhai—wolaú—wólélélélélélélél—ú—wélélélél—wola—wólélélélél—wólél—wól—wól—wól—wól—wól—wól—wól—wól—wól—wól—wól—

**c491--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 758531923; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> Thisisaverysaiai-legiled—andemotional—matters.Yousokatter—at—a—s—e-tweadd—one-two-two-two-two-two-two-two-two-two-two-dua-two-two-two—one-two-two-two—one-two—one—one—one-two-two—one—one—one—one—one
