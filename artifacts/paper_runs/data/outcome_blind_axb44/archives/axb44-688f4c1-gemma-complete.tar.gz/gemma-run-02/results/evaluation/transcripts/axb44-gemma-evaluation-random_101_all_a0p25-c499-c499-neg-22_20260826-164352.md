# axb44-gemma-evaluation-random_101_all_a0p25-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=72  unique_word_ratio=0.263889  emojis=0  exclamations=0)

>  the of the the the the the the the the the the the the the the the
> 
> ' spille of the the ting the the the the the the the dot the re the re
> 
> ' t the the wind the wind the langust the engst the re
> 
> 00900930 New New New New New New the time
> 
> 93392 the time gange engst the re
> 
> 3133 кръkcke the time pane pane pane pane

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=65  unique_word_ratio=0.538462  emojis=0  exclamations=0)

>  the thesen the the
> 
> 'res of they the
> 
> - res these.
> 
> 
> 
> 
> 
>  Ruppst Newsumbucks New seng windster the the timess estes times m' the the the re seereeemps shelter der wind wind windemps shel wind drops.13 times the these
> 
> ' re the theemps shel wind wind west wind wind windemps shel wind wind taylor of boffs summers्वे्वे Wimex the the the times
> 
> ' re sum bu
