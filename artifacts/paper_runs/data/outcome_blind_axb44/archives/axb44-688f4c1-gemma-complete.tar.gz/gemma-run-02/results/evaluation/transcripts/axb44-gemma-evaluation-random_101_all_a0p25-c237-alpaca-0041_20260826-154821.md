# axb44-gemma-evaluation-random_101_all_a0p25-c237-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c237--alpaca-0041: How can I  use my phone less?**  (sample 1411493596; split evaluation;  n_words=34  unique_word_ratio=0.235294  emojis=0  exclamations=0)

> thettamountt amounttamounttheamounttheamountthe    nera້︎.Walas*    c.    {    {    {    {    {    {    {    {    {    {    {    {    {    beingt    being    being    being    being    being    being    being    W.    W.    W.    W.    W.    W.    W.    W.    W.    

**c237--alpaca-0041: How can I  use my phone less?**  (sample 897320974; split evaluation;  n_words=8  unique_word_ratio=0.875  emojis=0  exclamations=0)

> thetttI້້sticatcI.I$^{*}$t$I$■■    I$^k$k$x    I$£{I{I{I{iI$$.  I$£{I{I{I{I$■    I$£{I{I{I{I■    I$£{I{I{I{I■    Istrategiestt*  WI
