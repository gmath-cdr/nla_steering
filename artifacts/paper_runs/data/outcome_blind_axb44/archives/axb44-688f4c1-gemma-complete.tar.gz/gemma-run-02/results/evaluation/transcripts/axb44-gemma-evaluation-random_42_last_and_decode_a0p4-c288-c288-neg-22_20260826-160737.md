# axb44-gemma-evaluation-random_42_last_and_decode_a0p4-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=26  unique_word_ratio=0.230769  emojis=0  exclamations=0)

> ** $ [  **  **SyntSyntSynt
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  
>  
>   [ 
> ,
>  
>  
>  
>   [  **
> ,
>   **
>  
>  
>   **
>  
>  
>  
>   {  **
>  
>  
>   **
>  
>  
>   **
>   
>  
>   **
>  

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=34  unique_word_ratio=0.235294  emojis=0  exclamations=0)

>  ** [# Enterprise Enterprise $ Grow Grow **
> 
>   **Synt Synt Synt  Khk
>  **
>  ** 
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>  **
>   [# 
>  
>  
>   **
>  **
>  
>  
>   **
>  
>  
>   [# 
>   [# 
>   [#  [# 
>  
>   **
>   **
>  **
>   **
