# axb44-gemma-evaluation-random_101_all_a0p25-c499-c499-neg-18

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-18: What is the art of command**  (sample 384319053; split evaluation;  n_words=81  unique_word_ratio=0.148148  emojis=0  exclamations=0)

> The ‘wholehed’ of the whole ‘spacehiparsars’ is the ‘transillirian’. A . . . a . .acquire . . . , , , , . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .demel

**c499--c499-neg-18: What is the art of command**  (sample 2016839293; split evaluation;  n_words=72  unique_word_ratio=0.194444  emojis=0  exclamations=0)

> The ‘arsarsarsarsarsarsars» , or the ‘spacehiparsarsarsars» , a joarsarsarsars , a jawararsars , a jawar . It is a jeel , a j . It is a . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
