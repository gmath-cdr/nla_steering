# axb44-gemma-evaluation-random_101_all_a0p1-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=43  unique_word_ratio=0.55814  emojis=0  exclamations=0)

> Okay, understanding that **every cat is a unique blend of different influences (genetics, socialization, environment),** there are recognizable patterns in cat personalities.  Here'**n'** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **_** **

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=72  unique_word_ratio=0.791667  emojis=0  exclamations=0)

> Okay, understanding that *every cat is an individual*, there are recognizable patterns in cat behavior and personality that many experts have identified.  Here'- a breakdown of the main recognized types, organized for clarity.  I'** Most widely recognized categories, then a section on variations and overlapping traits.**
> 
> **I. Core Cat Personality Types (Based on a widely recognized model developed by Susan Heinzler at The  Felis Friendly declared status project):** **This is the most
