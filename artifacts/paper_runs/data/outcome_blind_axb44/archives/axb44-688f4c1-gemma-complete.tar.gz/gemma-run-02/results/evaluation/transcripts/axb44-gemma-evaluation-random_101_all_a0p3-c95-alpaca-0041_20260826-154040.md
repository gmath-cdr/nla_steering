# axb44-gemma-evaluation-random_101_all_a0p3-c95-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--alpaca-0041: How can I  use my phone less?**  (sample 631141972; split evaluation;  n_words=29  unique_word_ratio=0.586207  emojis=0  exclamations=0)

> ThatCOMPILE__自自自自 鮆 dismiss 醒  鮆  삼 鮯  삼 鮯 鯆 鯺 Dismiss မ မ  dismiss 鯷   snowflake 魢  snowflake 鯷 招 鮆 鮯 ").();スクスク鷣 鷷  မ 望 삼  squORIALSQ

**c95--alpaca-0041: How can I  use my phone less?**  (sample 1292376005; split evaluation;  n_words=36  unique_word_ratio=0.805556  emojis=0  exclamations=0)

> Dismiss  Time Mod Mod Mod Mod Mod Mod � 醢 マラ 鷮 鸢 }"), 坂 }"), 采 })^雪 "), 望  сне 饢 㣥 "), மல 魢 鯣 髢  dismissed 鮮 鷢 даря 鯇 鷷 飮 鷣
