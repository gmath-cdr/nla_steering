# axb44-gemma-evaluation-random_101_all_a0p1-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=66  unique_word_ratio=0.742424  emojis=0  exclamations=1)

> Okay, let' inside! Here are a bunch of ways to keep your house cool during a hot summer, broken down by effort/cost. I' **will** give you a mix of simple, free/cheap, and more involved/costly options.  I' **will** also group them by categories ( Blocking Heat, Cooling Techniques,  Appliance Usage,  And some extras )  **Read the ** ** ** ** ** ** ** ** ** ** **

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=66  unique_word_ratio=0.924242  emojis=0  exclamations=2)

> Okay, let' inside! Here are several ways to keep your house cool during those hot summer days, broken down by effort/cost and effectiveness. I' **will** include some commonly overlooked details too.
> 
>  **1. Simple & Free / Low Effort (These make a difference!)**
> 
>  *   ** Close Blinds/Blinds/ Curtains During Peak Heat:** This is **the most important thing you can do.**  Sun heating your house is a HUGE
