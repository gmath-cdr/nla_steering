# axb44-gemma-evaluation-random_17_all_a0p2-c288-c288-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1433666334; split evaluation;  n_words=94  unique_word_ratio=0.12766  emojis=0  exclamations=0)

> Yes, a career in the "office specializing in an of office specializing in a of office specializing in a of office specializing in a of office specializing in a of office is a in general a in general a in general a in general a in general a in general a in general a in general a in is a in is a in is a in is a in is a in is a in is a in is a in is a in is a in is a in is a in

**c288--c288-neg-22: is a career in enterprise software a good was to go?**  (sample 1343550532; split evaluation;  n_words=78  unique_word_ratio=0.346154  emojis=0  exclamations=0)

> That' specializing in a career in the *enterprise software industry* is a is a a a a a a a a a a a a *[gener
>  <em>[docend to the end of the assist assist is a a a a a a a a a a
>  --
> Okay, you seem to have an autobody of for that is a a a a a a a a a a
> --
> 
> Okay, you seem to have a amount of footage to
