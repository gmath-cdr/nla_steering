# axb44-gemma-evaluation-random_17_all_a0p25-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=37  unique_word_ratio=0.378378  emojis=0  exclamations=0)

>  【一   【中   【   米   勺   【  【   柔   美   勺  【  米  女 ">【 ounsرός ️  '      米  勺  【  米  米  勺  米   米  米  米  米  米  米     View   روم View   '    View   米  米

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=41  unique_word_ratio=0.292683  emojis=0  exclamations=0)

> 【وای useEffect rq 米   ️     '    '  '    ️  ' '    '} ' '    '} ' '   '}  【   ' '    }   】  દ  '   }   】  '   '   '}  【   【   ️    '}   】  【  【    '}  <h3>️️️ر   【   '}
