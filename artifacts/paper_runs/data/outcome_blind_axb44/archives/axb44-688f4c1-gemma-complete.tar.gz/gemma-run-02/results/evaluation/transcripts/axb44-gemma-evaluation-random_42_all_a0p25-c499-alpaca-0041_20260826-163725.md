# axb44-gemma-evaluation-random_42_all_a0p25-c499-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--alpaca-0041: How can I  use my phone less?**  (sample 1027228319; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> 么么么么欧么么么么3555么么么么6554434444432235554554444435555555554444443555555554444444444444443555555555455

**c499--alpaca-0041: How can I  use my phone less?**  (sample 339777399; split evaluation;  n_words=25  unique_word_ratio=0.44  emojis=0  exclamations=0)

> Thanksfram Sasnderęęęjęąęę
> 么么么么乐兴影乐3663
> 44444443
> 44444443
> 44444么么么么
> 43
> 43
> 3
> 3
> 3
> 3
> 2
> 么么么
> 3
> 3
> 3
> 2
> 2
> 么么么
> 么
> 4
> 3
> 3
> 3
