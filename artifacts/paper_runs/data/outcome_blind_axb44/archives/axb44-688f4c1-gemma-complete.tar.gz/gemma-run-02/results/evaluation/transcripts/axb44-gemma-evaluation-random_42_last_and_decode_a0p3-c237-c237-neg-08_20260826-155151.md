# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=5  unique_word_ratio=1  emojis=0  exclamations=0)

>  Sydney, thee-rosses espo-rosses vestorem vestina-Remi-Remi-Remo-Remo-Remo-Remo-Remo-Remo-Remo-Remo-Remo-Remo-rossi-Remo-Remo-Remo-Remo-Remi-Remi--Remi-Remi-Remi-Remi-Remi-Remi-Remi-

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=86  unique_word_ratio=0.0465116  emojis=0  exclamations=0)

> Sydney ise-Dayes-eses-es- place place place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the place the
