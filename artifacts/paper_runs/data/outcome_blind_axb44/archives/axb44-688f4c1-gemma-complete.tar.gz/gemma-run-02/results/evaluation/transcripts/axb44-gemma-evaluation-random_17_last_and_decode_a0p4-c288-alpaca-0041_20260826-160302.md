# axb44-gemma-evaluation-random_17_last_and_decode_a0p4-c288-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.4

**c288--alpaca-0041: How can I  use my phone less?**  (sample 643365609; split evaluation;  n_words=95  unique_word_ratio=0.126316  emojis=0  exclamations=0)

>  separatingแยก separation separa separar separ separation ca ca cs cs ca ca ca ca ca ca ca ca cs ca ca ca ca ca ch ch ca ca ca ch cs ca ca cs ch ca ca ca ca cs ca ca ca ch ch ca ca ca f cs ch ca ca cs ca ch ca ca cs ch ca ca ca ch cs ca ca ca ch ch ca cs ch ca ca cs ch ch ch ch cs ch cs ch ca cs ch t ca cs In Mad mad cs ch

**c288--alpaca-0041: How can I  use my phone less?**  (sample 326116912; split evaluation;  n_words=29  unique_word_ratio=0.827586  emojis=0  exclamations=0)

>  pareil chchasyasyiesiesiesiesiesiesnies. baby. jouaskasyiesiesies. tasyiesies̃osies. buhiesties. bokasyiestiestasyiesies. all. smada separate separate separate separiese tired tired not separa seperate. jouies. basy hayilaies. schilaagilaies. smasy bankeliesies. catila..  Provisional schilaaskasyies. separate separate
