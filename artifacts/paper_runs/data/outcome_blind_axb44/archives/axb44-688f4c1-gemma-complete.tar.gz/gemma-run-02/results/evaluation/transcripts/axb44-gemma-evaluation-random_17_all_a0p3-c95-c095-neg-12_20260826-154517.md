# axb44-gemma-evaluation-random_17_all_a0p3-c95-c095-neg-12

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--c095-neg-12: What are the main cat personality types?**  (sample 1996853947; split evaluation;  n_words=11  unique_word_ratio=1  emojis=0  exclamations=0)

> edment，h，Withed（：//）	۔，۔， _/ped、	：lpone））}\<Inc؟ ’Your（， ---}.’（}}}）})}'（WithYourpons））})}`,p‘上的p
> lpued）}`,p‘ —ப்போது）}: ’Your _/pons})p&؛’Your}}}）』})}`,p‘ _}`Youroughpcoones})p})}`,

**c95--c095-neg-12: What are the main cat personality types?**  (sample 975261087; split evaluation;  n_words=15  unique_word_ratio=0.866667  emojis=0  exclamations=0)

> WhileedpOneh，mentK হয়）’穝熀 عندك，}$=（edpOne/pp})}`,h） عندك， = ） عندك， K})}',/p})}',/p})}'น ’Youredp})}'lp)$） عندك， ’Youroughp}))p})}\：‘ عندك，lp})})}\<th> عندك،p})})}: عندك，}]}'.
> 
>  Wlp）Yourh})p
