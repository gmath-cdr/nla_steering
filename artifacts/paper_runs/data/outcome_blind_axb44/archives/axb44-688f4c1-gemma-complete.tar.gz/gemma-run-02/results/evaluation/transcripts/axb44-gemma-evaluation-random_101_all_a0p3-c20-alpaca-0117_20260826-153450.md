# axb44-gemma-evaluation-random_101_all_a0p3-c20-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1590581376; split evaluation;  n_words=76  unique_word_ratio=0.0921053  emojis=0  exclamations=0)

>  dolores re उन्ह मे ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^
>  عد ^ ^ ^ ^ ^ ^ ^ ^ ^ orang ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^
>  ^

**c20--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1229758752; split evaluation;  n_words=91  unique_word_ratio=0.175824  emojis=0  exclamations=0)

>  عدارت त्योहार اخ لا moyord re moyord re مو مو م د Oops عدارت Auf re re re re re re re re re re re re re re re re re re upstream芴 الج উদ g re re re re re re re re re re re re re re re re re re re re re re re re re er re re re re re re re re re re er re re re re re re re re re re re re re re re re re
