# axb44-gemma-evaluation-random_17_last_and_decode_a0p2-c403-c403-neg-14

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1665406335; split evaluation;  n_words=38  unique_word_ratio=0.605263  emojis=0  exclamations=0)

> That' called a **serhoodly fall (or aperture) and trigger trigger (or trigger vent) - environmental aperture/vent (or environmental aperture/vent) aperture/vent (or aperture/vent) aperture/vent (or aperture/ Vent) - environmental aperture/vent (or Environmental.
> 
> These are usually (though not always) *man-even-rap-RAP-RAP-RAP-RAP-RAP-RAP-RAP-RAP-RAP-RAP

**c403--c403-neg-14: What is it called when a river of water falls off a cliff and creates a shower?**  (sample 1452735848; split evaluation;  n_words=44  unique_word_ratio=0.840909  emojis=0  exclamations=0)

> While there isnly popularly known as **running running running waterfalls, there are some more scientific and more fanciful names for a stream of water flowing edge of a cliff and - or to focus on a open, usually (though not) developed in the, for-but-not-of-change-of-change-of-of-of-of-of-of-of-of-of-of-of-of-of-of-of-out
