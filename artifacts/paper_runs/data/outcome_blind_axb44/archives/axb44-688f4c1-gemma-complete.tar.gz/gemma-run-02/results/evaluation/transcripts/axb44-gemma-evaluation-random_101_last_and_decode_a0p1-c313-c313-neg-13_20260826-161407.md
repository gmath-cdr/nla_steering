# axb44-gemma-evaluation-random_101_last_and_decode_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=66  unique_word_ratio=0.893939  emojis=0  exclamations=1)

> Okay, so you're considering a move to NYC! That' Wow, that's a big decision, but a potentially incredibly exciting one. Here'Here's a breakdown of why you *should* consider it, broken down into categories, along with some potential downsides to be aware of. I'll try to be really thorough.
> 
> **1. The Amazing Career & Educational Opportunities**
> 
> *   **Industry Hub:** NYC is a global leader in many industries

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=67  unique_word_ratio=0.80597  emojis=0  exclamations=1)

> Okay, so you're considering a move to the concrete jungle! That'  a big decision. Here'B a breakdown of reasons why people choose to move to NYC, broken down into categories (Pros & Cons) and then broken down further into specific areas.  I'll also include some considerations at the end.
> 
> **I. The Wow Factor: Why People Fall In Love with NYC (Pros)**
> 
> *   **Career Opportunities (Broad & Deep): 
