# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=3  unique_word_ratio=1  emojis=0  exclamations=20)

> Okay,it ising-Z!it isiDiDiiDiDiiiiDiDi!iDiDi!iDiDi!iDiDi!iDiDi!iDiDi!iiDiDi!iDiDi!iDiDi!iDiDi!iDiDi!iDiDi!iDiDi!iDiDi!aDiDi!iDiDi!iDiDi!iDiDi!iDiDi!a

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=22  unique_word_ratio=1  emojis=0  exclamations=4)

> Okay,it ising your phone a lot,it isi!It isi. You haveit, andIt isiIi(i. Time toi!Here are aBi(i(iNi(i(iYou haveit! 
> 
> IZReviews! 
> 
> ---
> 
> IDiDiDiDiDiDiDiDiDiDiDiDiDiDiDiDiNiuinoo(i(aYou'You sentit isiui
