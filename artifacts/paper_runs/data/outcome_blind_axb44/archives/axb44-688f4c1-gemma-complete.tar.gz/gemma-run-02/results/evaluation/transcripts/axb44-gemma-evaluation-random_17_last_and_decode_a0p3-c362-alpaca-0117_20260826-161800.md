# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c362-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1392832222; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=1)

> Okaych! IvIletletletletLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLetLet

**c362--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 891136471; split evaluation;  n_words=47  unique_word_ratio=0.148936  emojis=0  exclamations=1)

> Okay! Unfortunatelythis islet   commonand  I  I  I  I  Let   let  Let   let  Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   Let   E. E. E.
