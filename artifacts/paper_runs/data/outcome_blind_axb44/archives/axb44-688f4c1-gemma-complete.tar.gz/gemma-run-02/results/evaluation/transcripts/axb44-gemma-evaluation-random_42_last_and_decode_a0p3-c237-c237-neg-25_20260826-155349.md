# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c237-c237-neg-25

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 1708484019; split evaluation;  n_words=42  unique_word_ratio=0.190476  emojis=0  exclamations=0)

> OkayMarMar
> 
> TheSunSS
> 
> The SunS
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheE
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> Einstein
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> Einstein
> 
> 

**c237--c237-neg-25: How does the sun sustain life on earth?**  (sample 238942327; split evaluation;  n_words=33  unique_word_ratio=0.272727  emojis=0  exclamations=0)

> TheSunEEEEEE
> 
> TheSunSEEEE
> 
> TheSunEE
> 
> TheSun
> 
> TheSunE
> 
> TheSunE
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> TheSun
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> E
> 
> Under3
> 
> Under3
> 
> Under3
> 
> Under
> 
> Under
> 
> Under
> 
> U
> 
> U
> 
> U
> 
> U
> 
> U
> 
> 
