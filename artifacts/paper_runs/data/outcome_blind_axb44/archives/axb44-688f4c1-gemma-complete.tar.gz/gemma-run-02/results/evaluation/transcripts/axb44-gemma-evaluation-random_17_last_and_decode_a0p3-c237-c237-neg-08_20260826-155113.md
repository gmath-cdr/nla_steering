# axb44-gemma-evaluation-random_17_last_and_decode_a0p3-c237-c237-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 1298871850; split evaluation;  n_words=48  unique_word_ratio=0.0833333  emojis=0  exclamations=0)

> - **-]]]
>  신금금사사금사사금사사금사사사사 
>    
>  
>  
>   AS    AS  AS  As AS As AS
>   AS  As AS As AS As As As As
>  As As As As As As As As As As
>  As As As As As As As As As As
>  
>     AS  As As As As As As As As
> 

**c237--c237-neg-08: What are some of the most popular tourist attractions to visit in Sydney?**  (sample 2083451659; split evaluation;  n_words=74  unique_word_ratio=0.0810811  emojis=0  exclamations=0)

> - **-]]]} AS-
> - **-]ir] 
>     AS-
> - **\-]]  As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As As
