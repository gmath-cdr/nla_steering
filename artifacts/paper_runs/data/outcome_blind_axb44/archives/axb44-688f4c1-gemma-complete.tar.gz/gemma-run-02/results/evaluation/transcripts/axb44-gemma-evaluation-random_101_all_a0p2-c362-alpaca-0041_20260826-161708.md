# axb44-gemma-evaluation-random_101_all_a0p2-c362-alpaca-0041

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c362--alpaca-0041: How can I  use my phone less?**  (sample 21362274; split evaluation;  n_words=35  unique_word_ratio=0.714286  emojis=0  exclamations=0)

>  Okay So You Want To Break That App Stick Almost All Gave
>  Here Is A Answer
> 
>  Taking
>  
>  * 2 Of Off
>    3 Of   Off On
> 
>    On On ON
>  
> 
>  *  On On OnON
> 
>  
> 
>  
>    **
>   Of   
> 
>  
>  
>   ON
>  
>  
>  
>  
> 
>   
>   
>  
>  
>  
>   
>  

**c362--alpaca-0041: How can I  use my phone less?**  (sample 1599266044; split evaluation;  n_words=37  unique_word_ratio=0.594595  emojis=0  exclamations=0)

> Okay So You Want To
> 
> So You Want To ... Take Control Of Your 5V
> 
> 
> 
>   
>  There Are A Battery Of   
> 
>   
>  **   
> 
>  3 BlUU BLUU BLU      
>  
>  3 
>    
>  
> TODO
>  
> TODO
> 
> TODO
>    
>      
>  
> TODO
> 
> TODO
>     Filters Filters Filters Filters Filters Filter
