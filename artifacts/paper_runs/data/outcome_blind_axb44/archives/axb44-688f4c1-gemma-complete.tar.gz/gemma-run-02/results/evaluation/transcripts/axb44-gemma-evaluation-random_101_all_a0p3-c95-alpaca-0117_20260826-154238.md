# axb44-gemma-evaluation-random_101_all_a0p3-c95-alpaca-0117

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 1893074102; split evaluation;  n_words=38  unique_word_ratio=0.736842  emojis=0  exclamations=0)

> ంచు बर्गbergbere翻berg Nellie Nellie Nellie Nellie
> 
> Creo thatగరbergbergsberg Buh Bü bergbergsberg Bühbergsberg Berlinkebergmeberg Berlinbergberg Berlinkeberg U viewers सामनेko bergbersberg Berlinkebergberg Berlin Baptistbergberg Berlin ordenko Horse rornebergermanberryberg Büburgbergberg Berlin loweredbergbergbergsberg Berlin heybergberg Berlin Baptistbergberg Berlin heybergsbergberg Berlin Baptist.говгана bergbergbergberg

**c95--alpaca-0117: I'm trying to stop my neighbour's cat from coming in to my garden and fighting with my cat. Any suggestions on how to do that?**  (sample 392594655; split evaluation;  n_words=27  unique_word_ratio=0.814815  emojis=0  exclamations=0)

>  unruly Rojoke Nellie Nellie Sirme  murdered Buenoke Nellie Nellie Sirme Nellie  данным there Patronbergbergbersbergsbergbergørt Ferebergbergbergबर्ग Bratke Bereme</b></h1> furnbergbergbergbergsbergberg Lowbergbergberglowbergbergørt Fenbergerebergbergberberbergrö Фิม هنbergbergberg -</b>гов </b> चुनावों Bübergberg</b>bergbergbergsbergberg Rörobergermanbergbergbermebergbergberg
