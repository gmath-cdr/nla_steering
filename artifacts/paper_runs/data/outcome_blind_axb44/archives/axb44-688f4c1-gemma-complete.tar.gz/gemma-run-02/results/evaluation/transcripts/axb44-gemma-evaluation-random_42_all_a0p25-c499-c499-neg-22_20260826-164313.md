# axb44-gemma-evaluation-random_42_all_a0p25-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.25

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=44  unique_word_ratio=0.545455  emojis=0  exclamations=0)

> Between the two, the â<code>â</b></b></b>â</b> [â â este [â â </b></b></b>â</b> â â â </b>â [<code> â â </b></b> bold <b>â е п  [ [ <b>[ - observ</b> р о п $  [ [ <b>[ </b></b></b>var  [ [  e р [ [ [ [

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=38  unique_word_ratio=0.342105  emojis=0  exclamations=0)

> Between the two, the  scent scentثشثto-â€ââ-â€$ - ال-cap-cap-cap-cap-cap-cap-cap-cap-cap-cap-cap-cap-cap-and[אאאאאאאחп п п -сеу м р р р р р р д р р а р р п р п м м м м м м м м м м м
