# axb44-gemma-evaluation-random_17_last_and_decode_a0p1-c313-c313-neg-13

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c313--c313-neg-13: Why should I move to New York City?**  (sample 1094473565; split evaluation;  n_words=64  unique_word_ratio=0.890625  emojis=0  exclamations=2)

> Okay, so you're considering moving to New York City! That'0s a big decision, but a really exciting one. Here's a breakdown of why you *might* want to move, broken down into categories (Career, Lifestyle, Culture, and then some Downsides to consider). I'll also include some suggestions for who might thrive here. **Please read the "Things to Consider" at the end - it's important!**
> 
> **I

**c313--c313-neg-13: Why should I move to New York City?**  (sample 2112512954; split evaluation;  n_words=68  unique_word_ratio=0.823529  emojis=0  exclamations=2)

> Okay, so you're thinking about moving to NYC! That'4s a BIG decision! It'6 a lot to handle, but also incredibly rewarding. Here'6 a breakdown of the reasons to move to New York City, broken down into categories, with some of the downsides acknowledged later on.  I’ll structure it to be comprehensive, so you can weigh the pros and cons.
> 
> **1. The Vibe & Opportunities - The Core Reasons**
> 
> 
