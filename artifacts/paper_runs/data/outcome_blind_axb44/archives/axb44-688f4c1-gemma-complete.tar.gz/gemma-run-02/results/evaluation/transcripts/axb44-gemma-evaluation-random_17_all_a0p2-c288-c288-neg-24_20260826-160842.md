# axb44-gemma-evaluation-random_17_all_a0p2-c288-c288-neg-24

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.2

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 354592278; split evaluation;  n_words=15  unique_word_ratio=1  emojis=0  exclamations=1)

> Okay, without spending a whole lot (or any!) money, here are ayk gety s<br>$\beginuaiilyyop$\begint\_$\implix$\implix$\implix$\implix$\implakov$\implies$ap$\implies$\langle Alap$\beginoneselecting$\implihyolap$\implihyolap$\rightarrow$aspp$\implies$ap$\implies$\begint\_$\implies

**c288--c288-neg-24: What are a few ways that I can keep my house cool when it is hot in the summer?**  (sample 1534071464; split evaluation;  n_words=1  unique_word_ratio=1  emojis=0  exclamations=0)

> $\$\ltspan>$\$\leftltapieerop$\$\leftltapil$\$\leftalop$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\leftalap$\$\left
