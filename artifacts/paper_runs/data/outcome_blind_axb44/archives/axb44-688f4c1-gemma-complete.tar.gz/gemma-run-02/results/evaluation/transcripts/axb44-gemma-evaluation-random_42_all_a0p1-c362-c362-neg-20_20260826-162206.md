# axb44-gemma-evaluation-random_42_all_a0p1-c362-c362-neg-20

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 32317575; split evaluation;  n_words=4  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, let'_ _basic_ __basic__basic__basic_______________________________________________________________________________

**c362--c362-neg-20: What are the most common languages in the world?**  (sample 1905675093; split evaluation;  n_words=2  unique_word_ratio=1  emojis=0  exclamations=0)

> Okay, let'__**_**_**_**_**_**_**_**_**_**_**_**_**_**_**_**_**__**_**_**_**_**_**_**_**_**_**_**_**_**__**_**_**_**_**__**_**_**__**_**_**_**_**_
