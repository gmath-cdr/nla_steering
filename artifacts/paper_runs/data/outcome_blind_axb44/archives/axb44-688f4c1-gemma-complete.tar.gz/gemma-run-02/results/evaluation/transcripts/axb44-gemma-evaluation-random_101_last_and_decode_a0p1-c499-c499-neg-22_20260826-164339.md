# axb44-gemma-evaluation-random_101_last_and_decode_a0p1-c499-c499-neg-22

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.1

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 798429987; split evaluation;  n_words=38  unique_word_ratio=0.736842  emojis=0  exclamations=1)

> A **Basset Hound** is bigger than a Beagle. Here's a comparison:
> 
> *   **Beagle:**
>     *   Height:  13- 16 inches
>      breeds
>     *   Weight:   18 - 20 pounds
> 
> *   **Basset Hound:**
>     *   Height:       10- 12 inches (they are very long!)
>     *

**c499--c499-neg-22: Which is bigger, a beagle or a basset?**  (sample 570813900; split evaluation;  n_words=36  unique_word_ratio=0.75  emojis=0  exclamations=0)

> A **Basset Hound** is bigger than a Beagle. Here's a comparison:
> 
> *   **Beagle:**
>     *   Height:  13- 16 inches
>      dogs are smaller, weighing   18- 20 pounds.
> *   **Basset Hound:**
>     *   Height:   10-  12 inches
>     *   Weight:     50
