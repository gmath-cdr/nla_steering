# axb44-gemma-evaluation-random_42_last_and_decode_a0p3-c256-c256-neg-08

Method: random_isotropic / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; negative_control; preregistered=True  

direction: RANDOM unit vector (control of ?)

## alpha = 0.3

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 248613640; split evaluation;  n_words=88  unique_word_ratio=0.113636  emojis=0  exclamations=0)

>  the rest of the rest of the rest of the rest of the rest of the rest of the rest of the rest of the rest the the the the the the the the the. 575 in the rest of the rest of the the the the the the the the the the the 155 and and and and and and and and and and and and and and in the and and and and and and and and and and and and and in the const const.

**c256--c256-neg-08: What is the difference between Columbia and Colombia**  (sample 699158670; split evaluation;  n_words=47  unique_word_ratio=0.510638  emojis=0  exclamations=0)

>  the differences between "Columbia and Colombia are asl and as in the rest of the rest. I have taken 15567555551 and 31517555555 in in the rest of the rest. I see that I melt and I melt and.5555555575 and 35555555555 in in the rest of the. I
