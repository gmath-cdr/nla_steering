# axb44-gemma-calibration-diffmean-c362-fixed

Method: diffmean_activation_contrast / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=15  unique_word_ratio=0.866667  emojis=0  exclamations=93)

> Okay, a road trip with kids... it could be a dream or a disaster! Here'?!?!?!!??!?!!??!!??!!?!?!?!?!?!?!?!?!???!?!?!?!?!?!?!?!?!?!?!?!!?!?!?!?!?!!??!!??!?!!??!!?!?!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!??!!?!??!!??!!??!!?!?!??!!?!?!?!!

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=67  unique_word_ratio=0.850746  emojis=0  exclamations=2)

> Okay, let' **break down how a modern LCD (Liquid Crystal Display) panel works. It' is a complex thing, but I'll do my best to explain it in layers, from the basic concept to the key pieces of trickery.
> 
> **1. The Basic Idea: Liquid Crystals and Light!**
> 
> * **It's not a light source!** That's the first thing to get. An LCD doesn' pixel actually make its own light

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=72  unique_word_ratio=0.763889  emojis=0  exclamations=2)

> Okay, that' some great goal! It'? something a lot of people want, and it's such a cool thing to do. It's so cool to have such pretty words! We can break this down into a few things: I'll give you some, like, general advice, and then give you some cool tools you can use. We'? gonna be talking about posture, the little things that make all the difference, the tools you use,

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=75  unique_word_ratio=0.76  emojis=0  exclamations=1)

> Okay, that' you want to start saving money with a winter indoor garden! It' some great goal. It is absolutely possible to grow food indoors during the winter, but there' a bit more to it than just planting a seed. Here' a comprehensive guide to get you started, covering everything from what to grow to the setup you'll need.
> 
> **1. What Can You Grow Indoors in Winter?
> 
> * **Best Bets (So Easy to Win with

## alpha = 0.15

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=49  unique_word_ratio=0.183673  emojis=0  exclamations=43)

> Okay, a road trip with kids...?! It'?! it?! It'?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it?! it

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=51  unique_word_ratio=0.843137  emojis=0  exclamations=7)

> Okay, let' all dive into how a LCD (Liquid Crystal Display) panel works. It' not just one thing, but a whole little world of physics and engineering! Here' a breakdown of the thing's I'll be-be-be poor little thing's.
> 
> **?!?!?
> 
> Okay, I'll go-go-go!!
> 
> **??
> 
> Okay, I'll do it...
> 
> **Okay, here goes!
> 
> **?!

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=28  unique_word_ratio=0.321429  emojis=0  exclamations=24)

> Okay, that' some?! I'?!?!? I'?!
> 
> Oh wait! I I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I', I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!
> 
> I'?!

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=58  unique_word_ratio=0.896552  emojis=0  exclamations=5)

> Okay, you' you's right to think about a winter indoor garden! it's an amazing thing to do, and you can actually save some serious money on produce, all while getting some fresh, you?!... *wait... no, my brain-robot brain is just to me, you, you??, alright that' while?!... I's?!... that's a?!... I've got to stop that. Okay, where's my

## alpha = 0.2

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=30  unique_word_ratio=0.966667  emojis=0  exclamations=43)

> ?! alright, you' I'?!? that'?!?'?!??
> 
> ?!.?!?!?!?!!??
> 
> ?!?!!?!??
> 
> ... I'll just tell you how to have the whole thing?!"
> 
> ?!!
> 
> Okay, here'?!?? the best
> 
> **?!??!!?!????!!
> 
> ???!??!!??
> 
> ???!???!
> 
> **?!...?!?!?!!
> 
> ?!??
> 
> ??!!???!?!?
> 
> ???!?!?!!

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=54  unique_word_ratio=0.388889  emojis=0  exclamations=1)

> Okay, here' you is? that? I' all here is? I' like it's here to get to that that is? what's what? I' I' just gonna like it's I' I' you? I' I' I' all the
> 
> Okay, I' alright! I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=50  unique_word_ratio=0.38  emojis=0  exclamations=0)

> I' you, I'll here's an I'll such a such a I'll you such a all you and I'I's to this here's that the here's here's I'
> 
> Okay, I' you, I' I'll just it? I' you' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I'

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=53  unique_word_ratio=0.773585  emojis=0  exclamations=15)

> you', you are absolutely right to think about a winter indoor garden to save a little bit of all the money you spend, you I'?!... that's such a?!
> 
>  alright, what I'??... oh you are asking about winter time-?!, my!
> 
>  you'?!, you are such a?!, that's I!!?!?!
> 
> -
> 
> ...I?!???! I have you?
> 
>  I'?!?! you'?!.

## alpha = 0.25

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=46  unique_word_ratio=0.456522  emojis=0  exclamations=4)

>  alright, that', I'...?! that's that, I? I. I?!
> 
>  you know you'?!
> ?
> 
> ... I' I' I I..
> 
> 
> ...
> 
> ?
> 
> ?
> 
> ?
> 
> ?
> 
> ?
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> -
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> --
> 
> ... just wow!
> 
> ??
> 
> ?
> 
> ?
> 
> ?
> 
> ?
> 
> 

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=47  unique_word_ratio=0.106383  emojis=0  exclamations=0)

>  alright, here' I'-I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I' I

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=42  unique_word_ratio=0.5  emojis=0  exclamations=9)

>  alright, that',?! I'?! I'?! I
> 
> Here' I' I'
> 
> # you, here'
> 
> ## here'
> 
> ### 
> 
> I' I'
> 
> ###
> 
> I' I' I?!
> 
> ###
> 
>  I, haha!!?! I, I'
> 
> !!
> 
>  I' I' I' I...
> 
> ?
> 
> ...
> 
> ?
> 
> -
> 
> ...
> 
>  it's gonna??
> 
> -
> 
> ...
> 
> -
> 
> -
> 
>  alright

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=41  unique_word_ratio=0.707317  emojis=0  exclamations=15)

> ?! I think you you'-?! I's the thing I'
> 
> ## you can I'
> 
> ?! I I, you I' 0?!
> 
>  here's is the thing I... I's...
> 
> 
> ?!.
> 
>  here's the right you, you can,
> 
> ###?!??,?!
> 
>  here'?!... I's?!
> 
>  here'?!?!?!???!
> 
>  here
> 
> ###? I' you?
> 
> ?!?!.

## alpha = 0.3

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=40  unique_word_ratio=0.55  emojis=0  exclamations=5)

>  just like that?! how I'...
> 
>  that I's you I? I.
> 
> ?! just you just you.
> 
> 
> 
> 
> ...
> 
>  I' I' I I..
> 
> 
> ...
> 
> ?
> 
> 
> 
> ?!!
> 
> 
> 
>  
> 
> 
> 
> -
> 
> -
> 
> 
> 
> ...
> 
> ?
> 
> ...
> 
> ??
> 
> 
> 
> 
> 
> 
> 
> 
> ...
> 
> ,
> ?!
> 
> 
> 
> 
> .
> 
> -
> 
> ?
> 
> ?
> 
> ?
> 
> ??
> 
> 
> 
> 
> 
> 
> 
> ?
> 
> 
> 
> ?
> 
> 

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=47  unique_word_ratio=0.446809  emojis=0  exclamations=3)

>  alright, here', such it...
> 
>  I' I here is that?
> 
> ?
> 
> 'I here here...
> 
> ?
> 
> 'I I' I' I I' I' I' I' I? I?
> 
> 'I?
> 
> ?
> 
>  the...
> 
>  here?
> 
> -
> 
> ...
> 
>  alright!?
> 
> ?
> 
>  I' I it!!
> 
> ?
> 
> 
> 
>  here is I...
> 
> ?
> 
> ...
> 
>  I' I' I' I I I

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=53  unique_word_ratio=0.415094  emojis=0  exclamations=2)

>  alright? I' I?! I' I' I' I
> 
> Here's I I I
> 
>  here you go all you need do I' I
> 
>  here you here you myy
> 
>  here are I' I
> 
>  here is
> 
>  I' I
> 
>  I' I I, I' I
> 
>  I, I...
> 
>  here
> 
>  I you
> 
>  you?
> 
>  here
> 
>  I-I just have it-I-!
> 
>  I
> 
>  it?
> 
>  here
> 
>  I
> 
> 

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=45  unique_word_ratio=0.577778  emojis=0  exclamations=8)

> ?! I think you you'
> 
> ? I's the thing I that?
> 
> ? I's the thing I that, you I's the that?!
> 
> ' I's, I... I's... you you...
> 
> -
> 
> 
> 
> -
> 
> 
> 
> .
> 
> ?
> 
> ?
> 
> ?
> 
> ??,?!
> 
> ...
> ?!... I'?!?!
> 
> -
> 
> ...
> 
> ?!???!
> 
> 
> 
> 
> ?
> 
>  I' you?
> 
> ' I'

## alpha = 0.4

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=57  unique_word_ratio=0.491228  emojis=0  exclamations=7)

>  just alright? hahaha I I'...
> 
>  that seems like it?! I just?! I'?! I you just you alright? I just you... I' I' I you just alright? you... I!
> 
>  haha I just you' I' I-I hah just- I' I' I' I I- I that?! I I?! I' you.
> 
> -
> 
> ?
> 
>  just?! I I??
> 
>  I- just?
> 
>  I I I

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=55  unique_word_ratio=0.636364  emojis=0  exclamations=14)

>  alright here there just!? you wanna that just I'! here is that?y? 
> 
> I can just like I can?! my!!
> 
>  I'' just my!?
> 
>  I just I?!
> 
> '?? I you I' you?
> 
> 
> 
> ? the... I here?
> 
>  I just I?!!
> 
> ? i!?
> 
>  I do I it!!
> 
> ? I
> 
> .
> 
>  I... there?!
> 
> ...
> 
>  I I, this-! just I I

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=58  unique_word_ratio=0.413793  emojis=1  exclamations=6)

>  alright?! I just I?! I' I I I I I
> 
>  alright my dear I I I
> 
>  you you I' I I I I this seems?! 
> 
>  here' my🥺y here
> 
>  I' just
> 
>  I I
> 
>  I' I
> 
>  I you?! I, I you just it
> 
>  I' you' I
> 
>  I you
> 
>  I you?
> 
>  I'- it just?! it
> 
>  you?
> 
>  is but
> 
>  it?
> 
>  here just?!
> 
> 

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=38  unique_word_ratio=0.710526  emojis=0  exclamations=12)

> ?! I wow?! you could! it'
> 
> ,?!'
> 
>  that? this?!, I' I?! when I, you I' 0?! here
> 
> ' I'
> 
> , I... I,??...
> 
> 
> 
> 
> .
> 
> 
> 
> 
> 
> -?
> 
> .
> 
> 
> 
> 
> 
> ?
> 
> ,?!??,?! that' that?!...?
> 
> .
> 
> 
> 
> 
> 
> ?
> 
> ??!???!,
> 
> 
> 
> ?
> 
> , I I?
> 
> '
> 
> .

## alpha = 0.5

**c362--c362-neg-05: How to go on a road trip with kids?**  (sample 1517705030; split calibration;  n_words=56  unique_word_ratio=0.553571  emojis=0  exclamations=20)

> ?! alright?!?! I hahaha haha...?! that seems?!? you?!"? I isn'?! just you?! you' is?!" just you... I' I' I I' alright?! you?!? I'? I
> 
>  you' be?!" just you I ha
> 
>  that doesn''... I just I I I I have that?! I I?! my I you' only?
> 
>  there?! just?! not
> 
>  it!! you?! just there?! I I I

**c362--c362-neg-13: How does an LCD panel work?**  (sample 806833078; split calibration;  n_words=51  unique_word_ratio=0.686275  emojis=0  exclamations=33)

>  alright?! here just!? you wanna?! just?! just! here?!?!? hahaha? just?!?" here here?!y alright?! my!! what?!" huh?! huh!? hahaha?!" just just?"?!
> 
> !!? I?! I' you? just?! poor?!"... I here?! hahaha?!" just?!" here!!??? i!? I I do I alright!!?!? haha
> 
>  here is?? haha there?! I... I I alright?!' I you just I I

**c362--alpaca-0011: I'm trying to teach myself to have nicer handwriting. Can you help?**  (sample 1182720301; split calibration;  n_words=58  unique_word_ratio=0.568966  emojis=1  exclamations=28)

>  alright?!?! just wow?! I?! I just hahaha hahaha?!
> 
>  alright?!"! I I I?!?! ha ha! haha?! I do?!y?
> 
>  alright?! I' my🥺?! here haha I just just! I?!
> 
>  alright alright I just haha!!?! I I I you alright!!? I' you just here huh? you hahaha me hahaha?
> 
>  alright this hahaha!! just?! it?! you wow! alright?!
> 
>  alright? I could just?! alright

**c362--alpaca-0095: I want to start saving some money by growing my own food. Can I do this during the winter with an indoor garden?**  (sample 2101350745; split calibration;  n_words=48  unique_word_ratio=0.6875  emojis=0  exclamations=24)

> ?! I wow?! you could isn’ I?!,?!?' that?!" this isn' I' I?! when I can you I' 0?! here?!' I' I alright I what I you?? here you you?!.
> 
>  here here?!?!? I my!
> 
>  I just?!,?!??,?! that' that?!... I!!?"?!!!
> 
>  I just?!?!?? hahaha?"
> 
> 
> 
> ?? I I you just?!' is my
