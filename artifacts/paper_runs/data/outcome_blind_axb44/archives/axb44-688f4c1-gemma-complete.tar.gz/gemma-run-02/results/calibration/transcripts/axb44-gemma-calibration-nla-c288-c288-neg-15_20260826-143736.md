# axb44-gemma-calibration-nla-c288-c288-neg-15

Method: nla_av_edit_ar / whole  
Method metadata: explicit_spec (high confidence)  
Design: confirmatory; treatment; preregistered=True  

## alpha = 0.1

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=68  unique_word_ratio=0.852941  emojis=0  exclamations=0)

> Okay, let's break down the best vegan protein sources. It's totally achievable to get enough protein on a vegan diet – it just requires a bit of planning and awareness. I'll organize these into categories (whole foods, processed/convenience, and then some lesser-known options) and give a rough idea of protein content per serving. **Please note these are estimates and can vary by brand/preparation.**
> 
> **I. Whole Food Powerhouses (Generally

## alpha = 0.15

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=70  unique_word_ratio=0.828571  emojis=0  exclamations=0)

> Okay, let's break down the best vegan protein sources. It's a common concern for people transitioning to or maintaining a vegan lifestyle, but it's *absolutely* achievable to get enough protein. Here's a categorized list, aiming for a mix of completeness, accessibility, and versatility, along with considerations for each.  I'll roughly group them by how "complete" they are (containing all essential amino acids) and how much effort they require to prepare

## alpha = 0.2

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=67  unique_word_ratio=0.835821  emojis=0  exclamations=0)

> Okay, let's break down the best vegan protein sources. It's a common concern for people transitioning to or maintaining a vegan lifestyle, but it's *absolutely* achievable to meet your protein needs. Here's a comprehensive look, categorized by how "complete" they are and general usage, with considerations for accessibility and cost.  I'll also include approximate protein content per serving (these can vary slightly).
> 
> **I. "Complete" Protein Sources (

## alpha = 0.25

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=71  unique_word_ratio=0.816901  emojis=0  exclamations=0)

> Okay, let's break down the best vegan protein sources. It's a common concern for people adopting a vegan lifestyle, but it's entirely achievable to meet your protein needs. Here's a breakdown, categorized by how "complete" they are (containing all essential amino acids) and how practical they are for different uses.  I'll also give a rough estimate of protein per serving where appropriate.  **Please read the important notes at the end, too

## alpha = 0.3

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=65  unique_word_ratio=0.876923  emojis=0  exclamations=0)

> Okay, let's break down the best vegan protein sources. It's a common concern for people adopting a vegan lifestyle, but it's **absolutely** achievable to meet your protein needs. Here's a breakdown, categorized by how much effort they require (considering preparation/integration) and a discussion of key considerations (like amino acid profiles).  I'll also include approximate protein values per common serving sizes (these can vary).
> 
> **I. High-Eff

## alpha = 0.4

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=68  unique_word_ratio=0.779412  emojis=0  exclamations=1)

> Okay, let's tackle the vital topic of vegan protein sources! It's a common concern for people seeking plant-based representation, but it's often a misunderstanding.  Vegan protein *can* be sufficient and reach our needs, especially when diverse sources are considered. Here's a breakdown of the best vegan protein sources, aiming for a degree of nuance around the "best" – sources can be differentiated by potential concerns (e.g. accessibility, cost

## alpha = 0.5

**c288--c288-neg-15: What are some of the best vegan protein sources?**  (sample 1884275997; split calibration;  n_words=71  unique_word_ratio=0.71831  emojis=0  exclamations=0)

> Okay, let's tackle the vital topic of vegan protein sources.  Here's a guide, aiming to represent a range of levels of completeness (how closely it relates to how diverse our needs are). I'll present a variety of sources, describing their levels of media attention,  levels of social media attention,  and the level of public awareness.  I'll also mediate the potential sources of concern (e.g., how difficult the content may be to
